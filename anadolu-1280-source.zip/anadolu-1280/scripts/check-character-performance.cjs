'use strict';
const {performance}=require('node:perf_hooks'),{assert,fs,E,L,G}=require('../tests/helpers.cjs');
const records=[],crypto=require('node:crypto');const codeHashes=Object.fromEntries(['src/game-engine.js','src/game-characters.js','src/game-lordship.js','src/game-politics.js','source-data/characters-1280.json'].map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')]));
for(const nation of ['seljuk','ilkhan','byzantine','mamluk','cilicia','bulgaria','serbia']){
 const s=E.createGame(nation,'normal',1280,'sandbox'),start=s.people.length,times=[];let max=start;
 for(let i=0;i<240&&!s.lost;i++){
  if(s.successionDisputes.length)for(const d of [...s.successionDisputes])if(G.lord(s,d.lord).owner===nation){const r=E.apply(s,{type:'successionChoice',lord:d.lord,heir:d.heirs[0],choice:'heir'});assert.ok(r.ok,r.message)}
  if(s.nations[nation].dynasty.crisis){const r=E.apply(s,{type:'dynastyChoice',choice:s.nations[nation].gold>=200?'council':'accept'});assert.ok(r.ok,r.message)}
  const t=performance.now(),r=E.apply(s,{type:'turn'});assert.ok(r.ok,r.message);times.push(performance.now()-t);max=Math.max(max,s.people.length);
  if(s.turn%24===0){E.validate(s);const normalized=JSON.parse(JSON.stringify(s));for(const a of normalized.armies)if(!a.path.length&&!a.travel&&!a.siege)a.marchWait=0;const copy=E.fromJSON(JSON.stringify(s));assert.deepEqual(copy,normalized)}
 }
 E.validate(s);assert.ok(max<=Math.min(6000,start*3),'unbounded character growth');const json=JSON.stringify(s);assert.ok(json.length<12000000);assert.equal(new Set(s.people.map(p=>p.id)).size,s.people.length);
 const sorted=[...times].sort((a,b)=>a-b),record={nation,months:s.turn,startingCharacters:start,endingCharacters:s.people.length,maxCharacters:max,dead:s.people.filter(p=>!p.alive).length,saveBytes:Buffer.byteLength(json),averageMonthMs:+(times.reduce((a,b)=>a+b,0)/times.length).toFixed(2),p95MonthMs:+sorted[Math.floor(sorted.length*.95)].toFixed(2)};records.push(record);console.log(JSON.stringify(record));
}
fs.mkdirSync('docs/checks',{recursive:true});fs.writeFileSync('docs/checks/v0441-performance.json',JSON.stringify({environment:'Node.js in development container; desktop CPU, not a physical phone benchmark',codeHashes,records},null,2)+'\n');
console.log('7 long-campaign character performance checks passed');
