#!/usr/bin/env python3
"""A lightweight, period-inspired visible atlas. Full save geography is retained.

The geographic window is a game design choice, not a claim about what every
13th-century society knew. Carta Pisana / early portolans inform the ink style.
"""
from pathlib import Path
import sys,json,html,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'.map-deps'))
from shapely import make_valid,set_precision
from shapely.geometry import shape,box,Polygon,Point
from shapely.ops import unary_union
sys.path.insert(0,str(ROOT/'scripts'))
import atlas_assets as art
for i,n in enumerate(json.loads((ROOT/'source-data/world-1280.json').read_text())['countries']):
 art.HERALDRY[n['id']]=(n['color'],'#5d4e34','Temsilî oyun mührü')
 art.MOTIFS[n['id']]=['<path d="M0-28 9-9 28 0 9 9 0 28-9 9-28 0-9-9Z" fill="currentColor"/>',art.EAGLE,art.LION][i%3]
D=ROOT/'dist';data=json.loads((D/'world-map-data.json').read_text())
W,H,TOP,PH=11200,6200,100,6000;WEST,EAST,SOUTH,NORTH=-26,148,-12,73
SX=(W-240)/(EAST-WEST);SY=(PH-160)/(NORTH-SOUTH)
xy=lambda p:(120+(p[0]-WEST)*SX,TOP+80+(NORTH-p[1])*SY)
esc=lambda s:html.escape(str(s),quote=True)
def path(g):
 if g.is_empty:return ''
 if g.geom_type=='Polygon':return ' '.join('M'+'L'.join(f'{x:.1f},{y:.1f}' for x,y in map(xy,r.coords))+'Z' for r in [g.exterior,*g.interiors])
 if g.geom_type in ['LineString','LinearRing']:return 'M'+'L'.join(f'{x:.1f},{y:.1f}' for x,y in map(xy,g.coords))
 if hasattr(g,'geoms'):return ' '.join(path(q) for q in g.geoms)
 return ''
hidden={'mali','kanem','makuria','alwa','ethiopia','shewa'}
# Rectangular ocean; only physical land is restricted by scope.
frame=box(WEST,SOUTH,EAST,NORTH)
southern_africa=Polygon([(WEST,SOUTH),(54,SOUTH),(54,11),(44,12),(43.2,13),(40,18),(35.6,23.7),(WEST,23.7)])
footprint=frame.difference(southern_africa).difference(box(-60,66,-10,90)).difference(box(130,SOUTH,EAST,0)).difference(box(110,SOUTH,EAST,-9.4))
base=json.loads((ROOT/'source-data/land.geojson').read_text())
physical=make_valid(unary_union([shape(f['geometry']).intersection(frame) for f in base['features']]))
land=physical.intersection(footprint).simplify(.012,preserve_topology=True)
lakes=unary_union([shape(f['geometry']).intersection(footprint) for f in json.loads((ROOT/'source-data/ne_50m_lakes.geojson').read_text())['features'] if f['properties'].get('featurecla')!='Reservoir']).simplify(.015,preserve_topology=True)
land=land.difference(lakes);coast=physical.boundary.intersection(footprint).difference(frame.boundary.buffer(.01)).simplify(.012,preserve_topology=True)
features=json.loads((D/'world-provinces.geojson').read_text())['features']
original={f['id']:shape(f['geometry']) for f in features}
visible=[];geoms={}
for p in data['provinces']:
 p['map_visible']=p['owner'] not in hidden and footprint.covers(Point(p['lon'],p['lat']))
 if p['map_visible']:
  visible.append(p);geoms[p['id']]=set_precision(make_valid(original[p['id']].intersection(footprint)),.001)
for n in data['regions']:
 n['map_visible']=n['id'] not in hidden
 if n['continent']=='Afrika':n['continent']='Kuzey Afrika'
 if n['id']=='tripoli':n['continent']='Asya'
countries=[n for n in data['regions'] if n['map_visible']];N={n['id']:n for n in countries}
owned={n['id']:unary_union([geoms[p['id']] for p in visible if p['owner']==n['id']]) for n in countries}
occupied=unary_union(list(geoms.values()))
# A line is generated once from shared geometry, without buffered double edges.
# Reuse canonical, snapped polygon coordinates on both sides of a border.
edges=[]
for i,a in enumerate(visible):
 for b in visible[i+1:]:
  ga,gb=geoms[a['id']],geoms[b['id']]
  if ga.distance(gb)>.002:continue
  g=ga.boundary.intersection(gb.boundary)
  if not g.is_empty and g.length>.001:edges.append({'a':a['id'],'b':b['id'],'path':path(g.simplify(.008,preserve_topology=True))})
outer=occupied.boundary.difference(coast.buffer(.024)).difference(footprint.boundary.buffer(.025))
initial=unary_union([g.boundary for g in owned.values()]).difference(coast.buffer(.024)).difference(footprint.boundary.buffer(.025))
(D/'world-game-edges.json').write_text(json.dumps({'shared':edges,'outer':path(outer.simplify(.01,preserve_topology=True)),'initial':path(initial.simplify(.01,preserve_topology=True))},separators=(',',':')))
# Retain original heraldic symbols for panels; city marks are simple vector dots.
s=ET.fromstring((D/'world-map.svg').read_text());ns='{http://www.w3.org/2000/svg}'
defs=s.find(ns+'defs');symbols=[ET.tostring(q,encoding='unicode').replace('ns0:','').replace(':ns0','') for q in defs if q.tag==ns+'symbol' and not q.get('id','').startswith('atlas-')]
a=[f'<svg xmlns="http://www.w3.org/2000/svg" id="historical-map" class="world-atlas known-world-atlas" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="map-title map-desc"><title id="map-title">Anadolu 1280 · Bilinen Dünya</title><desc id="map-desc">Avrupa, Asya ve Kuzey Afrika. 1300 civarı portolan çiziminden esinlenen sade siyasi atlas; başlangıç 1280. Şehir çevreleri oyun bölgeleridir.</desc><defs>']
a+=symbols
fade_y1=xy((0,27.5))[1];fade_y2=xy((0,23.7))[1];fade_x=xy((35.6,0))[0]
a+=[f'<path id="world-land" d="{path(land)}"/><linearGradient id="africa-fade" gradientUnits="userSpaceOnUse" x1="0" y1="{fade_y1:.1f}" x2="0" y2="{fade_y2:.1f}"><stop stop-color="white"/><stop offset="1" stop-color="black"/></linearGradient><mask id="north-africa-margin" maskUnits="userSpaceOnUse" x="0" y="0" width="{W}" height="{H}"><rect width="{W}" height="{H}" fill="white"/><rect y="{fade_y1:.1f}" width="{fade_x:.1f}" height="{H-fade_y1:.1f}" fill="url(#africa-fade)"/></mask><clipPath id="world-frame"><rect width="{W}" height="{H}"/></clipPath><linearGradient id="atlas-sea" x2=".6" y2="1"><stop stop-color="#8faeb0"/><stop offset="1" stop-color="#8faeb0"/></linearGradient><linearGradient id="atlas-paper" x2=".3" y2="1"><stop stop-color="#e6dcc0"/><stop offset="1" stop-color="#ccbd96"/></linearGradient><radialGradient id="sahara-haze" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="1" gradientTransform="translate(1000 5600) scale(3900 3200)"><stop stop-color="#d8cba8"/><stop offset=".68" stop-color="#d8cba8"/><stop offset=".86" stop-color="#d8cba8" stop-opacity=".6"/><stop offset="1" stop-color="#d8cba8" stop-opacity="0"/></radialGradient><symbol id="atlas-city" viewBox="-9 -10 18 20"><path d="M-7 6V-2l4-4 4 4v8m-4-8V6M1 6V-1l3-3 3 3v7M-8 7H8" fill="#dfcf9f" stroke="#68563f" stroke-width="1.15" stroke-linejoin="round"/><path d="M-4 6V2h3v4m4 0V2h2v4" fill="#756048"/></symbol><symbol id="atlas-capital" viewBox="-10 -12 20 24"><path d="M-8 7V-4h2V-7h3v3h6V-7h3v3h2V7Zm5 0V1a3 3 0 0 1 6 0v6M-8-4H8M-10 8H10" fill="#d0b87c" stroke="#5c4d37" stroke-width="1.2" stroke-linejoin="round"/><path d="M0-7v-5l5 1-5 2" fill="#986547" stroke="#684f35" stroke-width="1"/></symbol></defs>']
a.append(art.defs())
a+=[f'<rect width="{W}" height="{H}" fill="url(#atlas-sea)"/><g clip-path="url(#world-frame)"><rect class="world-unknown-haze" width="{W}" height="{H}" fill="url(#sahara-haze)" pointer-events="none"/><g class="world-geography" mask="url(#north-africa-margin)"><use href="#world-land" fill="#d8cba8"/>']
# Solid per-province fills prevent seams from stacked translucent owner layers.
for p in visible:
 a.append(f'<path class="province" data-province="{p["id"]}" data-owner="{p["owner"]}" role="button" tabindex="0" aria-label="{esc(p["name"])} — {esc(N[p["owner"]]["name"])}" fill="{N[p["owner"]]["color"]}" d="{path(geoms[p["id"]])}"><title>{esc(p["name"])} — {esc(N[p["owner"]]["name"])}</title></path>')
# Major rivers and a few engraved ranges. No full-map repeated texture patterns.
rivers=[]
for f in json.loads((ROOT/'source-data/ne_50m_rivers_lake_centerlines.geojson').read_text())['features']:
 rank=f['properties'].get('scalerank',7)
 if rank is not None and rank<=3:rivers.append(shape(f['geometry']).intersection(footprint).simplify(.025,preserve_topology=True))
a.append(f'<path class="world-rivers" d="{path(unary_union(rivers))}"/><path class="world-water" d="{path(lakes)}"/><path class="world-coastline" d="{path(coast)}"/>')
for title,x,y in [('BAHR-İ RÛM',17,34),('KARADENİZ',34,44),('HAZAR',51,41),('HİNT DENİZİ',72,2),('ÇİN DENİZİ',115,16)]:
 x,y=xy((x,y));a.append(f'<text class="world-sea-label" x="{x:.1f}" y="{y:.1f}">{title}</text>')
# Light original ridge marks stay separate from boundaries and city symbols.
for title,line in [('ALPLER',[(6,46),(8,46.7),(11,46.5),(14,46)]),('ATLAS',[(-9,30),(-6,32),(-3,33),(1,35)]),('TOROSLAR',[(29,37),(32,37.5),(35,38),(37,38.5)]),('KAFKASLAR',[(40,43),(43,43.7),(46,42)]),('ZAGROS',[(45,35),(48,33),(51,30),(54,28)]),('HİMALAYA',[(74,34),(80,31),(86,29),(93,28)]),('TANRI DAĞLARI',[(71,42),(77,42.5),(84,43)])]:
 d=[]
 for lon,lat in line:
  x,y=xy((lon,lat));d.append(f'M{x-11:.1f},{y+8:.1f}l11,-22 12,22m-12,-22 3,19')
 a.append('<path class="world-engraved-range" d="'+' '.join(d)+'"/>')
a.append('</g><g class="cities-layer">')
for p in visible:
 x,y=p['map_x'],p['map_y'];cap=p['capital']
 a.append(f'<g class="city-node {"capital-node" if cap else ""}" data-province="{p["id"]}" role="button" tabindex="0" aria-label="{esc(p["name"])} merkezi" transform="translate({x:.1f} {y:.1f})"><title>{esc(p["name"])} · {esc(N[p["owner"]]["short"])}</title><circle class="city-hit" r="9" fill="transparent"/><circle class="city-dot" r="{3 if cap else 2}"/><use class="city-sprite" href="#{"atlas-capital" if cap else "atlas-city"}" x="{-9 if cap else -8}" y="{-12 if cap else -10}" width="{18 if cap else 16}" height="{22 if cap else 20}"/><rect class="city-label-hit" x="9" y="-10" width="{max(24,len(p["name"])*6+8)}" height="19" fill="transparent"/><text class="city-label" x="11" y="4" text-anchor="start">{esc(p["name"])}</text></g>')
a.append('</g></g>')
x,y=xy((7,18));a.append(f'<text class="atlas-margin-note" x="{x:.1f}" y="{y:.1f}" text-anchor="middle">SAHRA</text>')
a.append('</svg>');(D/'world-map.svg').write_text(''.join(a))
data['map']['cameraBounds']=[120,180,W-120,TOP+PH-80]
data['map']['atlasScope']='known-world';data['map']['visibleProvinceIds']=[p['id'] for p in visible];data['map']['visibleCountryIds']=list(N)
data['map']['views']=[{'id':i,'name':n,'bbox':[xy((b[0],b[3]))[0],xy((b[0],b[3]))[1],xy((b[2],b[1]))[0],xy((b[2],b[1]))[1]]} for i,n,b in [('all','Bilinen dünya',[-25,-9,146,69]),('europe','Avrupa',[-12,34,44,67]),('anatolia','Anadolu',[23,32,48,45]),('africa','Kuzey Afrika',[-16,24,36,38]),('asia','Asya',[45,0,144,58]),('eastasia','Doğu Asya',[100,18,144,49]),('india','Hindistan',[66,5,92,36])]]
data['stats']['visibleCountries']=len(countries);data['stats']['visibleProvinces']=len(visible)
data['cartography']['scope_note']='Görünür kapsam Avrupa, Asya ve Kuzey Afrika’dır. Sahra altı, Amerika ve Avustralya gösterilmez. 1300 civarı portolan üslubu, 1280 siyasi başlangıcıyla yorumlanmıştır.'
period=[{'title':'Carta Pisana, c. 1275–1300 · Oxford','url':'https://www.cabinet.ox.ac.uk/carta-pisana-ca-1275-1300','scope':'Akdeniz ve Karadeniz kıyıları, erken portolan çizim yaklaşımı; üslup referansı.'},{'title':'Library of Congress · Portolan Charts','url':'https://guides.loc.gov/nautical-charts/portolan-charts','scope':'Geç 13. yüzyıl deniz haritaları, kıyı ve liman odaklı çizim; görseller kopyalanmadı.'}]
for item in period:
 if item['url'] not in [s['url'] for s in data['cartography']['sources']]:data['cartography']['sources'].append(item)
(D/'world-map-data.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
print(json.dumps({'visible_countries':len(countries),'visible_cities':len(visible),'svg_kib':(D/'world-map.svg').stat().st_size//1024,'border_edges':len(edges)}))
