#!/usr/bin/env python3
import sys,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'.map-deps'))
from shapely.geometry import shape,Point
from shapely.ops import unary_union
d=json.loads((ROOT/'dist/world-map-data.json').read_text());features=json.loads((ROOT/'dist/world-provinces.geojson').read_text())['features'];geoms={f['id']:shape(f['geometry']) for f in features};P={p['id']:p for p in d['provinces']}
for i,(id,g) in enumerate(geoms.items()):
 assert g.is_valid and not g.is_empty,id
 assert g.distance(Point(P[id]['lon'],P[id]['lat']))<.18,(id,'anchor far outside city region')
 for b in list(geoms)[i+1:]:assert g.intersection(geoms[b]).area<1e-7,(id,b,'overlap')
 for b in P[id]['neighbours']:assert b in P and id in P[b]['neighbours'],(id,b,'asymmetric graph')
assert set(geoms)==set(P)
assert len({p['owner'] for p in P.values()})==len(d['regions'])
assert all(0<=p['map_x']<=d['map']['width'] and d['map']['top']<=p['map_y']<=d['map']['top']+d['map']['plot_height'] for p in P.values())
print('PASS geography: all',len(geoms),'city polygons valid, non-overlapping, in frame; symmetric travel graph; all',len(d['regions']),'states represented')
