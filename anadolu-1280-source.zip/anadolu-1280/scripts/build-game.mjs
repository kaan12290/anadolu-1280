import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
let sharp;try{sharp=require('sharp')}catch{sharp=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'sharp'))}
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const imageData=async(p,w)=>'data:image/webp;base64,'+(await sharp(path.join(root,p)).resize({width:w,withoutEnlargement:true}).webp({quality:82}).toBuffer()).toString('base64');
let map=read('dist/map.svg').replace(/<style>[\s\S]*?<\/style>/g,'').replace(/<path class="country-border"[^>]*\/>/g,'').replace(/<path d="[^"]*" fill="none" stroke="#e9dbad"[^>]*\/>/g,'').replace('role="img"','role="group"').replace(/<use href="#banner-[^"]+"[^>]*\/>/g,'').replace(/<path d="M17-43V-7"[^>]*\/>/g,'');
const scenario=JSON.parse(read('dist/map-data.json'));scenario.campaign=JSON.parse(read('source-data/campaign-1280.json'));
scenario.campaign.art=[];
for(const art of JSON.parse(read('source-data/ruler-art/credits.json'))){if(art.file)scenario.campaign.art.push({...art,image:await imageData(art.file,420)})}
scenario.campaign.characters=JSON.parse(read('source-data/characters-1280.json'));
const data=JSON.stringify(scenario),edges=read('dist/game-edges.json');
map=map.replace('</defs>',scenario.campaign.futureNations.map(n=>`<symbol id="crest-${n.id}" viewBox="0 0 72 88"><path d="M5 5H67V49Q65 72 36 84Q7 72 5 49Z" fill="${n.color}" stroke="#e2c685" stroke-width="3"/><path d="M22 35L36 18 50 35 36 55Z" fill="none" stroke="#ead9aa" stroke-width="3"/></symbol>`).join('')+'</defs>');
const portrait=await imageData('dist/ui-assets/ruler-concept.png',480),titleScene=await imageData('source-data/ui/title-palace-v2.webp',1920);
const iconSvg='<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256"><rect width="256" height="256" rx="45" fill="#203b3b"/><rect x="15" y="15" width="226" height="226" rx="34" fill="none" stroke="#bda16a" stroke-width="3"/><path d="M64 61h128v77c0 37-35 64-64 75-29-11-64-38-64-75V61Z" fill="#386052" stroke="#d5bd7e" stroke-width="5"/><path d="m83 96 22 13 23-31 23 31 22-13-9 51H92l-9-51Zm15 41h60" fill="#d8bd76" stroke="#d8bd76" stroke-width="4"/><text x="128" y="181" text-anchor="middle" font-family="Georgia,serif" font-size="26" fill="#efdcb0">1280</text></svg>';
const icon=await sharp(Buffer.from(iconSvg)).png().toBuffer();fs.mkdirSync(path.join(root,'desktop'),{recursive:true});fs.writeFileSync(path.join(root,'desktop/icon.png'),icon);
let html=read('src/game.template.html').replace('/* GAME_CSS */',()=>read('src/game.css')+'\n'+read('src/title-screen.css')+'\n'+read('src/game-prestige.css')+'\n'+read('src/game-strategy.css')+'\n'+read('src/game-statecraft.css')+'\n'+read('src/game-minimal-ui.css')+'\n'+read('src/game-lordship.css')+'\n'+read('src/game-workspace.css')+'\n'+read('src/game-characters.css')).replace('/* ICON_DATA */','data:image/png;base64,'+icon.toString('base64')).replace('/* PORTRAIT_DATA */',portrait).replace('<!-- TITLE_SCENE -->','<img src="'+titleScene+'" alt="" aria-hidden="true" fetchpriority="high">').replace('<!-- GAME_MAP -->',map).replace('/* SCENARIO_DATA */',data.replaceAll('</','<\\/')).replace('/* EDGE_DATA */',edges.replaceAll('</','<\\/')).replace('/* GAME_ENGINE */',()=>read('src/game-characters.js')+'\n'+read('src/game-missions.js')+'\n'+read('src/game-depth.js')+'\n'+read('src/game-strategy.js')+'\n'+read('src/game-statecraft.js')+'\n'+read('src/game-politics.js')+'\n'+read('src/game-conflict.js')+'\n'+read('src/game-diplomacy.js')+'\n'+read('src/game-lordship.js')+'\n'+read('src/game-engine.js')).replace('/* GAME_APP */',()=>read('src/game-app.js')+'\n'+read('src/game-expansion.js')+'\n'+read('src/game-depth-app.js')+'\n'+read('src/game-strategy-app.js')+'\n'+read('src/game-lordship-app.js')+'\n'+read('src/game-diplomacy-app.js')+'\n'+read('src/game-minimal-ui.js')+'\n'+read('src/game-workspace.js')+'\n'+read('src/game-characters-app.js'));
if(/\/\* (?:GAME_|SCENARIO_|EDGE_|PORTRAIT_|ICON_)|<!-- TITLE_SCENE -->/.test(html))throw Error('Unresolved template marker');
for(const match of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new vm.Script(match[1]);
fs.writeFileSync(path.join(root,'dist/index.html'),html);
const out=process.env.ANADOLU_OUTPUT_DIR;if(out){fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'Anadolu_1280.html'),html)}
console.log('Playable offline application:',Math.round(Buffer.byteLength(html)/1024),'KiB');
