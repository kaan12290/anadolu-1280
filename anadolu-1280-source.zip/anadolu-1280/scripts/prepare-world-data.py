#!/usr/bin/env python3
"""Curated January 1280 anchors; geographic boundaries are compiled separately.

Rulers, cities and borders are distinct evidence layers. Unknown rulers are
represented by an office rather than an invented historical personal name.
"""
import json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1];D=ROOT/'source-data'
read=lambda p:json.loads((D/p).read_text())
europe=read('world-research/europe.json')['countries'];africa=read('world-research/africa.json')['polities']
ASIA=[]
def polity(id,name,short,culture,capital,ruler,places,shape=None,box=None,overlord=None,note='',sources=None):
    p={'id':id,'name':name,'short':short,'culture':culture,'capital':capital,'color':'#b6ad8a','ruler':{'name':ruler,'title':'Hükümdar','status':'uncertain'},'locations':[{'name':n,'lon':x,'lat':y,'port':bool(port)} for n,x,y,port in places], 'summary':name+' · 1280 başlangıç haritası.','note':note,'sources':sources or ['https://github.com/Seshat-Global-History-Databank/cliopatria']}
    if shape:p['geometry_names']=shape if isinstance(shape,list) else [shape]
    if box:p['mask']=box
    if overlord:p['overlord']=overlord
    ASIA.append(p);return p
MONGOL='https://afe.easia.columbia.edu/mongols/conquests/conquests_4.htm'
polity('goldenhorde','Altın Orda Hanlığı','Altın Orda','kipchak','Saray','Möngke Temür',[('Saray',47.2,47.2,0),('Bulgar',49.05,54.97,0),('Saksın',48.0,46.5,0),('Solhat',35.03,45.03,0),('Ürgenç',59.16,42.32,0),('Sığnak',66.96,44.15,0)],'Golden Horde',note='Moğol alanı tek bir devlet olarak gösterilmez. Rus knezliklerinin haraç bağı, doğrudan Altın Orda eyaleti olmakla eş tutulmaz. 1294 referans geometrisi 1280 çevresine yaklaşık uyarlandı.',sources=[MONGOL])
polity('chagatai','Çağatay Hanlığı','Çağatay','chagatai','Almalık','Buqa Temür',[('Almalık',80.28,44.15,0),('Semerkant',66.97,39.65,0),('Buhara',64.43,39.77,0),('Kaşgar',75.99,39.47,0),('Yarkent',77.25,38.42,0),('Belh',66.9,36.76,0)],'Chagatai Khanate',note='Kaidu ile Çağatay ulusu arasındaki yetki ve sınırlar değişkendir. Duwa, Ocak 1280 hükümdarı olarak kullanılmadı. Sınır 1294 referansından genelleştirilmiştir.',sources=[MONGOL])
polity('kaidu','Kaidu Ulusu','Kaidu','mongol','Kayalık','Kaidu',[('Kayalık',80.12,45.64,0),('Beşbalık',89.25,44.0,0),('Emil',83.0,46.8,0)],box=[77,43.6,93,50.4],note='Ögedeyli Kaidu’nun değişken nüfuz alanı; kesin devlet sınırı iddiası yok.',sources=[MONGOL])
polity('yuan','Yuan İmparatorluğu','Yuan','han','Dadu','Kubilay Han',[('Dadu',116.39,39.91,0),('Shangdu',116.18,42.35,0),('Karakurum',102.82,47.2,0),('Chang’an',108.94,34.26,0),('Kaifeng',114.31,34.8,0),('Lin’an',120.15,30.27,1),('Quanzhou',118.59,24.91,1),('Guangzhou',113.26,23.13,1),('Chengdu',104.07,30.67,0),('Kunming',102.71,25.04,0),('Liaoyang',123.17,41.27,0),('Dunhuang',94.66,40.14,0)],'Yuan Dynasty',note='Yuan 1271’de ilan edildi; Güney Song 1279’da sona erdi. 1280’de bağımsız Song devleti eklenmedi. 1294 geometrisi, ayrı Kore ve Tibet idareleriyle yaklaşık kullanılır.',sources=[MONGOL,'https://asia.si.edu/education/educator-resources/teaching-china-with-the-smithsonian/explore-by-dynasty/yuan-dynasty/'])
polity('goryeo','Goryeo Krallığı','Goryeo','korean','Gaegyeong','Chungnyeol',[('Gaegyeong',126.55,37.97,0),('Pyeongyang',125.75,39.03,0),('Gyeongju',129.22,35.86,1)],box=[124,33,130.8,42.3],overlord='yuan',note='Yuan üst hâkimiyetinde kendi hanedanını sürdüren krallık; doğrudan Çin eyaleti olarak gösterilmez.',sources=[MONGOL])
polity('tibet','Sakya–Yuan Tibet İdaresi','Sakya','tibetan','Sakya','Sakya idaresi',[('Sakya',88.02,28.9,0),('Lhasa',91.13,29.65,0),('Shigatse',88.88,29.27,0)],box=[78,27,100.0,35.0],overlord='yuan',note='Sakya dinî idaresi ve Moğol/Yuan üst hâkimiyeti altında yaklaşık yönetim alanı; modern bağımsız ulus sınırı değildir.',sources=[MONGOL])
polity('japan','Kamakura Japonya’sı','Kamakura','japanese','Kamakura','Hōjō Tokimune',[('Kamakura',139.55,35.32,1),('Kyōto',135.77,35.01,0),('Hakata',130.42,33.59,1),('Nara',135.8,34.69,0),('Hiraizumi',141.11,38.99,0)],'Kamakura Shogunate',note='Kamakura askerî idaresi; imparatorluk sarayı Kyōto’dadır. Hōjō Tokimune şogun değil şikkendir.')
polity('delhi','Delhi Sultanlığı','Delhi','hindustani','Delhi','Gıyâseddin Balaban',[('Delhi',77.22,28.65,0),('Lahor',74.34,31.55,0),('Multan',71.47,30.2,0),('Badaun',79.13,28.04,0),('Lakhnauti',88.14,24.87,0)],['(Delhi Sultanate)','Mamluk Dynasty'],note='Delhi Türk Memlük hanedanı; Mısır Memlük devletinden ayrıdır. Halacî iktidarı 1290’da başlar.',sources=['https://islamansiklopedisi.org.tr/balaban-han'])
polity('yadava','Yadava Krallığı','Yadava','marathi','Devagiri','Ramachandra',[('Devagiri',75.22,19.94,0),('Pratishthana',75.38,19.48,0),('Nasik',73.78,20.0,0)],'Yadava Dynasty')
polity('hoysala','Hoysala Krallığı','Hoysala','kannada','Dvarasamudra','III. Narasimha',[('Dvarasamudra',75.99,13.21,0),('Belur',75.87,13.16,0),('Srirangapatna',76.69,12.42,0)],'Hoysala Kingdom')
polity('kakatiya','Kakatiya Krallığı','Kakatiya','telugu','Orugallu','Rudrama Devi',[('Orugallu',79.59,18.0,0),('Hanamkonda',79.56,18.01,0),('Motupalli',80.17,15.5,1)],'Kakatiya Dynasty')
polity('pandya','Pandya Krallığı','Pandya','tamil','Madurai','I. Maravarman Kulasekara',[('Madurai',78.12,9.93,0),('Tirunelveli',77.7,8.73,0),('Kayal',78.12,8.67,1)],'Pandya Empire')
polity('ganga','Doğu Ganga Krallığı','Doğu Ganga','oriya','Kataka','I. Narasimha’nın halefleri',[('Kataka',85.88,20.46,0),('Puri',85.83,19.81,1),('Kalinganagara',84.05,18.59,0)],'Eastern Ganga Kingdom')
polity('vaghela','Vaghela Gucerat’ı','Vaghela','gujarati','Anahilvada','Saranga Deva',[('Anahilvada',72.13,23.85,0),('Khambhat',72.62,22.32,1),('Somnath',70.4,20.89,1)],box=[68,20.0,74.5,25.0],note='Gucerat’ın Vaghela idaresi; çevre uçlar yaklaşık gösterilir.')
polity('chandela','Chandela Krallığı','Chandela','hindustani','Kalinjar','Chandela hükümdarı',[('Kalinjar',80.49,25.0,0),('Khajuraho',79.92,24.85,0)],'Chandela Kingdom')
polity('nepal','Katmandu Vadisi','Nepal','newar','Katmandu','Malla idaresi',[('Katmandu',85.32,27.71,0),('Patan',85.32,27.67,0)],'Kathmandu',note='Erken Malla dönemi vadi krallıkları bölgesel ölçekte birleştirilmiştir.')
polity('lanka','Dambadeniya Krallığı','Lanka','sinhala','Dambadeniya','I. Bhuvanekabahu',[('Dambadeniya',80.15,7.37,0),('Yapahuwa',80.31,7.82,0)],['Kingdom of Dambadeniya','Ceylon'],note='Sri Lanka’daki siyasi denetim genelleştirilmiştir; adanın her noktasında eşit fiilî denetim varsayılmaz.')
polity('pagan','Pagan Krallığı','Pagan','burmese','Pagan','Narathihapate',[('Pagan',94.86,21.17,0),('Tagaung',96.0,23.5,0),('Pegu',96.48,17.34,1)],'Pagan Kingdom')
polity('lanna','Mangrai’nin Kuzey Tai Ülkesi','Mangrai','tai','Chiang Rai','Mangrai',[('Chiang Rai',99.83,19.91,0),('Fang',99.21,19.92,0)],box=[98.3,19.0,101.2,21.1],note='Chiang Mai 1296’da kurulur; 1280 başkenti olarak eklenmedi. Haripunjaya henüz ayrı krallıktır.')
polity('haripunjaya','Haripunjaya Krallığı','Haripunjaya','mon','Haripunjaya','Yi Ba',[('Haripunjaya',99.01,18.58,0)],'Haripuñjaya',note='Mangrai’nin sonraki fethi 1280 başlangıcına taşınmadı.')
polity('sukhothai','Sukhothai Krallığı','Sukhothai','tai','Sukhothai','Ramkhamhaeng',[('Sukhothai',99.7,17.01,0),('Si Satchanalai',99.79,17.43,0)],'Sukhothai Kingdom',note='Saltanat başlangıcı geleneksel tarihleme ile yaklaşık 1279; sonraki azami yayılma 1280’e bütünüyle taşınmadı.',sources=['https://tile.loc.gov/storage-services/master/frd/copr/Thailand.pdf'])
polity('khmer','Khmer İmparatorluğu','Khmer','khmer','Angkor','VIII. Jayavarman',[('Angkor',103.87,13.44,0),('Preah Vihear',104.68,14.39,0),('Isanapura',105.04,12.87,0)],'Khmer Empire')
polity('lavo','Lavo Krallığı','Lavo','mon','Lavo','Lavo hükümdarı',[('Lavo',100.62,14.8,0)],'Lavo Kingdom')
polity('daiviet','Đại Việt Krallığı','Đại Việt','vietnamese','Thăng Long','Trần Nhân Tông',[('Thăng Long',105.85,21.03,0),('Thiên Trường',106.16,20.43,1),('Thanh Hóa',105.78,19.81,0)],'Ngô Dynasty',note='Cliopatria’daki Ngô etiketi 1280 için düzeltilerek Trần hanedanı gösterilir.')
polity('champa','Champa Krallığı','Champa','cham','Vijaya','Jaya Indravarman V',[('Vijaya',109.11,13.89,0),('Kauthara',109.19,12.25,1),('Panduranga',108.99,11.57,1)],'Chámpa')
polity('srivijaya','Melayu–Srivijaya Ülkeleri','Melayu','malay','Dharmasraya','Melayu hükümdarı',[('Dharmasraya',101.61,-0.99,0),('Palembang',104.75,-2.99,1),('Jambi',103.61,-1.61,1)],'Srivijaya',note='Sumatra’daki geçiş dönemi ve birden fazla merkez bölgesel oyun ölçeğinde birleştirilmiştir; tek merkezli imparatorluk kesinliği yok.')
polity('singhasari','Singhasari Krallığı','Singhasari','javanese','Tumapel','Kertanagara',[('Tumapel',112.65,-7.89,0),('Tuban',112.06,-6.9,1),('Kediri',112.01,-7.82,0)],'Singhasari',note='Majapahit ancak 1293’te kurulur; Ocak 1280’e eklenmedi.')
polity('sunda','Sunda Krallığı','Sunda','sundanese','Pakuan','Sunda hükümdarı',[('Pakuan',106.8,-6.6,0),('Banten',106.15,-6.05,1)],'Sunda Kingdom')
polity('kedah','Kedah Sultanlığı','Kedah','malay','Kedah','Kedah hükümdarı',[('Kedah',100.37,6.1,1)],'Sultanate of Kedah')
polity('rasulid','Resûlî Sultanlığı','Resûlîler','arabic','Taiz','el-Muzaffer Yûsuf',[('Taiz',44.02,13.58,0),('Aden',45.03,12.79,1),('Zebid',43.32,14.2,0),('Sana',44.2,15.35,0)],'Rasulid Dynasty',sources=['https://islamansiklopedisi.org.tr/resuliler'])
polity('usfurid','Usfûrî Bahreyn’i','Usfûrîler','arabic','el-Ahsâ','Usfûrî emiri',[('el-Ahsâ',49.58,25.38,0),('Katif',49.99,26.57,1),('Bahreyn',50.58,26.22,1)],'Bahrani Dynasty',note='Bahreyn tarihî coğrafya adı doğu Arabistan’ı da kapsar; kesin hanedan uçları belirsizdir.')
polity('oman','Umman Yerel İdareleri','Umman','arabic','Nizva','Umman yerel idaresi',[('Nizva',57.53,22.93,0),('Suhar',56.75,24.35,1),('Maskat',58.41,23.59,1)],'Mahdids',note='Kaynak veri setindeki Mahdid etiketi Umman için aynen tarihî hanedan iddiası olarak kullanılmaz; yerel idareler topluca gösterilir.')
polity('hormuz','Hürmüz Krallığı','Hürmüz','persian','Eski Hürmüz','Hürmüz meliki',[('Eski Hürmüz',56.99,27.1,1)],box=[55.5,26.0,58.7,28.7],note='Ada merkezine 14. yüzyıldaki taşınma başlangıca alınmadı; kıyı Hürmüz’ü gösterilir.')

mapping={
'england':['(Kingdom of England)'],'scotland':['Kingdom of Alba'],'gwynedd':['Kingdom of Gwynedd'],'france':['(Kingdom of France)'],'castile':['Crown of Castile'],'aragon':['Crown of Aragon','County of Ampuria','County of Urgell'],'portugal':['Kingdom of Portugal'],'navarre':['Kingdom of Navarre'],'majorca':['Kingdom of Majorca'],'granada':['Emirate of Granada'],'hre':['(Holy Roman Empire)'],'bohemia':['Kingdom of Bohemia'],'hungary':['Kingdom of Hungary'],'norway':['Old Kingdom of Norway'],'sweden':['Kingdom of Sweden'],'denmark':['Kingdom of Denmark'],'teutonic':['Teutonic Order'],'greaterpoland':['Duchy of Greater Poland'],'krakow':['Grand Duchy of Kraków','Duchy of Sandomierz'],'masovia':['Duchy of Masovia'],'silesia':['Duchy of Silesia','Duchy of Głogów','Duchy of Jawor','Duchy of Legnica','Duchy of Opole'],'lithuania':['Grand Duchy of Lithuania'],'novgorod':['Novgorod Republic'],'smolensk':['Principality of Smolensk'],'galicia':['Galicia-Volhynia'],'vladimir':['Principality of Vladimir-Suzdal'],'papal':['Papal States','Comtat Venaissin'],'sicily':['House of Anjou-Sicily'],'genoa':['Republic of Genoa'],'pisa':['Republic of Pisa'],'florence':['Republic of Florence'],'arborea':['Giudicato of Arborea'],
'marinid':['Almohad Caliphate'],'zayyanid':['Zayyanid dynasty'],'hafsid':['Hafsid Dynasty'],'mali':['Mali Empire'],'kanem':['Empire of Kanem'],'makuria':['Makuria'],'alwa':['Alodia'],'ethiopia':['Ethiopian Empire']}
masks={'pomerelia':[16.6,53.1,19.2,54.9],'novgorod':[27.5,56.5,44,64.0],'vladimir':[36,54.1,46,59.0],'smolensk':[29.0,53.5,35.8,56.5],'ryazan':[38.0,52,43.5,54.9],'galicia':[22.4,47.7,29.4,51.7],'milan':[8.2,44.6,10.3,46.4],'shewa':[38.5,8.9,41.0,10.8]}
palette=['#a8bcb6','#b9a3a1','#c2b78c','#9eaea2','#a5b3c5','#bda792','#b4adba','#b4bd93','#c3aa91','#a6b9b8','#c6b0a9','#a9b5a0']
allnew=europe+africa+ASIA
for i,p in enumerate(allnew):
    if p['id'] in mapping:p['geometry_names']=mapping[p['id']]
    if p['id'] in masks:p['mask']=masks[p['id']]
    p.setdefault('geometry_names',[]);p.setdefault('continent','Avrupa' if p in europe else 'Afrika' if p in africa else 'Asya')
    p['color']=palette[i%len(palette)]
    p['note']=p.get('note',' '.join(p.get('notes',[])))
    p['ruler'].setdefault('from',0)
    p['ruler'].setdefault('title','Hükümdar')
    p.setdefault('sources',['https://github.com/Seshat-Global-History-Databank/cliopatria'])
    for loc in p['locations']:
        loc.setdefault('port',False);loc.setdefault('fort','Şehir tahkimatı' if loc['name']==p['capital'] else '')
    if p['id'] in ['vladimir','ryazan','galicia','smolensk']:p['overlord']='goldenhorde'
    if p['id']=='makuria':p['overlord']='mamluk'
    if p['id']=='bohemia':p['overlord']='hre'
    p['kind']='Bağlı yönetim' if p.get('overlord') else '1280 siyasi alanı'
payload={'revision':'world-1280-v1','year':1280,'frame':{'west':-26,'east':148,'south':-12,'north':73,'width':11200,'height':6200,'top':100,'plot_height':6000},'countries':allnew,'extent_note':'Avrupa, Asya, Kuzey Afrika, Sahel ve Nil–Habeş bölgesi. Modern ülke sınırları kullanılmaz; eksik tarihî denetim alanları nötr coğrafya olarak kalır.','sources':[{'title':'Cliopatria v0.2.1 · Seshat Global History Databank','publisher':'Seshat / Scientific Data','url':'https://github.com/Seshat-Global-History-Databank/cliopatria','license':'CC BY 4.0','scope':'1280 kesiti; gerekli yerlerde açıkça etiketlenmiş 1294 referansı ve tarihî düzeltmeler.'},{'title':'Natural Earth · Physical vectors','url':'https://www.naturalearthdata.com/downloads/50m-physical-vectors/','license':'Public domain','scope':'Kıyı, kara, nehir ve göller; siyasi sınır kaynağı değildir.'},{'title':'Euratlas Europe 1300','url':'https://www.euratlas.net/history/europe/1300/europe_map_1300.html','scope':'Yakın dönem karşılaştırması; lisanslı vektörler kopyalanmadı, 1300 sınırları 1280 kabul edilmedi.'},{'title':'The Mongol Empire · Four Sectors','publisher':'Columbia University · Asia for Educators','url':MONGOL,'scope':'Moğol alanını Yuan, Çağatay, Altın Orda ve İlhanlı olarak ayıran tarihî kontrol.'}]}
(D/'world-1280.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
print('New states:',len(allnew),'new city anchors:',sum(len(p['locations']) for p in allnew))
