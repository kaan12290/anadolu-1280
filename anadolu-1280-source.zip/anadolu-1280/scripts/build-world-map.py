#!/usr/bin/env python3
"""Compile a researched Eurasian/North-African 1280 map for the existing game.

Historical polity outlines: Cliopatria, adapted and credited, not modern states.
City cells are game regions, NOT a reconstruction of medieval administration.
The core 69 province identifiers and their original travel links are retained.
"""
import pathlib,sys,json,math,html,random,re,unicodedata,hashlib,base64
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.map-deps'))
from shapely import make_valid,set_precision
from shapely.geometry import shape,mapping,Polygon,MultiPoint,Point,box,LineString
from shapely.ops import unary_union,voronoi_diagram,transform
sys.path.insert(0,str(ROOT/'scripts'))
import atlas_assets as art
D=ROOT/'source-data';O=ROOT/'dist';read=lambda p:json.loads((D/p).read_text())
cfg=read('world-1280.json');core=read('core-map-0442.json');regional=read('regional-1280.json');campaign=read('core-campaign-0442.json')
W,H,TOP,PH=11200,6200,100,6000;WEST,EAST,SOUTH,NORTH=-26,148,-12,73
frame=box(WEST,SOUTH,EAST,NORTH);SX=(W-240)/(EAST-WEST);SY=(PH-160)/(NORTH-SOUTH)
def xy(p):return 120+(p[0]-WEST)*SX,TOP+80+(NORTH-p[1])*SY
def esc(s):return html.escape(str(s),quote=True)
def slug(s):return re.sub('[^a-z0-9]+','-',unicodedata.normalize('NFKD',s.replace('ı','i')).encode('ascii','ignore').decode().lower()).strip('-')
def polygons(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 if hasattr(g,'geoms'):return [p for q in g.geoms for p in polygons(q)]
 return []
def clean(g):return unary_union(polygons(make_valid(g)))
def gpath(g):
 if g.is_empty:return ''
 if g.geom_type=='Polygon':return ' '.join('M'+'L'.join(f'{x:.1f},{y:.1f}' for x,y in map(xy,r.coords))+'Z' for r in [g.exterior,*g.interiors])
 if g.geom_type in ['LineString','LinearRing']:return 'M'+'L'.join(f'{x:.1f},{y:.1f}' for x,y in map(xy,g.coords))
 if hasattr(g,'geoms'):return ' '.join(gpath(q) for q in g.geoms)
 return ''
def bounds(g):
 a,b,c,d=g.bounds;x1,y1=xy((a,d));x2,y2=xy((c,b));return [x1,y1,x2,y2]
land=clean(unary_union([shape(f['geometry']).intersection(frame) for f in read('land.geojson')['features']])).simplify(.006,preserve_topology=True)
water=clean(unary_union([shape(f['geometry']).intersection(frame) for f in read('ne_50m_lakes.geojson')['features'] if f['properties'].get('featurecla')!='Reservoir']))
land=clean(land.difference(water));coast=land.boundary
dated=read('cliopatria-1280.geojson')['features'];nearby=read('cliopatria-1294-reference.geojson')['features']
def reference(names):
 return clean(unary_union([shape(f['geometry']) for f in dated if f['properties']['Name'] in names]+[shape(f['geometry']) for f in nearby if f['properties']['Name'] in names and not any(v['properties']['Name']==f['properties']['Name'] for v in dated)]).intersection(frame))
coregeom=read('core-provinces-0442.geojson')['features']
raw={n['id']:clean(unary_union([shape(f['geometry']) for f in coregeom if f['properties']['owner']==n['id']])) for n in core['regions']}
raw['ilkhan']=clean(raw['ilkhan'].union(reference(['Ilkhanate'])))
raw['venice']=clean(raw['venice'].union(reference(['Republic of Venice'])))
for cid,names in {'byzantine':['Byzantine Empire'],'bulgaria':['Second Bulgarian Empire'],'serbia':['Kingdom of Serbia'],'cilicia':['Armenian Kingdom of Cilicia'],'trebizond':['Empire of Trebizond'],'epirus':['Despotate of Epirus'],'thessaly':['Thessaly'],'athens':['Duchy of Athens']}.items():
 g=reference(names).intersection(land)
 if not g.is_empty:raw[cid]=clean(g)
core_asia={'ilkhan','seljuk','cilicia','trebizond','cyprus','georgia','tripoli','jerusalem'}
countries=[dict(n,continent='Afrika' if n['id']=='mamluk' else 'Asya' if n['id'] in core_asia else 'Avrupa') for n in core['regions']]+cfg['countries'];byid={n['id']:n for n in countries}
locations=[dict(p) for p in core['provinces']]
byid['venice']['capital']={'name':'Venedik','city':'Venedik','visible':True}
byid['venice']['name']='Venedik Cumhuriyeti'
locations.append({'name':'Venedik','lon':12.335,'lat':45.44,'owner':'venice','port':True,'fort':'Liman tahkimatı','capital':True,'id':'pr-venedik','major':True,'absorbed':[]})
locations.append({'name':'Skálholt','lon':-20.526,'lat':64.126,'owner':'norway','port':True,'fort':'','capital':False,'id':'pr-skalholt','major':True,'absorbed':[]})
# More named cities complete the old frame's previously cropped eastern state.
for name,lon,lat,port in [('Bağdat',44.37,33.32,False),('Sultaniye',48.8,36.43,False),('İsfahan',51.68,32.65,False),('Şiraz',52.58,29.61,False),('Herat',62.2,34.35,False),('Nişabur',58.8,36.21,False),('Yezd',54.37,31.9,False),('Hemedan',48.52,34.8,False)]:
 locations.append({'name':name,'lon':lon,'lat':lat,'owner':'ilkhan','port':port,'fort':'Şehir tahkimatı','capital':False,'id':'pr-'+slug(name),'major':True,'absorbed':[]})
for n in cfg['countries']:
 g=reference(n['geometry_names'])
 if 'mask'in n and (g.is_empty or n['id'] in ['goryeo','tibet','kaidu']):
  # Researched regional masks supply polities absent from the dated dataset.
  # They are explicitly approximate, never a modern country polygon.
  mask=box(*n['mask']);a,b,c,d=n['mask'];
  if n['id']=='kaidu':mask=Polygon([(77.3,46.1),(79.0,48.8),(83,50.1),(87.0,49.1),(90.1,47.2),(92.9,46.1),(91.7,43.5),(88.3,42.9),(84.0,43.8),(81.8,43.2),(78.6,44.8)]).buffer(.1)
  if n['id']=='tibet':mask=Polygon([(78.5,33.5),(80.5,35),(84.5,35.3),(89.2,35),(94.1,34.1),(97.1,32.8),(99.8,31.2),(98.5,29.2),(95.4,27.5),(92,27.4),(88.2,28.2),(84.2,29.5),(81.1,31.1)]).buffer(.1)
  if n['id'] not in ['goryeo','tibet','kaidu']:
   mask=Polygon([(a+(c-a)*.12,b+(d-b)*.18),(a+(c-a)*.35,b),(c-(c-a)*.17,b+(d-b)*.09),(c,b+(d-b)*.4),(c-(c-a)*.06,d-(d-b)*.17),(a+(c-a)*.63,d),(a+(c-a)*.2,d-(d-b)*.05),(a,b+(d-b)*.55)]).buffer(.15)
  if n['id'] in ['goryeo','tibet','kaidu']:g=reference(['Yuan Dynasty','Chagatai Khanate','Golden Horde']).intersection(mask)
  else:g=mask
 if g.is_empty:
  points=[Point(p['lon'],p['lat']) for p in n['locations']];g=unary_union(points).convex_hull.buffer(.5)
 raw[n['id']]=clean(g.intersection(land))
 for p in n['locations']:
  locations.append(dict(p,id='pr-'+slug(p['name']),owner=n['id'],capital=p['name']==n['capital'],major=True,absorbed=[]))
# Date corrections and generic regional extents should not import later maxima.
raw['sukhothai']=raw['sukhothai'].intersection(box(98.7,16.4,100.6,18.4))
raw['england']=clean(raw['england'].difference(box(-11,51.0,-6.65,55.8)))
# No unsupported late foundation of Cairo's new capital in Iran in 1280.
locations=[p for p in locations if p['name']!='Sultaniye']
assert len({p['id'] for p in locations})==len(locations),'Duplicate city slug'
# Small, separately governed places override surrounding imperial aggregates.
def priority(n):
 if n['id'] in ['yuan','goldenhorde','ilkhan','hre','france','mamluk']:return (0,-raw[n['id']].area)
 if n['id'] in [c['id'] for c in core['regions']]:return (3,-raw[n['id']].area)
 return (2,-raw[n['id']].area)
owned={};occupied=Polygon()
for n in reversed(sorted(countries,key=priority)):
 g=clean(raw[n['id']].difference(occupied));owned[n['id']]=g;occupied=clean(occupied.union(g))
# Respect the documented city allegiance when coarse source outlines disagree.
# Each repair is recorded; it never silently changes a claimed high-precision border.
repairs=[]
for p in locations:
 pt=Point(p['lon'],p['lat']);owner=p['owner'];dist=owned[owner].distance(pt)
 if dist>.008:
  control=pt.buffer(.23).intersection(land)
  if control.is_empty:control=land.intersection(pt.buffer(.65))
  if control.is_empty:raise ValueError('No land around city '+p['name'])
  for key in owned:
   if key!=owner and owned[key].intersects(control):owned[key]=clean(owned[key].difference(control))
  owned[owner]=clean(owned[owner].union(control));repairs.append({'city':p['name'],'owner':owner,'source_distance_degrees':round(dist,3),'kind':'approximate city control correction'})
occupied=clean(unary_union(list(owned.values())))
for k,g in owned.items():assert not g.is_empty,k
# Determine city catchments within each researched polity, including islands.
COS=math.cos(math.radians(32));project=lambda x,y,z=None:(x*COS,y);unproject=lambda x,y,z=None:(x/COS,y)
province_shapes={};provinces=[]
for n in countries:
 group=[p for p in locations if p['owner']==n['id']];territory=owned[n['id']]
 if len(group)==1:cells=[(group[0],territory)]
 else:
  seeds=[Point(p['lon']*COS,p['lat']) for p in group]
  diagram=voronoi_diagram(MultiPoint(seeds),envelope=box(WEST*COS-10,SOUTH-10,EAST*COS+10,NORTH+10))
  cells=[]
  for cell in diagram.geoms:
   candidates=[i for i,p in enumerate(seeds) if cell.covers(p)]
   assert len(candidates)==1,('Voronoi site',n['id'],candidates)
   cells.append((group[candidates[0]],clean(transform(unproject,cell).intersection(territory))))
 for p,g in cells:
  if g.is_empty:raise ValueError('Empty city region '+p['name'])
  province_shapes[p['id']]=g
  p=dict(p);p['neighbours']=[];p['map_x'],p['map_y']=xy((p['lon'],p['lat']));p['coastal']=coast.distance(Point(p['lon'],p['lat']))<.55;p.setdefault('port',False);p.setdefault('fort','');p.setdefault('control','Yaklaşık 1280 şehir çevresi');p['terrain_class']='plain';p.setdefault('terrain','Ova');provinces.append(p)
provinces.sort(key=lambda p:(list(byid).index(p['owner']),not p['capital'],p['name']))
P={p['id']:p for p in provinces}
for i,a in enumerate(provinces):
 ga=province_shapes[a['id']]
 for b in provinces[i+1:]:
  gb=province_shapes[b['id']]
  if ga.distance(gb)<.012 and ga.boundary.intersection(gb.buffer(.014)).length>.025:
   a['neighbours'].append(b['id']);b['neighbours'].append(a['id'])
# Preserve the local travel network for campaign orders already in progress.
for p in core['provinces']:
 for q in p['neighbours']:
  if q not in P[p['id']]['neighbours']:P[p['id']]['neighbours'].append(q)
  if p['id'] not in P[q]['neighbours']:P[q]['neighbours'].append(p['id'])
for p in provinces:p['neighbours'].sort()
chains=[('PİRENELER',[(-1.7,43),(.4,42.7),(2.5,42.5)]),('ALPLER',[(5.6,45.3),(7.5,46.1),(10.4,46.6),(13.6,46.4)]),('KARPATLAR',[(18.5,49.5),(22.5,48.3),(25.8,46.8),(25.4,45.2),(22,44.9)]),('ATLAS',[(-9,30),(-6,32),(-3.5,33.3),(1.5,35)]),('TOROSLAR',[(29.4,36.8),(32,37.3),(35.5,37.8),(37,38.4)]),('PONTUS',[(30,41),(34.5,40.9),(39.5,40.7),(41,41)]),('KAFKASLAR',[(39.5,43.2),(42.5,43.5),(46,42)]),('ZAGROS',[(44,36),(47.3,34),(50,30),(54,27.8)]),('ELBURZ',[(48.5,36.7),(52,36.5),(55,37)]),('HİNDİKUŞ',[(65,35),(69,36),(73,36.4)]),('TANRI DAĞLARI',[(70,42),(75,42.5),(80,43),(86,43)]),('ALTAY',[(83,48),(88,49.5),(94,50)]),('HİMALAYA',[(73,35),(78,32),(84,29.3),(89,27.8),(95,28.5)]),('KUNLUN',[(77,36.5),(85,35.6),(93,35.5)]),('BATI GATLAR',[(73,19),(74.5,15.5),(76,11),(77,9)]),('HABEŞ YAYLALARI',[(38,14),(39,11.5),(39,9)]),('JAPON ALPLERİ',[(136,35.5),(138,36.5),(140,39)]),('BALKAN DAĞLARI',[(21,41),(23,42.5),(26,42.8)]),('ARAKAN',[(93.4,19),(94,22),(96,25.5)]),('ANNAM',[(104.5,20),(106,17),(107.5,14)]),('TIBESTİ',[(16,19),(18,21),(20,22)]),('AKKAGAR',[(4,22),(6,24),(8,24.8)])]
forest_zones=[box(-5,47,25,56),box(9,57,32,65),box(28,55,100,61),box(93,16,107,26),box(101,-5,118,7),box(127,30,142,42)]
desert_zones=[box(-17,18,29,29),box(40,18,58,30),box(53,29,62,35),box(77,37,91,41),box(96,40,110,45)]
for p in provinces:
 pt=Point(p['lon'],p['lat']);ridge=min(LineString(line).distance(pt) for _,line in chains)
 terrain='mountain' if ridge<.65 else 'hill' if ridge<1.3 else 'desert' if any(z.covers(pt) for z in desert_zones) else 'forest' if any(z.covers(pt) for z in forest_zones) else 'plain'
 if p['id'] in {q['id'] for q in core['provinces']}:
  t=p.get('terrain','');terrain='marsh' if p['id'] in ['pr-dimyat','pr-gazze'] else 'desert' if p['name'] in ['Kahire','Kus','Asvan','Medine','Mekke','Kerek'] else 'forest' if p['name'] in ['Kastamonu','Samsun'] else 'mountain' if 'Dağ'in t or 'Toros'in t else 'hill' if any(v in t for v in ['Tepe','Engeb','Plato']) else 'plain'
 p['terrain_class']=terrain;p['terrain']={'mountain':'Dağlık','hill':'Engebeli / tepe','desert':'Çöl / vaha','forest':'Ormanlık','plain':'Ova','marsh':'Bataklık / delta'}[terrain]

# Enrich profiles without reintroducing the disabled dynasty gameplay.
culture_labels={'english':'İngiliz','scottish':'İskoç / Gal','welsh':'Gal','french':'Fransız / Oksitan','castilian':'Kastilyalı','catalan':'Katalan / Aragon','portuguese':'Portekizli','basque':'Bask / Navar','german':'Alman','czech':'Çek','hungarian':'Macar','norse':'İskandinav','norwegian':'Norveçli','swedish':'İsveçli','danish':'Danimarkalı','prussian':'Prus / Baltık','polish':'Leh','lithuanian':'Litvan','russian':'Rus','ruthenian':'Ruten','italian':'İtalyan','sardinian':'Sard','maghrebi':'Mağripli / Berberî','manding':'Mande','kanuri':'Kanuri','ethiopian':'Habeş','shewan':'Şeva','kipchak':'Kıpçak','chagatai':'Çağatay / Türkî','han':'Han Çinlisi','korean':'Koreli','tibetan':'Tibetli','japanese':'Japon','hindustani':'Hindustanlı','marathi':'Marathi','kannada':'Kannada','telugu':'Telugu','tamil':'Tamil','oriya':'Oriya','gujarati':'Guceratlı','newar':'Newar','sinhala':'Sinhala','burmese':'Birmanyalı','tai':'Tai','mon':'Mon','khmer':'Khmer','vietnamese':'Vietnamlı','cham':'Çam','malay':'Malay','javanese':'Cavalı','sundanese':'Sundalı'}
for n in cfg['countries']:
 c=n['culture'];campaign['cultures'].setdefault(c,{'name':culture_labels.get(c,c.replace('_',' ').title()),'color':n['color']})
 ruler={k:v for k,v in n['ruler'].items() if k in ['name','title','from']}
 campaign['profiles'][n['id']]={'culture':c,'accepted':[c],'summary':n['summary']+' '+n['note'],'milestones':[{'year':1280,'text':'Başlangıç: '+n['name']+'. '+n['note']}],'rulers':[ruler],'sources':n['sources'],'court':[],'dynasty':n['short']+' idaresi'}
campaign['coverage']='Başlangıç: Ocak 1280. Eski bölgenin olay akışı 1335’e kadar; yeni alanlarda kaynaklı başlangıç ve genel devlet simülasyonu.'
campaign['cultureNote']='Topluluk oranları tarihî nüfus sayımı değildir; bölgesel kültür anahtarları oyun senaryosu sınıflandırmalarıdır.'
# Generic non-national era-inspired seals for new states, with explicit labeling.
for i,n in enumerate(cfg['countries']):
 art.HERALDRY[n['id']]=(n['color'],'#5d4e34','Temsilî 1280 oyun mührü; tarihî resmî bayrak değildir')
 art.MOTIFS[n['id']]=['<path d="M0-28 9-9 28 0 9 9 0 28-9 9-28 0-9-9Z" fill="currentColor"/>',art.EAGLE,art.LION][i%3]

# Public geography and scenario metadata.
public=[]
for n in countries:
 group=[p for p in provinces if p['owner']==n['id']];r={k:v for k,v in n.items() if k not in ['geometry_names','mask','locations','ruler']};r['capital']={'name':n['capital'] if isinstance(n['capital'],str) else n['capital']['name'],'city':n['capital'] if isinstance(n['capital'],str) else n['capital']['city'],'visible':True};r['province_count']=len(group);r['ports']=sum(bool(p['port']) for p in group);r['forts']=sum(bool(p['fort']) for p in group);r['map_bbox']=bounds(owned[n['id']]);r['label_anchor']=list(xy((owned[n['id']].representative_point().x,owned[n['id']].representative_point().y)));r['area']=round(owned[n['id']].area,2);r['note']=n.get('note','');r['text']=n.get('summary',n.get('text',''));r['emblem_note']=art.HERALDRY[n['id']][2];public.append(r)
views=[('all','Bütün harita',frame),('europe','Avrupa',box(-12,34,44,67)),('anatolia','Anadolu',box(23,32,48,45)),('africa','Afrika',box(-19,6,49,37)),('asia','Asya',box(45,4,144,58)),('eastasia','Doğu Asya',box(100,18,144,49)),('india','Hindistan',box(66,5,92,36))]
sea_pairs=[]
explicit=[('Londra','Rouen'),('Exeter','Bordeaux'),('Dublin','Exeter'),('Aberdeen','Bergen'),('Oslo','Roskilde'),('Stockholm','Åbo'),('Stockholm','Reval'),('Lund','Gdańsk'),('Ceneviz','Barselona'),('Ceneviz','Pisa'),('Palma','Barselona'),('Palma','Valencia'),('Palma','Málaga'),('Palermo','Napoli'),('Messina','Bari'),('Palermo','Tunus'),('Cagliari','Pisa'),('Cagliari','Palma'),('Tanca','Málaga'),('Tunus','Trablusgarp'),('Trablusgarp','İskenderiye'),('Venedik','Bari'),('Venedik','Kandiye'),('Venedik','Dıraç'),('Ceneviz','Kaffa'),('Kaffa','Konstantinopolis'),('Kayal','Dambadeniya'),('Khambhat','Suhar'),('Suhar','Eski Hürmüz'),('Maskat','Aden'),('Aden','Cidde'),('Quanzhou','Guangzhou'),('Quanzhou','Hakata'),('Hakata','Gyeongju'),('Hakata','Kamakura'),('Gyeongju','Gaegyeong'),('Guangzhou','Thiên Trường'),('Thiên Trường','Kauthara'),('Kauthara','Panduranga'),('Pegu','Kedah'),('Kedah','Palembang'),('Palembang','Tuban'),('Palembang','Banten'),('Banten','Tuban')]
byname={p['name']:p['id'] for p in provinces}
explicit.append(('Bergen','Skálholt'))
for a,b in explicit:
 if a in byname and b in byname:sea_pairs.append([byname[a],byname[b]])
# Add the maritime Venetian home city that was outside the old frame.
if 'Venedik' not in byname:
 # Already generated geometry cannot be mutated here. The main port in Crete
 # remains the capital of the inherited map until additional cities are curated.
 pass
payload={'year':1280,'regions':public,'provinces':provinces,'sources':core['sources']+cfg['sources'],'notes':{'provinces':'Şehir çevreleri oyun bölgeleridir; tarihî idarî sınırlar değildir.','emblems':'Yeni mühürler temsilî dönem motifleridir; resmî bayrak iddiası yok.','sites':cfg['extent_note']},'map':{'revision':cfg['revision'],'width':W,'height':H,'top':TOP,'plot_height':PH,'views':[{'id':i,'name':n,'bbox':bounds(g)} for i,n,g in views]},'aliases':core.get('aliases',{}),'stats':{'provinces':len(provinces),'countries':len(public),'ports':sum(bool(p['port']) for p in provinces),'land_edges':sum(len(p['neighbours']) for p in provinces)//2},'method':cfg['extent_note'],'seaPairs':sea_pairs,'legacyScenario':core,'initialOverlords':{n['id']:n['overlord'] for n in cfg['countries'] if n.get('overlord')},'cartography':{'border_note':'Tarihî denetim alanları yaklaşık; 1294 verisinden uyarlanan hanlık uçları ve şehir denetimi düzeltmeleri belgelidir.','sources':cfg['sources'],'city_repairs':repairs}}
campaign['characters']=read('characters-1280.json')
(O/'world-map-data.json').write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')))
(D/'world-campaign-1280.json').write_text(json.dumps(campaign,ensure_ascii=False,indent=2))
(O/'world-provinces.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','id':p['id'],'properties':{'id':p['id'],'owner':p['owner'],'name':p['name']},'geometry':mapping(province_shapes[p['id']])} for p in provinces]},ensure_ascii=False,separators=(',',':')))

lp=gpath(land);province_lines=unary_union([g.boundary for g in province_shapes.values()]);frontiers=unary_union([g.boundary for g in owned.values()])
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" id="historical-map" class="world-atlas" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="map-title map-desc"><title id="map-title">Anadolu 1280 — Avrupa, Asya ve Afrika Atlası</title><desc id="map-desc">{len(public)} siyasi alan, {len(provinces)} adlandırılmış şehir çevresi. Kıyılar, nehirler, dağlar ve geçitler. Siyasi sınırlar kaynak karşılaştırmalı yaklaşık gösterimdir.</desc>']
svg.append('''<defs><linearGradient id="world-sea" x2=".2" y2="1"><stop stop-color="#527b87"/><stop offset=".5" stop-color="#73939a"/><stop offset="1" stop-color="#406c7b"/></linearGradient><linearGradient id="world-paper" x2=".7" y2="1"><stop stop-color="#e8dfbf"/><stop offset=".6" stop-color="#d7c99e"/><stop offset="1" stop-color="#cabb91"/></linearGradient><pattern id="world-grain" width="39" height="43" patternUnits="userSpaceOnUse"><path d="M3 4h2m13 16 1 1m16-12v2m-4 27h1m-22-9h1" stroke="#68523b" stroke-width=".7" opacity=".13"/></pattern><pattern id="world-desert" width="34" height="25" patternUnits="userSpaceOnUse"><path d="m3 18 9-2 8 2m9-12 4-1" fill="none" stroke="#b28d54" stroke-width="1.3" opacity=".32"/></pattern><pattern id="world-forest" width="29" height="31" patternUnits="userSpaceOnUse"><path d="m8 4-5 9h3l-4 8h12l-4-8h3Z" fill="#6a805b" opacity=".28"/><path d="M8 18v6" stroke="#5e694b" stroke-width="1" opacity=".25"/></pattern><pattern id="world-subject" width="17" height="17" patternTransform="rotate(35)" patternUnits="userSpaceOnUse"><path d="M1 0V17" stroke="#7c674c" stroke-width="1.6" opacity=".25"/></pattern>''')
svg.append(f'<path id="world-land" d="{lp}"/><clipPath id="world-land-clip"><use href="#world-land"/></clipPath><clipPath id="world-frame"><rect y="{TOP}" width="{W}" height="{PH}"/></clipPath></defs>')
svg.append(art.defs());svg.append('<style>'+(ROOT/'src/game-world-map.css').read_text()+'</style>')
svg.append(f'<rect width="{W}" height="{H}" fill="#dacba5"/><g clip-path="url(#world-frame)"><rect y="{TOP}" width="{W}" height="{PH}" fill="url(#world-sea)"/>')
svg.append('<g class="world-graticule">')
for lon in range(-20,150,10):x1,y1=xy((lon,SOUTH));x2,y2=xy((lon,NORTH));svg.append(f'<path d="M{x1:.1f},{y1:.1f}L{x2:.1f},{y2:.1f}"/>')
for lat in range(-10,74,10):x1,y1=xy((WEST,lat));x2,y2=xy((EAST,lat));svg.append(f'<path d="M{x1:.1f},{y1:.1f}L{x2:.1f},{y2:.1f}"/>')
svg.append('</g>')
for width,op in [(26,.1),(13,.18),(5,.38)]:svg.append(f'<use href="#world-land" fill="url(#world-paper)" stroke="#c2d0bc" stroke-width="{width}" stroke-opacity="{op}"/>')
svg.append('<use href="#world-land" fill="url(#world-paper)"/>')
for n in countries:svg.append(f'<path class="world-country-base" data-country="{n["id"]}" fill="{n["color"]}" d="{gpath(owned[n["id"]])}" fill-rule="evenodd"/>')
for p in provinces:svg.append(f'<path class="province" data-province="{p["id"]}" data-owner="{p["owner"]}" role="button" tabindex="0" aria-label="{esc(p["name"])} — {esc(byid[p["owner"]]["name"])}" fill="{byid[p["owner"]]["color"]}" d="{gpath(province_shapes[p["id"]])}"><title>{esc(p["name"])} — {esc(byid[p["owner"]]["name"])}</title></path>')
svg.append('<g class="world-physical" clip-path="url(#world-land-clip)">')
if (D/'world-relief.webp').exists():
 x,y=xy((WEST,NORTH));xx,yy=xy((EAST,SOUTH));img=base64.b64encode((D/'world-relief.webp').read_bytes()).decode()
 svg.append(f'<image class="world-relief-raster" x="{x}" y="{y}" width="{xx-x}" height="{yy-y}" preserveAspectRatio="none" href="data:image/webp;base64,{img}"/>')
for zone in desert_zones:svg.append(f'<path d="{gpath(zone)}" fill="url(#world-desert)" opacity=".55"/>')
for zone in forest_zones:svg.append(f'<path d="{gpath(zone)}" fill="url(#world-forest)" opacity=".35"/>')
random.seed(1280)
for title,line in chains:
 g=LineString(line);ridge=g.buffer(.35)
 svg.append(f'<path class="world-ridge-shadow" d="{gpath(ridge)}"/>')
 shadow=[];tops=[]
 for a,b in zip(line,line[1:]):
  length=math.hypot((b[0]-a[0])*SX,(b[1]-a[1])*SY);steps=max(1,int(length/17))
  for i in range(steps):
   t=(i+.3)/steps;lon=a[0]+(b[0]-a[0])*t;lat=a[1]+(b[1]-a[1])*t
   if not land.covers(Point(lon,lat)):continue
   x,y=xy((lon,lat));hh=random.uniform(13,27);ww=hh*.7
   tops.append(f'M{x-ww:.1f},{y+7:.1f}L{x:.1f},{y-hh:.1f}L{x+ww:.1f},{y+7:.1f}Z');shadow.append(f'M{x:.1f},{y-hh:.1f}L{x+3:.1f},{y+6:.1f}L{x+ww:.1f},{y+7:.1f}Z')
 svg.append('<path class="world-mountains" d="'+' '.join(tops)+'"/><path class="world-mountain-shadow" d="'+' '.join(shadow)+'"/>')
 mid=g.interpolate(.5,normalized=True);x,y=xy((mid.x,mid.y));svg.append(f'<text class="world-range-name" x="{x:.1f}" y="{y+42:.1f}">{title}</text>')
svg.append('</g>')
rivers=[]
for f in read('ne_50m_rivers_lake_centerlines.geojson')['features']:
 rank=f['properties'].get('scalerank',7)
 if rank is not None and rank<=6:
  g=shape(f['geometry']).intersection(frame)
  if not g.is_empty:rivers.append(g)
svg.append(f'<path class="world-rivers" d="{gpath(unary_union(rivers))}"/><path class="world-water" d="{gpath(water)}"/>')
svg.append(f'<path class="world-province-lines" d="{gpath(province_lines)}"/><path class="world-initial-borders" d="{gpath(frontiers)}"/><use href="#world-land" class="world-coastline"/><rect y="{TOP}" width="{W}" height="{PH}" fill="url(#world-grain)" pointer-events="none"/>')
for title,x,y in [('ATLAS OKYANUSU',-20,40),('KUZEY DENİZİ',2,57),('AKDENİZ',16,34),('KARADENİZ',34,44),('HAZAR DENİZİ',51,41),('KIZILDENİZ',36,20),('HİNT OKYANUSU',70,0),('BENGAL KÖRFEZİ',88,13),('GÜNEY ÇİN DENİZİ',114,15),('JAPON DENİZİ',135,41),('BÜYÜK OKYANUS',143,22)]:
 x,y=xy((x,y));svg.append(f'<text class="world-sea-label" x="{x:.1f}" y="{y:.1f}">{title}</text>')
for title,x,y in [('SAHRA',10,25),('SÁPMI',24,68),('SİBİRYA',89,61),('ARAP YARIMADASI',45,23),('TİBET PLATOSU',86,32)]:
 x,y=xy((x,y));svg.append(f'<text class="world-context-label" x="{x:.1f}" y="{y:.1f}">{title}</text>')
svg.append('<g class="world-static-labels">')
for n in public:
 x,y=n['label_anchor'];svg.append(f'<text class="map-label-text" x="{x:.1f}" y="{y:.1f}" text-anchor="middle">{esc(n["short"])}</text>')
svg.append('</g><g class="cities-layer">')
placed=[]
for p in sorted(provinces,key=lambda p:not p['capital']):
 x,y=p['map_x'],p['map_y'];font=25 if p['capital'] else 22;width=len(p['name'])*font*.55;pos=(18,25,'start')
 for dx,dy,anchor in [(18,25,'start'),(-18,25,'end'),(18,-23,'start'),(-18,-23,'end'),(0,49,'middle'),(0,-40,'middle'),(45,4,'start'),(-45,4,'end')]:
  left=x+dx-(width if anchor=='end' else width/2 if anchor=='middle' else 0);r=box(left-2,y+dy-font,left+width+2,y+dy+4)
  if not any(r.intersects(q) for q in placed):pos=(dx,dy,anchor);break
 placed.append(r);dx,dy,anchor=pos
 svg.append(f'<g class="city-node {"capital-node" if p["capital"] else ""}" data-province="{p["id"]}" role="button" tabindex="0" aria-label="{esc(p["name"])} merkezi" transform="translate({x:.1f} {y:.1f})"><circle r="19" fill="transparent"/>')
 if abs(dy)>30 or abs(dx)>30:svg.append(f'<path class="world-city-leader" d="M0,0L{dx},{dy-9}"/>')
 size=34 if p['capital'] else 27
 svg.append(f'<use class="city-sprite" href="#{"site-capital" if p["capital"] else "site-city"}" x="{-size/2}" y="{-size*.75}" width="{size}" height="{size}"/>')
 if p['port']:svg.append('<use class="port-mark" href="#site-port" x="12" y="0" width="18" height="21"/>')
 if p['fort']:svg.append('<use class="fort-mark" href="#site-fort" x="-29" y="0" width="17" height="21"/>')
 svg.append(f'<text class="city-label" x="{dx}" y="{dy}" text-anchor="{anchor}">{esc(p["name"])}</text></g>')
svg.append('</g></g>')
svg.append(f'<g class="export-only"><text x="125" y="66" font-family="Georgia,serif" font-size="45" fill="#655337" letter-spacing="8">ANADOLU 1280 · BÜYÜK ATLAS</text><text x="{W-125}" y="66" text-anchor="end" font-size="26" fill="#655337">AVRUPA · ASYA · AFRİKA</text><text x="125" y="{H-36}" font-size="22" fill="#655337">{len(public)} siyasi alan · {len(provinces)} şehir çevresi · Siyasi sınırlar yaklaşık; şehir bölgeleri oyun tasarımıdır.</text><text x="{W-125}" y="{H-36}" text-anchor="end" font-size="21" fill="#655337">Cliopatria / Seshat · CC BY 4.0, uyarlanmıştır · Natural Earth</text></g></svg>')
(O/'world-map.svg').write_text(''.join(svg))
edges=[]
for p in provinces:
 for j in p['neighbours']:
  if p['id']>j:continue
  g=province_shapes[p['id']].boundary.intersection(province_shapes[j].buffer(.014))
  if not g.is_empty:edges.append({'a':p['id'],'b':j,'path':gpath(g)})
(O/'world-game-edges.json').write_text(json.dumps({'shared':edges,'outer':gpath(occupied.boundary.difference(coast.buffer(.001)))},separators=(',',':')))
(D/'world-research/geometry-audit.json').write_text(json.dumps({'countries':len(public),'provinces':len(provinces),'city_allegiance_repairs':repairs,'source':'Cliopatria v0.2.1, January1280 selection; 1294 explicitly referenced for successor khanates and select missing polities.','geometry':'No modern administrative border dataset used; 50m physical land clip. City cells are Voronoi game regions.'},ensure_ascii=False,indent=2))
print(json.dumps(payload['stats']|{'svg_kib':(O/'world-map.svg').stat().st_size//1024,'city_repairs':len(repairs)},ensure_ascii=False))

# Apply the user-selected visible scope and lightweight display geometry.
import subprocess
subprocess.run([sys.executable,str(ROOT/"scripts/refine-known-world.py")],check=True)
