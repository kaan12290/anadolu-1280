/* Conserved casualty pools, captives and gradual political military revolts. */
(function(root){
'use strict';
function createConflict(E){
 const {P,N,C,ids,nids,armies,own,capital,units,clamp,log,newArmy,sync}=E,G=E.statecraft,T=E.politics,kinds=Object.keys(units),sum=G.sum,empty=G.empty;
 const add=(to,from)=>{for(const u of kinds)to[u]+=from[u]},copy=u=>Object.fromEntries(kinds.map(k=>[k,u[k]]));
 function initialize(s){s.conflictVersion=1;s.prisoners??=[];s.nextPrisoner??=1;s.rebelArmies??=[];s.nextRebel??=1;
  for(const n of nids){s.nations[n].casualties??={wounded:empty(),dead:empty(),deserted:empty()};for(const a of [...s.nations[n].commanders,...s.nations[n].council,...s.lords.filter(l=>l.owner===n)]){a.ultimatum??=null;a.rebelId??=null;a.lastContainment??=-12}}return s;
 }
 function partition(start,end,losing,civil=false){const categories={ready:copy(end),wounded:empty(),dead:empty(),prisoner:empty(),deserted:empty()};for(const u of kinds){const loss=start[u]-end[u];categories.wounded[u]=Math.floor(loss*.35);categories.prisoner[u]=0;categories.deserted[u]=Math.floor(loss*.1);categories.dead[u]=loss-categories.wounded[u]-categories.prisoner[u]-categories.deserted[u]}return categories}
 const counts=x=>Object.fromEntries(Object.entries(x).map(([k,u])=>[k,sum(u)]));
 function summarize(report,civil=false){report.casualtiesA=counts(partition(report.startA,report.endA,report.winnerArmy===report.defenderArmy,civil));report.casualtiesD=counts(partition(report.startD,report.endD,report.winnerArmy===report.attackerArmy,civil));return report}
 function addPrisoners(s,owner,captor,selection,rebel=false){if(!sum(selection))return;if(s.prisonersEnabled===false){add(s.nations[owner][rebel?'casualties':'reserveUnits']?.deserted||s.nations[owner].reserveUnits,selection);return}let p=s.prisoners.find(p=>p.owner===owner&&p.captor===captor&&p.rebel===rebel);if(!p){p={id:'captive-'+s.nextPrisoner++,owner,captor,rebel,units:empty(),since:s.turn};s.prisoners.push(p)}add(p.units,selection);return p}
 function recordPart(s,owner,captor,part,rebel=false){const q=s.nations[owner].casualties;add(q.wounded,part.wounded);add(q.dead,part.dead);add(q.deserted,part.deserted);addPrisoners(s,owner,captor,part.prisoner,rebel)}
 function afterBattle(s,report,attacker,defender){
  if(!s.armies.includes(attacker)){report.endA=empty();report.lossA=sum(report.startA)}if(!s.armies.includes(defender)){report.endD=empty();report.lossD=sum(report.startD)}
  const a=partition(report.startA,report.endA,report.winnerArmy===defender.id),d=partition(report.startD,report.endD,report.winnerArmy===attacker.id);
  recordPart(s,attacker.owner,defender.owner,a);recordPart(s,defender.owner,attacker.owner,d);report.casualtiesA=counts(a);report.casualtiesD=counts(d);
  if(sum(a.prisoner)+sum(d.prisoner))log(s,P[report.province].name+' sonrasında '+(sum(a.prisoner)+sum(d.prisoner))+' asker esir kaydedildi. Esirler orduya eklenmedi.','war');
 }
 function returnUnits(s,p,selection){if(p.rebel){add(s.nations[p.owner].casualties.deserted,selection)}else add(s.nations[p.owner].reserveUnits,selection)}
 function prune(s){s.prisoners=s.prisoners.filter(p=>sum(p.units)>0)}
 function release(s,p){returnUnits(s,p,p.units);p.units=empty();prune(s)}
 function returnPair(s,a,b){for(const p of [...s.prisoners])if(!p.rebel&&(p.owner===a&&p.captor===b||p.owner===b&&p.captor===a))release(s,p)}
 function take(pool,amount){const result=empty();for(const u of kinds){const x=Math.min(pool[u],amount);pool[u]-=x;result[u]=x;amount-=x}return result}
 function ransomQuote(s,p,payer=p.owner){const price=Math.ceil(sum(p.units)*.12),pay=s.nations[payer],held=s.nations[p.captor];return {price,accepted:!p.rebel&&pay.gold>=price&&(payer===s.player||!E.isWar(s,p.owner,p.captor)||armies(s,p.owner).reduce((v,a)=>v+a.troops,0)<armies(s,p.captor).reduce((v,a)=>v+a.troops,0)*1.2||held.exhaustion>40)}}
 function prisonerAction(s,a){if(s.prisonersEnabled===false)throw Error('Esir sistemi bu sürümde kapalı.');const n=s.player,p=s.prisoners.find(p=>p.id===a.prisoner);if(!p||p.captor!==n&&p.owner!==n)throw Error('Erişebildiğin mevcut esir grubunu seç.');
  if(a.type==='releasePrisoners'){if(p.captor!==n)throw Error('Yalnız tuttuğun esirleri bırakabilirsin.');release(s,p);log(s,'Esirler serbest bırakıldı; başka devletlerin askerleri kendi yedeklerine döndü.','good');return 'Esir grubu serbest bırakıldı.'}
  if(a.type==='ransomPrisoners'){const quote=ransomQuote(s,p);if(!quote.accepted)throw Error('Karşı taraf bu fidyeyi kabul etmiyor veya ödeme gücü yok.');s.nations[p.owner].gold-=quote.price;s.nations[p.captor].gold+=quote.price;release(s,p);log(s,'Fidye ödendi: '+quote.price+' altın; esirler kendi devletinin yedeğine iade edildi.','good');return 'Fidye ve asker iadesi tamamlandı.'}
  const other=p.captor===n?p.owner:p.captor,back=s.prisoners.find(x=>!x.rebel&&x.owner===n&&x.captor===other),foreign=s.prisoners.find(x=>!x.rebel&&x.owner===other&&x.captor===n);if(!back||!foreign||other===n)throw Error('Karşılıklı tutulan iki devlet esirleri gerekli.');const count=Math.min(sum(back.units),sum(foreign.units));returnUnits(s,back,take(back.units,count));returnUnits(s,foreign,take(foreign.units,count));prune(s);log(s,'Karşılıklı '+count+' esir değiştirildi. Askerler mevcut yedeklere döndü.','good');return count+' kişilik karşılıklı esir değişimi yapıldı.';
 }
 const actorRef=(s,n,kind,id)=>kind==='lord'?s.lords.find(l=>l.owner===n&&l.id===id):kind==='commander'?s.nations[n].commanders.find(c=>c.id===id):s.nations[n].council.find(c=>c.id===id);
 function startRebellion(s,n,kind,id,goal=null){if(E.stateMode(s))return false;const a=actorRef(s,n,kind,id),q=s.nations[n];if(!a||a.rebelId||s.rebelArmies.filter(r=>r.status==='active').length>=20)return false;
  const linkedCommander=kind==='commander'?id:kind==='lord'?a.commanderId:null;const source=linkedCommander?armies(s,n).find(x=>x.commander===linkedCommander&&s.provinces[x.province].owner===n&&!s.provinces[x.province].rebellion):null;
  const province=source?.province||(kind==='lord'?G.cities(s,a).find(id=>!s.provinces[id].rebellion)||a.claims?.find(id=>s.provinces[id].owner===n&&!s.provinces[id].rebellion):null),pool=source?.units||(kind==='lord'?a.units:null);if(!province||!pool)return false;
  const share=clamp((100-a.loyalty)*.003+a.influence*.003-q.authority*.002,.12,.55),selection=Object.fromEntries(kinds.map(u=>[u,Math.floor(pool[u]*share)]));if(sum(selection)<300)return false;
  const independent=n==='seljuk'&&C.futureNations.some(f=>f.claims.includes(province)&&!own(s,f.id).length);if(goal==='independence'&&!independent)return false;
  const chosen=goal||(independent&&a.ambition>85?'independence':a.ambition>85?'throne':kind==='lord'?'autonomy':'office');
  const r={id:'rebel-'+s.nextRebel++,owner:n,kind,actor:id,province,goal:chosen,units:selection,wounded:empty(),morale:70,supply:65,started:s.turn,status:'active',treasury:kind==='lord'?Math.floor(a.treasury*.5):0};
  for(const u of kinds)pool[u]-=selection[u];if(source){sync(source);source.commander=null;source.path=[];source.siege=null;source.progress=0}if(kind==='lord')a.treasury-=r.treasury;
  a.rebelId=r.id;a.demand=null;if(q.chiefCommander===id)q.chiefCommander=null;s.rebelArmies.push(r);s.rebelArmies=s.rebelArmies.filter(x=>x.status==='active'||s.turn-x.started<120).slice(-40);
  const p=s.provinces[province];p.rebellion={culture:E.dominant(p),forces:sum(r.units),started:s.turn,cause:'military',rebelId:r.id};p.building=null;p.recruit=null;
  log(s,a.name+' askerî isyan başlattı: '+P[province].name+'. Mevcut birliklerden '+sum(r.units)+' asker ayrıldı; bütün ordu katılmadı.','war');return r;
 }
 function finish(s,r){r.status='resolved';const p=s.provinces[r.province];if(p.rebellion?.rebelId===r.id){p.rebellion=null;p.organization=0}const a=actorRef(s,r.owner,r.kind,r.actor);if(a){a.rebelId=null;a.ultimatum=null;a.opposition=0;a.lastDemand=s.turn;a.loyalty=Math.max(a.loyalty,50)}}
 function independence(s,r){const b=C.futureNations.find(f=>f.claims.includes(r.province)&&!own(s,f.id).length);if(r.owner!=='seljuk'||!b)throw Error('Bu isyan için bağımsız beylik koşulları yok.');const p=s.provinces[r.province],q=s.nations[b.id];p.owner=b.id;p.governor=null;p.unrest=20;q.capital=r.province;q.baseIncome=55;q.gold+=r.treasury;r.treasury=0;add(q.reserveUnits,r.units);add(q.casualties.wounded,r.wounded);r.units=empty();r.wounded=empty();s.truces[E.key(r.owner,b.id)]=s.turn+24;finish(s,r);log(s,b.name+' bağımsız yönetim kurdu; asker ve hazine mevcut isyancı kaynaklarından devredildi.','war')}
 function fightRebellion(s,r,armyId=null){const n=r.owner,a=armies(s,n).find(a=>a.id===armyId&&a.province===r.province)||armies(s,n).find(a=>a.province===r.province);if(!a||a.troops<100)throw Error('İsyan şehrine kendi ordunu getir.');
  const d={id:r.id,owner:n,province:r.province,units:copy(r.units),troops:sum(r.units),morale:r.morale,supply:r.supply,stance:'balanced',tactic:'hold',formation:'line',commander:null,path:[],arrivalFrom:null},report=E.simulateBattle(s,a,d,false),won=report.winnerArmy===a.id;
  const ap=partition(report.startA,report.endA,!won,true),dp=partition(report.startD,report.endD,won,true);recordPart(s,n,n,ap);
  add(s.nations[n].casualties.dead,dp.dead);add(s.nations[n].casualties.deserted,dp.deserted);r.units=copy(report.endD);r.morale=d.morale;
  if(won){const captured=copy(r.units);add(captured,dp.wounded);add(captured,r.wounded);addPrisoners(s,n,n,captured,true);add(dp.deserted,dp.ready);add(dp.deserted,dp.wounded);dp.ready=empty();dp.wounded=empty();r.units=empty();r.wounded=empty();r.resolution='fought';s.nations[n].gold+=r.treasury;r.treasury=0;finish(s,r)}else{add(r.wounded,dp.wounded);s.provinces[r.province].rebellion.forces=sum(r.units);a.path=[];a.siege=null;if(!a.troops)E.retire(s,a)}
  report.civilWar=true;report.sideNames={a:'Hükümdar kuvvetleri',d:'İsyancı kuvvetleri'};report.casualtiesA=counts(ap);report.casualtiesD=counts(dp);report.endD=copy(r.units);report.lossD=sum(report.startD)-sum(report.endD);s.battles.unshift(report);s.battles=s.battles.slice(0,24);log(s,P[r.province].name+' askerî isyan muharebesi: '+(won?'hükümdar kuvvetleri kazandı':'isyancılar mevzisini korudu')+'.','war');return won?'İsyan yenildi; kalan isyancı birlikleri dağıtıldı.':'İsyan devam ediyor; muharebe kayıpları kaydedildi.';
 }
 function respondRebellion(s,id,choice,armyId=null){const r=s.rebelArmies.find(r=>r.id===id&&r.status==='active');if(!r)throw Error('Etkin isyan bulunamadı.');const n=r.owner,q=s.nations[n],a=actorRef(s,n,r.kind,r.actor);
  if(choice==='fight')return fightRebellion(s,r,armyId);
  if(choice==='independence'){independence(s,r);return 'Bağımsızlık tanındı; sınır ve mevcut kaynaklar devredildi.'}
  if(choice!=='negotiate'||q.gold<180)throw Error('Müzakere için 180 altın gerekli.');q.gold-=180;if(r.goal==='office')q.chiefCommander=r.kind==='commander'?r.actor:null;
  if(r.goal==='autonomy'&&r.kind==='lord'){a.tax=Math.max(.2,a.tax-.1);a.levy=.2;q.authority=clamp(q.authority-5,0,100)}
  if(r.goal==='throne'){q.rulerOverride={name:'Uzlaşılmış askerî yönetim (oyun)',title:'Alternatif yönetim',from:s.turn};q.dynasty.legitimacy=50;q.authority=clamp(q.authority-10,0,100)}
  if(r.kind==='lord'){add(a.units,r.units);a.treasury+=r.treasury}else{add(q.reserveUnits,r.units);q.gold+=r.treasury}r.treasury=0;r.resolution='negotiated';add(q.casualties.wounded,r.wounded);r.units=empty();r.wounded=empty();if(a)a.loyalty=60;finish(s,r);log(s,'Askerî isyan müzakereyle sona erdi; mevcut birlikler antlaşmayla geri döndü.','good');return 'İsyanla uzlaşıldı; yeni birlik üretilmedi.';
 }
 function contain(s,a){const n=s.player,x=actorRef(s,n,a.kind,a.actor),q=s.nations[n];if(!x||x.rebelId||s.turn-x.lastContainment<12)throw Error('Uygun siyasi kişi ve 12 ay bekleme gerekli.');if(!['mediate','dismiss','reassign','divide'].includes(a.choice))throw Error('Geçerli önleyici adım seç.');if(a.choice==='mediate'&&q.gold<100)throw Error('100 altın gerekli.');
  if(a.choice==='divide'){const army=armies(s,n).find(y=>y.commander===x.id);if(!army)throw Error('Bu kişiye bağlı bir sahra ordusu yok.');E.strategy.handle(s,{type:'splitArmy',army:army.id,units:Object.fromEntries(kinds.map(u=>[u,Math.floor(army.units[u]/2)]))})}
  if(a.choice==='mediate'){q.gold-=100;x.loyalty=clamp(x.loyalty+12,0,100);x.opposition=Math.max(0,x.opposition-20)}
  if(['dismiss','reassign'].includes(a.choice)){if(a.kind!=='commander')throw Error('Bu işlem yalnız komutanlar için.');for(const army of armies(s,n))if(army.commander===x.id)army.commander=null;x.influence=clamp(x.influence-15,0,100);x.support=clamp(x.support-15,0,100);x.loyalty=clamp(x.loyalty-(a.choice==='dismiss'?15:5),0,100);x.suspended=a.choice==='dismiss';if(q.chiefCommander===x.id)q.chiefCommander=null}
  x.lastContainment=s.turn;log(s,x.name+' için önleyici siyasi adım uygulandı.','good');return 'Önleyici adım uygulandı.';
 }
 function monthly(s){
  for(const n of nids){const q=s.nations[n];for(const u of kinds){const heal=Math.min(q.casualties.wounded[u],Math.ceil(q.casualties.wounded[u]*.15));q.casualties.wounded[u]-=heal;q.reserveUnits[u]+=heal}}
  if(E.stateMode(s))return;
  for(const n of nids){if(!own(s,n).length)continue;const q=s.nations[n],actors=T.actors(s,n);
   for(const {kind,actor:a} of actors){if(a.rebelId)continue;if(a.demand&&s.turn>a.demand.deadline)T.respond(s,n,kind,a.id,'refuse');
    if(a.opposition>0&&a.loyalty<55){a.opposition=clamp(a.opposition+.6+(55-a.loyalty)*.015,0,100);a.influence=clamp(a.influence+.25,0,100);a.support=clamp(a.support+.45+a.coalition.length*.08,0,100);if(s.turn%6===0)a.coalition=actors.filter(x=>x.actor!==a&&x.actor.loyalty<55&&x.actor.opposition>10).slice(0,3).map(x=>x.actor.id)}else a.opposition=Math.max(0,a.opposition-.25);
    if(a.opposition>=60&&a.support>=50&&a.ultimatum===null){a.ultimatum=s.turn+6;log(s,a.name+' ültimatom verdi; '+E.date({turn:a.ultimatum})+' öncesinde uzlaşma veya komuta tedbiri alabilirsin.','war')}
    if(a.ultimatum!==null&&s.turn>=a.ultimatum&&a.opposition>=80&&a.support>=60&&a.loyalty<35&&q.authority<65){const r=startRebellion(s,n,kind,a.id);if(!r)a.ultimatum=s.turn+12}
   }
  }
  for(const r of s.rebelArmies.filter(r=>r.status==='active')){const chief=actorRef(s,r.owner,r.kind,r.actor);if(r.kind==='lord'&&chief&&!G.cities(s,chief).length&&!chief.claims?.some(id=>s.provinces[id].owner===r.owner)){add(s.nations[r.owner].casualties.deserted,r.units);add(s.nations[r.owner].casualties.deserted,r.wounded);r.units=empty();r.wounded=empty();finish(s,r);continue}if(s.provinces[r.province].owner!==r.owner){const a=actorRef(s,r.owner,r.kind,r.actor);if(a&&r.kind==='lord')add(a.units,r.units);else add(s.nations[r.owner].reserveUnits,r.units);add(s.nations[r.owner].casualties.wounded,r.wounded);r.units=empty();r.wounded=empty();finish(s,r);continue}
   for(const u of kinds){const heal=Math.min(r.wounded[u],Math.ceil(r.wounded[u]*.15));r.wounded[u]-=heal;r.units[u]+=heal}s.provinces[r.province].rebellion.forces=sum(r.units);
   if(r.owner!==s.player&&s.turn%3===0){const a=armies(s,r.owner).find(x=>x.province===r.province);if(a&&a.troops>sum(r.units)*1.2)fightRebellion(s,r,a.id);else if(s.nations[r.owner].gold>=180)respondRebellion(s,r.id,'negotiate')}
  }
 }
 function handle(s,a){if(['releasePrisoners','ransomPrisoners','exchangePrisoners'].includes(a.type))return prisonerAction(s,a);if(a.type==='containActor')return contain(s,a);if(a.type==='rebelResponse'){const r=s.rebelArmies.find(r=>r.id===a.rebel);if(!r||r.owner!==s.player)throw Error('Kendi ülkendeki isyanı seç.');return respondRebellion(s,r.id,a.choice,a.army)}return null}
 function validate(s){const num=(v,a,b)=>typeof v==='number'&&Number.isFinite(v)&&v>=a&&v<=b,validUnits=u=>u&&Object.keys(u).length===3&&kinds.every(k=>Number.isInteger(u[k])&&num(u[k],0,E.stateMode(s)?1e11:1e9));if(s.conflictVersion!==1||!Array.isArray(s.prisoners)||s.prisoners.length>800||!Array.isArray(s.rebelArmies)||s.rebelArmies.length>40||!Number.isInteger(s.nextPrisoner)||!num(s.nextPrisoner,1,1e7)||!Number.isInteger(s.nextRebel)||!num(s.nextRebel,1,1e7))throw Error('Esir ve isyan defteri geçersiz.');
  for(const n of nids){const q=s.nations[n].casualties;if(!q||!['wounded','dead','deserted'].every(k=>validUnits(q[k])))throw Error('Savaş kayıp havuzu geçersiz.');for(const {actor:a} of T.actors(s,n)){if(!(a.ultimatum===null||num(a.ultimatum,0,150000))||!num(a.lastContainment,-12,s.turn)||!(a.rebelId===null||s.rebelArmies.some(r=>r.id===a.rebelId&&r.status==='active')))throw Error('Siyasi isyan eşiği geçersiz.')}}
  const seen=new Set();for(const p of s.prisoners){if(!/^captive-\d+$/.test(p.id)||seen.has(p.id)||Number(p.id.slice(8))>=s.nextPrisoner||!N[p.owner]||!N[p.captor]||typeof p.rebel!=='boolean'||!validUnits(p.units)||!sum(p.units)||!num(p.since,0,s.turn)||p.owner===p.captor&&!p.rebel)throw Error('Esir grubu geçersiz.');seen.add(p.id)}
  const rebels=new Set();for(const r of s.rebelArmies){if(!/^rebel-\d+$/.test(r.id)||rebels.has(r.id)||Number(r.id.slice(6))>=s.nextRebel||!N[r.owner]||!P[r.province]||!['office','autonomy','throne','independence'].includes(r.goal)||!['active','resolved'].includes(r.status)||!validUnits(r.units)||!validUnits(r.wounded)||!num(r.morale,0,100)||!num(r.supply,0,100)||!num(r.started,0,s.turn)||!num(r.treasury,0,1e9)||r.status==='active'&&(!actorRef(s,r.owner,r.kind,r.actor)||!sum(r.units)||s.provinces[r.province].rebellion?.rebelId!==r.id))throw Error('İsyancı ordu geçersiz.');rebels.add(r.id)}return s;
 }
 return {initialize,partition,counts,summarize,afterBattle,addPrisoners,returnPair,ransomQuote,prisonerAction,release,startRebellion,respondRebellion,fightRebellion,monthly,contain,handle,validate,sum};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createConflict;else root.createAnadoluConflict=createConflict;
})(typeof globalThis!=='undefined'?globalThis:this);
