/* A wider map with regional navigation, search and scale-dependent detail. */
if(E.world.revision){
 const regionNames=[...new Set(SCENARIO.regions.filter(n=>n.map_visible!==false).map(n=>n.continent))],fold=s=>String(s).replace(/ı/g,'i').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const countryOptions=()=>{const query=fold($('#world-country-query').value),region=$('#world-country-region').value,old=$('#country-select').value;$('#country-select').innerHTML=regionNames.map(c=>{const list=SCENARIO.regions.filter(n=>n.map_visible!==false&&n.continent===c&&(!region||c===region)&&(!query||fold(n.name+' '+n.short+' '+n.capital.city).includes(query)));return list.length?'<optgroup label="'+escapeHtml(c)+'">'+list.map(n=>'<option value="'+n.id+'">'+escapeHtml(n.name)+'</option>').join('')+'</optgroup>':''}).join('');if([...$('#country-select').options].some(o=>o.value===old))$('#country-select').value=old;if($('#country-select').value)previewCountry();$('#start-game').disabled=!$('#country-select').value};
 $('#country-select').insertAdjacentHTML('beforebegin','<label class="world-filter-label" for="world-country-query">DEVLET VEYA BAŞKENT ARA</label><input id="world-country-query" class="world-nation-search" type="search" placeholder="Selçuklu, Fransa, Delhi…" autocomplete="off"><label class="world-filter-label" for="world-country-region">BÖLGE</label><select id="world-country-region" class="world-country-filter"><option value="">Bütün bölgeler</option>'+regionNames.map(r=>'<option>'+escapeHtml(r)+'</option>').join('')+'</select>');
 $('#recommended-countries').addEventListener('click',e=>{if(e.target.closest('[data-country]')){$('#world-country-query').value='';$('#world-country-region').value='';countryOptions()}},true);
 $('#world-country-query').addEventListener('input',countryOptions);$('#world-country-region').addEventListener('change',countryOptions);countryOptions();
 const worldSaveMenu=openSaveMenu;openSaveMenu=function(){worldSaveMenu();try{if(localStorage.getItem(SAVE_KEY+'-before-v045'))$('#dialog-content .save-actions').insertAdjacentHTML('beforeend','<button data-world-backup>Atlas güncellemesi öncesi kaydı indir ↓</button>')}catch{}};
 document.addEventListener('click',e=>{if(e.target.closest('[data-world-backup]')){const raw=localStorage.getItem(SAVE_KEY+'-before-v045');if(raw)download('Anadolu_1280_Atlas_Oncesi.json',raw,'application/json')}});
 const worldPreview=previewCountry;previewCountry=function(){if(!$('#country-select').value)return;worldPreview();const n=E.N[$('#country-select').value];$('#country-preview').insertAdjacentHTML('beforeend','<p class="world-country-note">'+escapeHtml(n.note||n.text||'')+'</p>')};
 $('#map-type').insertAdjacentHTML('afterend','<select class="world-region-select" id="world-region-view" aria-label="Bölgeye git"><option value="">Bölgeye git</option>'+map.views.map(v=>'<option value="'+v.id+'">'+escapeHtml(v.name)+'</option>').join('')+'</select>');
 $('#world-region-view').addEventListener('change',e=>{const choice=map.views.find(v=>v.id===e.target.value);if(choice){viewMode='manual';fitBox(choice.bbox,35)}e.target.value=''});
 viewport.insertAdjacentHTML('beforeend','<div class="world-mini"><span class="world-mini-header">Bilinen Dünya · 1280</span><svg id="world-mini-svg" viewBox="0 '+map.top+' '+map.width+' '+map.plot_height+'" role="button" tabindex="0" aria-label="Genel harita: bir bölgeye gitmek için tıkla"><rect x="0" y="'+map.top+'" width="'+map.width+'" height="'+map.plot_height+'" fill="#537983"/><use href="#world-land" fill="#bbb58f" mask="url(#north-africa-margin)"/><rect class="world-mini-view" id="world-mini-view" x="0" y="0" width="100" height="100"/></svg></div><div class="world-map-info"><span id="world-detail-hint">1280 · Yaklaşık siyasi sınırlar</span><button id="world-sources">Harita kaynakları</button></div>');
 function moveMini(e){if(!game||!view)return;const mini=$('#world-mini-svg'),point=mini.createSVGPoint();point.x=e.clientX;point.y=e.clientY;const pt=point.matrixTransform(mini.getScreenCTM().inverse());view.x=pt.x-view.w/2;view.y=pt.y-view.w/aspect/2;viewMode='manual';renderView()}
 $('#world-mini-svg').addEventListener('click',moveMini);$('#world-mini-svg').addEventListener('keydown',e=>{if(e.key==='Enter'){viewMode='world';fitBox(world,0)}});
 $('#world-sources').addEventListener('click',()=>openDialog('1280 · Büyük Atlasın Kaynakları','<div class="dialog-help world-source-list"><p class="eyebrow">AVRUPA · ASYA · KUZEY AFRİKA</p><h3>'+SCENARIO.stats.visibleCountries+' görünen siyasi alan · '+SCENARIO.stats.visibleProvinces+' şehir çevresi</h3><p>'+escapeHtml(SCENARIO.cartography.scope_note||'')+'</p><p>Kıyılar, nehirler ve göller fizikî coğrafyadan çizildi. Siyasi alanlar Ocak 1280 için tarihî kaynaklarla karşılaştırıldı. Göçebe nüfuzu ve tartışmalı uçlar kesin çizgi sayılmamalı.</p><p>Şehirler küçük nokta ve başkent elmasıyla gösterilir. Ülke içi yapay bölme çizgileri çizilmez.</p><p>Cliopatria’nın 1280 kesitindeki tek Moğol alanı, ayrı hanlıklara uyarlandı. Bunun için kullanılan 1294 referansı 1280’in birebir sınırı olarak sunulmaz. Yuan’da Song, Java’da Majapahit ve Mağrip’te Muvahhid etiketleri başlangıç yılına göre düzeltildi. Yeni şehir çevreleri oyun bölgeleridir; tarihî idarî sınırlar değildir.</p><ul>'+SCENARIO.cartography.sources.map(s=>'<li><strong>'+escapeHtml(s.title)+'</strong><p>'+escapeHtml(s.scope||'')+'</p><a href="'+escapeHtml(s.url)+'" target="_blank" rel="noopener">'+escapeHtml(s.url)+'</a></li>').join('')+'</ul><p>Cliopatria / Seshat Global History Databank · <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">CC BY 4.0</a>, uyarlanmıştır. Natural Earth fizikî coğrafyası kamu malıdır. Yeni mühürler temsilî oyun çizimleridir.</p><p>Eski bölgenin tarihî olayları korunur. Yeni alanlar kaynaklı 1280 başlangıcı ve genel devlet simülasyonuyla oynanır; her devlet için ayrıntılı gelecek olay zinciri bu harita güncellemesinin parçası değildir.</p></div>'));
 // Cache ownership and anchors on state changes, never on pointer movement.
 const cityNodes=$$('.world-atlas .city-node').map(node=>({node,p:E.P[node.dataset.province],label:node.querySelector('.city-label'),labelHit:node.querySelector('.city-label-hit'),shown:null,transform:''}));
 const miniRect=$('#world-mini-view'),hint=$('#world-detail-hint');
 let nationLabels=[],detailTimer=0,lastLabelHtml='',lastScale=0,cityLabelMode='auto';
 const labelToggle=$('#toggle-labels');
 function labelToggleText(){labelToggle.textContent='Şehir adları · '+({auto:'Otomatik',all:'Tümü',off:'Kapalı'}[cityLabelMode]);labelToggle.setAttribute('aria-label','Şehir adları: '+({auto:'otomatik',all:'tümü',off:'kapalı'}[cityLabelMode]));labelToggle.setAttribute('aria-pressed',String(cityLabelMode!=='off'))}
 labelToggle.addEventListener('click',e=>{e.stopImmediatePropagation();cityLabelMode=cityLabelMode==='auto'?'all':cityLabelMode==='all'?'off':'auto';svg.classList.remove('hide-city-labels');labelToggleText();worldDetail()},true);labelToggleText();
 function refreshLabelData(){
  const groups=new Map();for(const id of map.visibleProvinceIds){const p=E.P[id],n=game.provinces[id].owner;if(!groups.has(n))groups.set(n,[]);groups.get(n).push(p)}
  nationLabels=[...groups].map(([id,land])=>{const def=E.N[id],unchanged=land.length===def.province_count&&land.every(p=>p.owner===id);let x,y;if(unchanged&&def.label_anchor)[x,y]=def.label_anchor;else{x=land.reduce((v,p)=>v+p.map_x,0)/land.length;y=land.reduce((v,p)=>v+p.map_y,0)/land.length}return {id,def,x,y,count:land.length}}).sort((a,b)=>(b.def.area||0)-(a.def.area||0));
 }
 function worldLabels(scale,detail){
  const placed=[],width=viewport.clientWidth,height=viewport.clientHeight;let out='';if(detail==='local'||width<700&&detail==='region'||cityLabelMode==='all'){if(lastLabelHtml){labelLayer.innerHTML='';lastLabelHtml=''}return}
  for(const n of nationLabels){if(detail==='world'&&(n.def.area||0)<20&&n.id!==game.player)continue;
   const px=(n.x-view.x)*scale,py=(n.y-view.y)*scale,text=n.def.short.toLocaleUpperCase('tr-TR'),font=detail==='world'?((n.def.area||0)>250?13:10):11,w=text.length*font*.60;
   if(px+w/2<0||px-w/2>width||py<12||py>height-20)continue;
   const rect=[px-w/2-5,py-font-5,px+w/2+5,py+4];if(placed.some(r=>rect[0]<r[2]&&rect[2]>r[0]&&rect[1]<r[3]&&rect[3]>r[1]))continue;placed.push(rect);
   out+='<text class="map-label-text" x="'+n.x+'" y="'+(n.y-14/scale)+'" text-anchor="middle" style="font-size:'+(font/scale)+'px;letter-spacing:'+(1.1/scale)+'px;stroke-width:'+(1.7/scale)+'px">'+escapeHtml(text)+'</text>';
  }
  if(out!==lastLabelHtml){labelLayer.innerHTML=out;lastLabelHtml=out}
 }
 function worldDetail(){
  if(!game||!view||!viewport.clientWidth)return;
  const width=viewport.clientWidth,height=viewport.clientHeight,scale=width/view.w,detail=scale<.20?'world':scale<.60?'region':'local';
  svg.dataset.detail=detail;svg.classList.toggle('world-physical-mode',mapType==='terrain');
  miniRect.setAttribute('x',view.x);miniRect.setAttribute('y',view.y);miniRect.setAttribute('width',view.w);miniRect.setAttribute('height',view.w/aspect);
  const moving=!!(drag&&moved);svg.classList.toggle('is-panning',moving);if(moving)return;
  hint.textContent=SCENARIO.stats.visibleProvinces+' şehir · İşaretlere tıkla';
  const placed=[];const factor=1/scale;
  // All city marks stay in the SVG; only labels depend on scale.
  const ordered=[...cityNodes].sort((a,b)=>Number(b.p.id===selectedProvince)-Number(a.p.id===selectedProvince)||Number(game.provinces[b.p.id].owner===game.player)-Number(game.provinces[a.p.id].owner===game.player)||Number(b.node.classList.contains('capital-node'))-Number(a.node.classList.contains('capital-node')));
  for(const item of ordered){const {node,p,label,labelHit}=item,px=(p.map_x-view.x)*scale,py=(p.map_y-view.y)*scale;
   const cap=node.classList.contains('capital-node'),inView=px>-15&&px<width+15&&py>-15&&py<height+15;
   if(item.shown!==true){node.style.display='';item.shown=true}
   const transform='translate('+p.map_x+' '+p.map_y+') scale('+factor+')';if(item.transform!==transform){node.setAttribute('transform',transform);item.transform=transform}
   const w=p.name.length*5.8,rect=[px+9,py-9,px+w+15,py+8],eligible=detail==='local'||detail==='region'&&(cap||game.provinces[p.id].owner===game.player)||p.id===selectedProvince;
   const showLabel=inView&&cityLabelMode!=='off'&&(cityLabelMode==='all'||eligible&&px>0&&px+w+14<width-5&&!placed.some(r=>rect[0]<r[2]&&rect[2]>r[0]&&rect[1]<r[3]&&rect[3]>r[1]));
   label.style.display=showLabel?'':'none';if(labelHit)labelHit.style.display=showLabel?'':'none';if(showLabel)placed.push(rect);
   node.classList.toggle('is-selected-city',p.id===selectedProvince);
  }
  const offsets={};for(const token of [...armyLayer.children]){const a=game.armies.find(a=>a.id===token.dataset.army);if(!a)continue;const p=E.P[a.province],px=(p.map_x-view.x)*scale,py=(p.map_y-view.y)*scale;
   const relevant=screen==='war'||a.owner===game.player||E.isWar(game,game.player,a.owner);const shown=p.map_visible!==false&&relevant&&detail==='local'&&px>-70&&px<width+30&&py>-70&&py<height+30;token.style.display=shown?'':'none';if(!shown)continue;
   const i=offsets[a.province]||0;offsets[a.province]=i+1;token.setAttribute('transform','translate('+(p.map_x-22*factor)+' '+(p.map_y+(20+i*24)*factor)+') scale('+factor+')');
  }
  worldLabels(scale,detail);lastScale=scale;
 }
 function scheduleWorldDetail(){clearTimeout(detailTimer);if(drag&&moved){svg.classList.add('is-panning');return}detailTimer=setTimeout(worldDetail,55)}
 const worldRenderView=renderView;renderView=function(){worldRenderView();scheduleWorldDetail()};
 const worldRenderMap=renderMap;renderMap=function(){worldRenderMap();if(!game)return;refreshLabelData();worldDetail()};
 svg.addEventListener('pointerup',()=>{clearTimeout(detailTimer);worldDetail()});svg.addEventListener('pointercancel',()=>{clearTimeout(detailTimer);worldDetail()});
}
