/* State and estates: procedural officeholders are game characters, not historical claims. */
(function(root){
'use strict';
function createStatecraft(E){
 const {P,N,ids,nids,own,armies,capital,clamp,log,random,newArmy,sync,units,buildings}=E;
 const kinds=Object.keys(units),sum=u=>kinds.reduce((a,k)=>a+u[k],0),empty=()=>({infantry:0,cavalry:0,archer:0});
 const tenures=Object.freeze({appointed:{name:'Atanmış valilik',tax:.6,levy:.5,inheritance:'crown'},hereditary:{name:'Kalıtsal beylik',tax:.35,levy:.25,inheritance:'heir'},charter:{name:'Özel imtiyazlı beylik',tax:.25,levy:.2,inheritance:'heir'}});
 const hash=v=>[...v].reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,1280);
 function initialize(s){
  s.craftVersion=1;s.nextLord??=1;s.lords??=[];
  for(const id of ids)s.provinces[id].governor??=null;
  for(const n of nids){const q=s.nations[n];q.estateLedger??={lastIncome:0,lastLevy:0};
   if(!E.stateMode(s)&&!s.lords.some(l=>l.owner===n))for(let i=0;i<2;i++){const h=hash(n+i);s.lords.push({id:'lord-'+s.nextLord++,owner:n,name:(i?'Uç beyi':'Saray valisi')+' '+(i+1)+' (oyun)',house:N[n].short+' Hanesi '+(i+1),role:i?'Sınır idaresi':'Şehir idaresi',alive:true,tenure:'appointed',inheritance:'crown',tax:.6,levy:.5,loyalty:72+(h%9),ambition:30+h%35,personality:['temkinli','uzlaşmacı','hırslı'][h%3],administration:2+h%4,military:2+(h>>>3)%4,treasury:0,manpower:0,units:empty(),lastLevy:-12,lastContract:-12})}
  }return s;
 }
 const lord=(s,id)=>s.lords.find(l=>l.id===id);
 const cities=(s,l)=>E.stateMode(s)?[]:ids.filter(id=>s.provinces[id].governor===l.id&&s.provinces[id].owner===l.owner);
 const governor=(s,id)=>{if(E.stateMode(s))return null;const l=lord(s,s.provinces[id].governor);return l?.alive&&l.owner===s.provinces[id].owner?l:null};
 function capacity(s,n){if(E.stateMode(s))return {direct:own(s,n).length,limit:own(s,n).length,excess:0,cost:0};const direct=own(s,n).filter(id=>!governor(s,id)).length,cap=capital(s,n),limit=8+(cap?s.provinces[cap].development:0)+(s.nations[n].advisors.finance?2:0),excess=Math.max(0,direct-limit);return {direct,limit,excess,cost:excess*3}}
 function cityStats(s,id,raw){
  if(s.craftVersion!==1)return raw;
  const l=governor(s,id);if(!l)return {...raw,grossGold:raw.gold,grossManpower:raw.manpower,lordGold:0,lordManpower:0,lordMaintenance:0};
  const parent=s.lordshipVersion&&l.liege?lord(s,l.liege):null,localGold=raw.gold*l.tax,localManpower=Math.floor(raw.manpower*l.levy),gold=parent?localGold*parent.tax:localGold,manpower=parent?Math.floor(localManpower*parent.levy):localManpower;
  return {...raw,gold,manpower,maintenance:0,grossGold:raw.gold,grossManpower:raw.manpower,lordGold:raw.gold-localGold,lordManpower:raw.manpower-localManpower,liegeGold:localGold-gold,liegeManpower:localManpower-manpower,lordMaintenance:raw.maintenance};
 }
 function ledger(s){
  if(E.stateMode(s))return {};
  const result=Object.fromEntries(s.lords.map(l=>[l.id,{gold:0,manpower:0,maintenance:0}]));
  for(const id of ids){const p=s.provinces[id],l=governor(s,id);if(!l){p.governor=null;continue}const st=E.cityStats(s,id),v=result[l.id];v.gold+=st.lordGold;v.manpower+=st.lordManpower;v.maintenance+=st.lordMaintenance;if(l.liege&&result[l.liege]){result[l.liege].gold+=st.liegeGold||0;result[l.liege].manpower+=st.liegeManpower||0}}
  return result;
 }
 function cleanup(s){for(const id of ids)if(s.provinces[id].governor&&!governor(s,id))s.provinces[id].governor=null}
 function collect(s,entries){
  if(E.stateMode(s))return;
  for(const l of s.lords){if(!l.alive)continue;const e=entries[l.id]||{gold:0,manpower:0,maintenance:0},cost=E.strategy.upkeep(l.units);l.treasury=Math.max(0,+(l.treasury+e.gold-e.maintenance-cost).toFixed(4));l.manpower=Math.min(30000,l.manpower+e.manpower);
   if(!l.treasury&&sum(l.units))for(const u of kinds)l.units[u]=Math.floor(l.units[u]*.98);
  }
 }
 function check(s,l,n){if(!l||!l.alive||l.owner!==n)throw Error('Kendi yaşayan beyini seç.');if(s.pendingEvents.length||s.nations[n].dynasty.crisis)throw Error('Önce bekleyen tarihî kararı çöz.')}
 function buildLord(s,l,id,type){const p=s.provinces[id],def=buildings[type];if(!p||p.governor!==l.id||p.owner!==l.owner||p.rebellion||p.building||!Object.hasOwn(buildings,type)||p[type]>=def.max)throw Error('Beyin uygun bir şehrini ve inşaatı seç.');const cost=Math.ceil(def.cost*(1+p[type]*.35));if(l.treasury<cost)throw Error('Beyin hazinesi yetersiz.');l.treasury-=cost;p.building={type,remaining:2,payer:l.id};return cost}
 function raise(s,l,unit,amount){if(!Object.hasOwn(units,unit)||![100,500,1000].includes(amount)||!cities(s,l).some(id=>!s.provinces[id].rebellion))throw Error('Birlik türü, sayı ve güvenli beylik şehri gerekli.');const cost=amount*units[unit].cost;if(l.manpower<amount||l.treasury<cost||sum(l.units)+amount>30000)throw Error('Beyin asker havuzu veya hazinesi yetersiz.');l.treasury-=cost;l.manpower-=amount;l.units[unit]+=amount;return amount}
 function handle(s,a,n=s.player){
  if(!['grantEstate','revokeEstate','lordContract','lordBuild','lordRecruit','callLevy','fundLord'].includes(a.type))return null;
  const l=lord(s,a.lord),q=s.nations[n];check(s,l,n);
  if(a.type==='grantEstate'){
   const p=s.provinces[a.province],def=tenures[a.tenure];if(!p||p.owner!==n||p.rebellion||p.governor||a.province===capital(s,n)||!Object.hasOwn(tenures,a.tenure)||cities(s,l).length>=5)throw Error('Başkent dışındaki doğrudan yönetilen güvenli kendi şehrini seç.');
   if(cities(s,l).length&&(l.tenure!==a.tenure||(a.tenure==='charter'&&l.inheritance!==a.inheritance)))throw Error('Bir beyin şehirleri aynı fermana bağlı olmalı.');
   if(a.tenure==='charter'&&!['heir','crown'].includes(a.inheritance))throw Error('Fermanın veraset şartını seç.');if(q.gold<50)throw Error('Atama ödeneği için 50 altın gerekli.');
   q.gold-=50;l.treasury+=50;if(!cities(s,l).length){l.tenure=a.tenure;l.inheritance=a.tenure==='charter'?a.inheritance:def.inheritance;l.tax=def.tax;l.levy=def.levy}p.governor=l.id;l.loyalty=clamp(l.loyalty+4,0,100);log(s,P[a.province].name+', '+l.name+' idaresine verildi. Vergi/asker üretimi merkez ve bey arasında paylaşılacak.','good');return 'Şehir beye verildi; mülkiyet devletinde kaldı.';
  }
  if(a.type==='revokeEstate'){
   const p=s.provinces[a.province];if(!p||p.owner!==n||p.governor!==l.id)throw Error('Bu beyin yönettiği kendi şehrini seç.');const cost=l.tenure==='appointed'?60:120;if(q.gold<cost)throw Error(cost+' altın gerekli.');q.gold-=cost;p.governor=null;l.loyalty=clamp(l.loyalty-(l.tenure==='appointed'?10:25),0,100);if(l.tenure!=='appointed')q.stability=clamp(q.stability-4,0,100);log(s,P[a.province].name+' doğrudan yönetime alındı; '+l.name+' bağlılığı azaldı.','war');return 'Şehir doğrudan yönetime döndü.';
  }
  if(a.type==='lordContract'){
   if(![.2,.25,.35,.5,.6].includes(a.tax)||![.2,.25,.5].includes(a.levy)||s.turn-l.lastContract<12)throw Error('Geçerli yükümlülük seç; sözleşme yılda bir değişir.');const increase=Math.max(0,a.tax-l.tax)+Math.max(0,a.levy-l.levy);l.loyalty=clamp(l.loyalty-Math.round(increase*45)+(increase?0:3),0,100);l.tax=a.tax;l.levy=a.levy;l.lastContract=s.turn;return 'Vergi ve asker yükümlülüğü yenilendi.';
  }
  if(a.type==='fundLord'){if(![50,100,200].includes(a.amount)||q.gold<a.amount||l.treasury+a.amount>1e9)throw Error('Hazinede karşılanabilen 50, 100 veya 200 altın seç.');q.gold-=a.amount;l.treasury+=a.amount;return 'Ödenek merkezden beyin hazinesine aktarıldı.'}
  if(a.type==='lordBuild'){buildLord(s,l,a.province,a.building);return 'Beyin hazinesiyle inşaat başladı.'}
  if(a.type==='lordRecruit'){raise(s,l,a.unit,a.amount);return 'Bey kendi havuzundan asker yetiştirdi.'}
  const ids=cities(s,l),at=ids.find(id=>!s.provinces[id].rebellion),parent=s.lordshipVersion&&l.liege?lord(s,l.liege):null,upstream=Object.fromEntries(kinds.map(u=>[u,Math.floor(l.units[u]*l.levy)])),selection=Object.fromEntries(kinds.map(u=>[u,parent?Math.floor(upstream[u]*parent.levy):upstream[u]])),amount=sum(selection);
  if(parent&&sum(parent.units)+sum(upstream)-amount>30000)throw Error('Üst beyin birlik sınırı dolu.');if(!at||!amount||s.turn-l.lastLevy<12)throw Error('Güvenli beylik şehri, mevcut asker ve 12 ay bekleme gerekli.');
  let target=armies(s,n).find(x=>x.province===at&&!x.siege&&!x.path.length);if(!target&&(s.armies.length>=500||s.nextArmy>=1e6))throw Error('Ordu kayıt sınırı dolu.');
  if(target&&target.troops+amount>1e7)throw Error('Ordu üst sınırı aşılır.');
  if(!target){target=newArmy(s,n,at,amount,'infantry');target.units=empty();target.commander=null}
  for(const u of kinds){l.units[u]-=upstream[u];if(parent)parent.units[u]+=upstream[u]-selection[u];target.units[u]+=selection[u]}sync(target);l.lastLevy=s.turn;l.loyalty=clamp(l.loyalty-3,0,100);q.estateLedger.lastLevy=amount;log(s,l.name+' mevcut birliklerinden '+amount+' asker sefer ordusuna katıldı.','good');return amount+' mevcut asker devlete aktarıldı; yeni asker üretilmedi.';
 }
 function ai(s){if(E.stateMode(s))return;if(s.turn%12||s.pendingEvents.length)return;for(const n of nids){if(!own(s,n).length)continue;const q=s.nations[n];if(q.dynasty.crisis)continue;const ls=s.lords.filter(l=>l.owner===n&&l.alive);
  if(capacity(s,n).excess&&q.gold>=50){const id=own(s,n).find(id=>id!==capital(s,n)&&!s.provinces[id].governor&&!s.provinces[id].rebellion),l=ls.find(l=>cities(s,l).length<3);if(id&&l)handle(s,{type:'grantEstate',lord:l.id,province:id,tenure:'appointed'},n)}
  for(const l of ls){if(l.rebelId)continue;const id=cities(s,l).find(id=>!s.provinces[id].rebellion&&!s.provinces[id].building);if(id&&l.treasury>400&&s.provinces[id].market<2)buildLord(s,l,id,'market');if(id&&l.manpower>=500&&l.treasury>250&&sum(l.units)<2000)raise(s,l,'infantry',500);}
 }}
 function validate(s){const num=(v,a,b)=>typeof v==='number'&&Number.isFinite(v)&&v>=a&&v<=b;if(s.craftVersion!==1||!Number.isInteger(s.nextLord)||!num(s.nextLord,1,1e6)||!Array.isArray(s.lords)||s.lords.length>500)throw Error('Bey yönetimi kaydı geçersiz.');const seen=new Set();
  for(const l of s.lords){if(!/^lord-\d+$/.test(l.id)||seen.has(l.id)||Number(l.id.slice(5))>=s.nextLord||!N[l.owner]||typeof l.name!=='string'||l.name.length>150||typeof l.house!=='string'||l.house.length>150||typeof l.alive!=='boolean'||!Object.hasOwn(tenures,l.tenure)||!['heir','crown'].includes(l.inheritance)||!num(l.tax,.2,.6)||![.2,.25,.5].includes(l.levy)||!['loyalty','ambition'].every(k=>num(l[k],0,100))||!['administration','military'].every(k=>Number.isInteger(l[k])&&num(l[k],1,6))||!num(l.treasury,0,1e9)||!Number.isInteger(l.manpower)||!num(l.manpower,0,30000)||!l.units||!kinds.every(k=>Number.isInteger(l.units[k])&&num(l.units[k],0,30000))||Object.keys(l.units).length!==3||sum(l.units)>30000||!num(l.lastLevy,-12,s.turn)||!num(l.lastContract,-12,s.turn))throw Error('Bey kaydı geçersiz.');seen.add(l.id)}
  for(const id of ids){const p=s.provinces[id];if(p.governor!==null&&!governor(s,id))throw Error('Şehir beyi bulunamadı.');if(p.building?.payer&&!lord(s,p.building.payer))throw Error('İnşaat ödeyen beyi geçersiz.');}for(const n of nids){const l=s.nations[n].estateLedger;if(!l||!num(l.lastIncome,0,1e10)||!num(l.lastLevy,0,1e7))throw Error('Bey yükümlülük defteri geçersiz.');}return s;
 }
 return {initialize,cleanup,tenures,lord,cities,governor,capacity,cityStats,ledger,collect,handle,ai,validate,buildLord,raise,sum,empty};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createStatecraft;else root.createAnadoluStatecraft=createStatecraft;
})(typeof globalThis!=='undefined'?globalThis:this);
