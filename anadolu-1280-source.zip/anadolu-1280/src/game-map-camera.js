/* Bound the map camera without changing campaign state. */
(function(root){'use strict';
function constrain(camera,bounds,aspect){const [left,top,right,bottom]=bounds,bw=right-left,bh=bottom-top,maxWidth=Math.max(bw,bh*aspect),w=Math.max(300,Math.min(maxWidth,camera.w)),h=w/aspect;return {x:w>=bw?left+(bw-w)/2:Math.max(left,Math.min(right-w,camera.x)),y:h>=bh?top+(bh-h)/2:Math.max(top,Math.min(bottom-h,camera.y)),w}}
if(typeof module!=='undefined'&&module.exports)module.exports=constrain;else root.constrainAtlasCamera=constrain;
})(typeof globalThis!=='undefined'?globalThis:this);
