/* Distinct civic loyalty, slow cultural policy, small houses and mixed succession. */
(function(root){
'use strict';
function createPolitics(E){
 const {P,N,C,ids,nids,own,armies,capital,profile,clamp,log,random,units}=E,G=E.statecraft;
 const civic={balanced:{name:'Dengeli yönetim',loyalty:0,cost:0},tolerant:{name:'Hoşgörü ve yerel haklar',loyalty:.2,cost:1},repression:{name:'Baskıcı güvenlik',loyalty:-.25,cost:2}};
 const cultural={none:{name:'Kültüre müdahale etme',yearly:0,cost:0},voluntary:{name:'Gönüllü bütünleşme',yearly:.1,cost:2},settlement:{name:'İskân teşviki',yearly:.3,cost:3},coercion:{name:'Zorlayıcı kültür siyaseti',yearly:.5,cost:4}};
 const hash=v=>[...v].reduce((a,c)=>(a*31+c.charCodeAt(0))>>>0,1280);
 function family(l,generation=1){return [1,2,3].map((i)=>({id:l.id+'-g'+generation+'-kin'+i,name:(i===3?'Eş':'Varis '+i)+' · '+l.house+' (oyun)',relation:i===3?'spouse':'child',alive:true,legitimate:i!==3,ageMonths:(i===3?Math.max(16,Math.floor(l.ageMonths/12)-2):Math.max(0,Math.min(i===1?22:17,Math.floor(l.ageMonths/12)-(i===1?18:23))))*12,claim:i===1?80:i===2?45:0,loyalty:65+i*3,administration:2+i%3,military:2+(i+1)%3,ambition:35+i*8}))}
 function initialize(s){s.politicsVersion=1;s.successionDisputes??=[];s.politicalHistory??=[];
  for(const id of ids){const p=s.provinces[id];p.allegiance??=65;p.civicPolicy??='balanced';p.culturalPolicy??=p.policy==='integration'?'voluntary':'none'}
  for(const l of s.lords){const h=hash(l.id);l.ageMonths??=(40+h%9)*12;l.deathAt??=(72+h%12)*12;l.generation??=1;l.family??=family(l);l.personId??=l.id+'-founder';l.lastSuccession??=-1;l.opposition??=0;l.support??=30;l.influence??=35;l.demand??=null;l.lastDemand??=-36;l.coalition??=[]}
  for(const n of nids){const q=s.nations[n];q.authority??=65;q.reserveUnits??=G.empty();q.chiefCommander??=null;q.council??=['finance','envoy'].map(role=>({id:n+'-'+role,role,name:E.advisor(s,n,role).name,loyalty:72,ambition:45,influence:30,support:30,opposition:0,demand:null,lastDemand:-36,coalition:[]}));
   for(const c of q.commanders){const h=hash(c.id);c.ambition??=35+h%50;c.influence??=45;c.support??=35;c.opposition??=0;c.demand??=null;c.lastDemand??=-36;c.coalition??=[]}
  }return s;
 }
 function archive(s,text,n,type='good'){s.politicalHistory.unshift({turn:s.turn,nation:n,text});s.politicalHistory=s.politicalHistory.slice(0,100);log(s,text,type)}
 function actors(s,n){if(E.stateMode(s))return [];const ls=s.lords.filter(l=>l.owner===n&&l.alive&&(G.cities(s,l).length||(s.lordshipVersion&&l.claims?.some(id=>s.provinces[id].owner===n)&&s.turn-l.lastDismissal<120)));return [...s.nations[n].commanders.filter(c=>!c.retired&&!ls.some(l=>l.commanderId===c.id)).map(actor=>({kind:'commander',actor})),...ls.map(actor=>({kind:'lord',actor})),...s.nations[n].council.filter(a=>s.nations[n].advisors[a.role]).map(actor=>({kind:'vizier',actor}))]}
 function actor(s,n,kind,id){return actors(s,n).find(x=>x.kind===kind&&x.actor.id===id)?.actor}
 function power(s,n,kind,a){if(kind==='commander'){const total=armies(s,n).reduce((v,x)=>v+x.troops,0)||1,led=armies(s,n).filter(x=>x.commander===a.id).reduce((v,x)=>v+x.troops,0);return clamp(led/total*70+a.influence*.3,0,100)}if(kind==='lord')return clamp(G.cities(s,a).length/Math.max(1,own(s,n).length)*60+G.sum(a.units)/150+a.influence*.2+(a.commanderId?armies(s,n).filter(x=>x.commander===a.commanderId).reduce((v,x)=>v+x.troops,0)/Math.max(1,armies(s,n).reduce((v,x)=>v+x.troops,0))*40:0),0,100);return a.influence}
 function cost(s,id){const p=s.provinces[id];return civic[p.civicPolicy].cost+(s.lordshipVersion?0:(p.policy==='integration'&&p.culturalPolicy==='voluntary'?0:cultural[p.culturalPolicy].cost))}
 function communities(s){
  for(const id of ids){const p=s.provinces[id],q=s.nations[p.owner],l=G.governor(s,id),guard=armies(s,p.owner).some(a=>a.province===id),cap=G.capacity(s,p.owner);
   const delta=(q.stability-72)*.006+(q.tax==='low'?.22:q.tax==='high'?-.35:0)+civic[p.civicPolicy].loyalty-p.unrest*.005+(guard&&p.unrest>15?.25:0)+(l?(l.loyalty-70)*.003+(s.characterSchema?E.getCharacters().administrativeDrift(s,l.personId):0):-cap.excess*.005)-(p.culturalPolicy==='coercion'?.2:0);
   p.allegiance=clamp(p.allegiance+delta,0,100);if(p.civicPolicy==='repression')p.unrest=clamp(p.unrest-.5,0,95);if(p.culturalPolicy==='coercion')p.unrest=clamp(p.unrest+.7,0,95);
   if(s.lordshipVersion||s.turn%12||p.rebellion||q.gold<=0||p.allegiance<40)continue;const rate=cultural[p.culturalPolicy].yearly,main=profile(p.owner).culture,other=Object.entries(p.cultures).filter(([c,v])=>c!==main&&v>0).sort((a,b)=>b[1]-a[1])[0];
   if(rate&&other){const amount=Math.min(rate,other[1]);p.cultures[other[0]]=+(other[1]-amount).toFixed(4);p.cultures[main]=100-Object.entries(p.cultures).filter(([c])=>c!==main).reduce((v,[,x])=>v+x,0);p.loyalty[main]??=65}
  }
 }
 function eligible(l){return l.family.filter(p=>p.alive&&p.legitimate&&p.relation==='child').sort((a,b)=>b.claim-a.claim||b.ageMonths-a.ageMonths)}
 function inherit(s,l,heir){const old=l.name;l.personId=heir.id;l.name=heir.name;l.ageMonths=heir.ageMonths;l.administration=heir.administration;l.military=heir.military;l.ambition=heir.ambition;l.loyalty=clamp((heir.loyalty+l.loyalty)/2-5,25,90);l.generation++;l.deathAt=(72+hash(heir.id)%12)*12;l.family=family(l,l.generation);l.lastSuccession=s.turn;l.opposition=0;l.demand=null;l.coalition=[];archive(s,old+' öldü; '+l.name+' beylik şehirlerini, hazinesini ve mevcut birliklerini devraldı.',l.owner)}
 function revert(s,l){const q=s.nations[l.owner],old=l.name,amount=G.sum(l.units),important=G.cities(s,l).length||l.treasury||amount;for(const id of G.cities(s,l))s.provinces[id].governor=null;q.gold+=l.treasury;q.manpower=Math.min(60000,q.manpower+l.manpower);for(const u of Object.keys(units)){q.reserveUnits[u]+=l.units[u];l.units[u]=0}l.treasury=0;l.manpower=0;l.personId=l.id+'-replacement-'+s.turn;l.name='Yeni saray valisi (oyun)';l.ageMonths=35*12;l.deathAt=78*12;l.family=family(l,++l.generation);l.tenure='appointed';l.inheritance='crown';l.tax=.6;l.levy=.5;l.lastSuccession=s.turn;l.loyalty=72;l.opposition=0;l.demand=null;if(important)archive(s,old+' öldü; makam ve hazine merkeze döndü. '+amount+' mevcut asker merkez yedeğine aktarıldı.',l.owner)}
 function death(s,l){
  if(!l.alive||l.ageMonths<l.deathAt||l.lastSuccession===s.turn||s.successionDisputes.some(d=>d.lord===l.id))return false;
  const heirs=eligible(l);if(l.tenure==='appointed'||l.inheritance==='crown'||!heirs.length){revert(s,l);return true}
  const significant=G.cities(s,l).length>=2||G.sum(l.units)>=500;
  if(significant&&heirs[1]&&heirs[0].claim-heirs[1].claim<=12&&l.owner===s.player){s.successionDisputes.push({lord:l.id,started:s.turn,heirs:heirs.slice(0,2).map(h=>h.id)});archive(s,l.name+' mirasında iki güçlü varis karşı karşıya. Hükümdarın kararını bekliyor.',l.owner,'war');return true}
  inherit(s,l,heirs[0]);return true;
 }
 function monthly(s){
  communities(s);if(E.stateMode(s))return;
  if(!s.lordshipVersion)for(const l of s.lords){if(!l.alive)continue;l.ageMonths++;for(const p of l.family)if(p.alive)p.ageMonths++;death(s,l)}
  for(const n of nids){const q=s.nations[n];q.authority=clamp(q.authority+((q.stability+q.dynasty.legitimacy)/2-q.authority)*.02,0,100);if(!own(s,n).length)continue;
   for(const {kind,actor:a} of actors(s,n)){if(a.demand||s.turn-a.lastDemand<36||s.turn%24||(s.characterSchema?E.getCharacters().demandAmbition(s,n,a):a.ambition)<72||power(s,n,kind,a)<35)continue;a.demand={goal:kind==='commander'?'office':kind==='lord'?'autonomy':'budget',started:s.turn,deadline:s.turn+6};a.lastDemand=s.turn;archive(s,a.name+' yeni siyasi talep sundu: '+(a.demand.goal==='office'?'başkomutanlık':a.demand.goal==='autonomy'?'daha fazla özerklik':'saray bütçesi')+'.',n,'war');if(n!==s.player)respond(s,n,kind,a.id,q.gold>=100?'negotiate':'refuse')}
  }
 }
 function respond(s,n,kind,id,choice){
  const a=actor(s,n,kind,id),q=s.nations[n];if(!a||!a.demand)throw Error('Bekleyen siyasi talep bulunamadı.');if(!['grant','refuse','negotiate'].includes(choice))throw Error('Geçerli siyasi cevap seç.');if(choice==='negotiate'&&q.gold<100)throw Error('Müzakere için 100 altın gerekli.');
  if(choice==='grant'){
   if(kind==='commander'){q.chiefCommander=a.id;a.influence=clamp(a.influence+10,0,100)}else if(kind==='lord'){a.tax=Math.max(.2,Math.round((a.tax-.1)*100)/100);a.levy=.2;q.authority=clamp(q.authority-3,0,100)}else{if(q.gold<100)throw Error('Bütçe için 100 altın gerekli.');q.gold-=100}a.loyalty=clamp(a.loyalty+15,0,100);a.opposition=Math.max(0,a.opposition-20);
  }else if(choice==='negotiate'){q.gold-=100;a.loyalty=clamp(a.loyalty+8,0,100);a.opposition=Math.max(0,a.opposition-12)}else{a.loyalty=clamp(a.loyalty-12,0,100);a.opposition=clamp(a.opposition+20,0,100)}
  a.demand=null;archive(s,a.name+' talebi '+(choice==='grant'?'kabul edildi':choice==='refuse'?'reddedildi; muhalefeti arttı':'müzakereyle yatıştırıldı')+'.',n,choice==='refuse'?'war':'good');return 'Siyasi talep cevaplandı; anında isyan başlamadı.';
 }
 function handle(s,a){const n=s.player,q=s.nations[n];
  if(a.type==='communityPolicy'){const p=s.provinces[a.province];if(!p||p.owner!==n||!Object.hasOwn(civic,a.civic)||!Object.hasOwn(cultural,a.cultural))throw Error('Kendi şehrini ve geçerli iki politika seç.');if(q.gold<80)throw Error('İdari geçiş için 80 altın gerekli.');if((q.cooldowns['community-'+a.province]||0)>s.turn)throw Error('Şehir politikası 12 ayda bir değişir.');q.gold-=80;p.civicPolicy=a.civic;p.culturalPolicy=a.cultural;q.cooldowns['community-'+a.province]=s.turn+12;return 'Bağlılık yönetimi ve kültür politikası ayrı ayrı kaydedildi.'}
  if(a.type==='successionChoice'){
   const dispute=s.successionDisputes.find(d=>d.lord===a.lord),l=G.lord(s,a.lord);if(!dispute||!l||l.owner!==n)throw Error('Bekleyen kendi veraset anlaşmazlığını seç.');if(a.choice==='crown'){if(q.gold<150)throw Error('Müdahale için 150 altın gerekli.');q.gold-=150;q.stability=clamp(q.stability-6,0,100);q.authority=clamp(q.authority-4,0,100);for(const x of s.lords.filter(x=>x.owner===n&&x!==l))x.loyalty=clamp(x.loyalty-8,0,100);revert(s,l)}else{const heir=l.family.find(h=>h.id===a.heir&&dispute.heirs.includes(h.id));if(!heir||!heir.alive||!heir.legitimate)throw Error('Geçerli meşru varis seç.');inherit(s,l,heir);l.loyalty=clamp(l.loyalty-5,0,100)}s.successionDisputes=s.successionDisputes.filter(d=>d!==dispute);return 'Veraset anlaşmazlığı çözüldü.';
  }
  if(a.type==='politicalResponse')return respond(s,n,a.kind,a.actor,a.choice);
  if(a.type==='mobilizeReserve'){
   const p=s.provinces[a.province],total=G.sum(q.reserveUnits);if(!p||p.owner!==n||p.rebellion||!total)throw Error('Güvenli kendi şehrini ve mevcut merkez yedeğini seç.');let target=armies(s,n).find(x=>x.province===a.province&&!x.siege&&!x.path.length);if(!target&&(s.armies.length>=500||s.nextArmy>=1e6))throw Error('Ordu kayıt sınırı dolu.');if(target&&target.troops+total>1e7)throw Error('Ordu üst sınırı.');if(!target){target=E.newArmy(s,n,a.province,total,'infantry');target.units=G.empty();target.commander=null}for(const u of Object.keys(units)){target.units[u]+=q.reserveUnits[u];q.reserveUnits[u]=0}E.sync(target);return total+' mevcut yedek asker orduya alındı.';
  }return null;
 }
 function validate(s){const num=(v,a,b)=>typeof v==='number'&&Number.isFinite(v)&&v>=a&&v<=b;if(s.politicsVersion!==1||!Array.isArray(s.successionDisputes)||s.successionDisputes.length>30||!Array.isArray(s.politicalHistory)||s.politicalHistory.length>100)throw Error('İç siyaset kaydı geçersiz.');
  for(const id of ids){const p=s.provinces[id];if(!num(p.allegiance,0,100)||!Object.hasOwn(civic,p.civicPolicy)||!Object.hasOwn(cultural,p.culturalPolicy))throw Error('Şehir bağlılığı veya kültür siyaseti geçersiz.')}
  for(const l of s.lords){if(!num(l.ageMonths,0,1800)||!num(l.deathAt,600,1800)||!Number.isInteger(l.generation)||l.generation<1||!num(l.lastSuccession,-1,s.turn)||!Array.isArray(l.family)||l.family.length>4)throw Error('Bey ailesi geçersiz.');const seen=new Set();for(const p of l.family){if(typeof p.id!=='string'||seen.has(p.id)||typeof p.name!=='string'||p.name.length>250||!['child','spouse'].includes(p.relation)||typeof p.alive!=='boolean'||typeof p.legitimate!=='boolean'||!num(p.ageMonths,0,1800)||!['claim','loyalty','ambition'].every(k=>num(p[k],0,100))||!['administration','military'].every(k=>Number.isInteger(p[k])&&num(p[k],1,6)))throw Error('Varis kaydı geçersiz.');seen.add(p.id)}}
  for(const n of nids){const q=s.nations[n];if(!num(q.authority,0,100)||!q.reserveUnits||!Object.keys(units).every(u=>Number.isInteger(q.reserveUnits[u])&&num(q.reserveUnits[u],0,E.stateMode(s)?1e11:1e7))||!Array.isArray(q.council)||q.council.length!==2||q.chiefCommander!==null&&!q.commanders.some(c=>c.id===q.chiefCommander))throw Error('Merkezî yönetim geçersiz.');for(const {actor:a} of [...actors(s,n),...q.council.map(actor=>({actor})),...s.lords.filter(l=>l.owner===n).map(actor=>({actor}))]){if(!['ambition','influence','support','opposition','loyalty'].every(k=>num(a[k],0,100))||!num(a.lastDemand,-36,s.turn)||!Array.isArray(a.coalition)||a.coalition.length>12||a.demand&&(!['office','autonomy','budget'].includes(a.demand.goal)||!num(a.demand.started,0,s.turn)||!num(a.demand.deadline,a.demand.started,150000)))throw Error('Siyasi kişi geçersiz.')}}
  const seen=new Set();for(const d of s.successionDisputes){const l=G.lord(s,d.lord);if(!l||seen.has(d.lord)||!num(d.started,0,s.turn)||!Array.isArray(d.heirs)||d.heirs.length!==2||new Set(d.heirs).size!==2||d.heirs.some(id=>s.lordshipVersion?!s.people.some(p=>p.id===id&&p.alive):!l.family.some(h=>h.id===id)))throw Error('Veraset anlaşmazlığı geçersiz.');seen.add(d.lord)}for(const h of s.politicalHistory)if(!N[h.nation]||!num(h.turn,0,s.turn)||typeof h.text!=='string'||h.text.length>1000)throw Error('Siyasi tarihçe geçersiz.');return s;
 }
 return {initialize,civic,cultural,cost,communities,actors,actor,power,eligible,death,inherit,revert,monthly,respond,handle,validate,blocking:s=>!E.stateMode(s)&&s.successionDisputes.some(d=>G.lord(s,d.lord)?.owner===s.player)};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createPolitics;else root.createAnadoluPolitics=createPolitics;
})(typeof globalThis!=='undefined'?globalThis:this);
