/* Wide workspaces for dense ledgers; compact city drawers keep their existing layout. */
const workspaceChoices=new Map();
$('#ui-workspace-close').insertAdjacentHTML('beforebegin','<button id="ui-workspace-size" class="ui-workspace-size" aria-pressed="false">Geniş ekran</button>');
function updateWorkspaceSize(){
 $('#game-shell').dataset.workspaceTab=screen==='depth'?depthTab:'';
 const key=screen==='depth'?'depth:'+depthTab:screen;
 const wide=!['atlas','war'].includes(screen)&&(workspaceChoices.get(key)??(screen==='history'||screen==='depth'&&['missions','command','trade'].includes(depthTab)));
 $('#game-shell').classList.toggle('wide-workspace',wide);
 const button=$('#ui-workspace-size');button.textContent=wide?'Küçült':'Geniş ekran';button.setAttribute('aria-pressed',String(wide));button.title=wide?'Sağdaki küçük panele dön':'Geniş çalışma ekranını aç';
 if(screen==='depth'&&depthTab==='missions')$('#ui-workspace-title').textContent='Görev Ağacı';
}
$('#ui-workspace-size').addEventListener('click',()=>{const key=screen==='depth'?'depth:'+depthTab:screen;workspaceChoices.set(key,!$('#game-shell').classList.contains('wide-workspace'));updateWorkspaceSize()});
const workspaceScreen=switchScreen;switchScreen=function(name){workspaceScreen(name);updateWorkspaceSize()};
const workspaceDepth=renderDepth;renderDepth=function(){workspaceDepth();updateWorkspaceSize()};
