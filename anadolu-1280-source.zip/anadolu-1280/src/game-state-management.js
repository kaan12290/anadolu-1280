/* State-focused play. Legacy households remain inert records; their assets transfer once. */
(function(root){'use strict';
function createStateManagement(E){
 const {ids,nids,units,stateMode}=E,kinds=Object.keys(units),empty=()=>Object.fromEntries(kinds.map(u=>[u,0]));
 const blocked=new Set(['heir','dynastyCouncil','dynastyChoice','marriage','lordMarriage','successionChoice','politicalResponse','containActor','rebelResponse','grantEstate','revokeEstate','lordContract','lordBuild','lordRecruit','callLevy','fundLord','cityTitle','transferCity','lordAudience','promoteLord','setLiege','dismissGovernor']);
 function initialize(s){
  if(s.managementVersion===1)return s;
  const archive={turn:s.turn,governors:{},disputes:JSON.parse(JSON.stringify(s.successionDisputes)),dynasties:{},transfers:[],rebels:[]};
  for(const id of ids){const p=s.provinces[id];if(p.governor)archive.governors[id]=p.governor;p.governor=null;
   if(p.rebellion?.cause==='dynastic'){p.rebellion=null;p.organization=0}
  }
  for(const l of s.lords){const q=s.nations[l.owner];
   archive.transfers.push({lord:l.id,owner:l.owner,gold:l.treasury,manpower:l.manpower,units:{...l.units},demand:l.demand,ultimatum:l.ultimatum,opposition:l.opposition,commanderId:l.commanderId||null});
   q.gold+=l.treasury;q.manpower+=l.manpower;for(const u of kinds)q.reserveUnits[u]+=l.units[u];
   l.treasury=0;l.manpower=0;l.units=empty();l.demand=null;l.ultimatum=null;l.rebelId=null;l.opposition=0;l.coalition=[];l.commanderId=null;l.inactive=true;
  }
  for(const r of s.rebelArmies.filter(r=>r.status==='active')){const q=s.nations[r.owner];
   archive.rebels.push({id:r.id,owner:r.owner,units:{...r.units},wounded:{...r.wounded},gold:r.treasury});
   q.gold+=r.treasury;for(const u of kinds){q.reserveUnits[u]+=r.units[u];q.casualties.wounded[u]+=r.wounded[u]}
   r.units=empty();r.wounded=empty();r.treasury=0;r.status='resolved';r.resolution='state-management';
   const p=s.provinces[r.province];if(p.rebellion?.rebelId===r.id){p.rebellion=null;p.organization=0}
  }
  for(const n of nids){const q=s.nations[n];archive.dynasties[n]=JSON.parse(JSON.stringify(q.dynasty));
   q.dynasty.crisis=null;q.dynasty.civilWar=null;q.chiefCommander=null;
   for(const a of [...q.commanders,...q.council]){a.demand=null;a.ultimatum=null;a.rebelId=null;a.opposition=0;a.coalition=[]}
  }
  s.successionDisputes=[];s.managementArchive=archive;const migrated=!stateMode(s)||s.lords.length>0;s.managementMode='state';s.managementVersion=1;if(migrated)E.log(s,'Şehirler doğrudan devlet idaresine alındı. Önceki iç siyaset krizleri kapatıldı; mevcut hazine ve askerler merkeze aktarıldı.','good');
  return s;
 }
 function handle(s,a){if(!stateMode(s))return null;if(blocked.has(a.type))throw Error('Hanedan, iç siyaset ve yerel bey yönetimi bu sürümde kapalı.');
  if(a.type!=='dismissCommander')return null;const q=s.nations[s.player],c=q.commanders.find(c=>c.id===a.commander&&!c.retired&&!c.suspended);
  if(!c)throw Error('Görevdeki kendi komutanını seç.');for(const army of E.armies(s,s.player))if(army.commander===c.id)army.commander=null;c.suspended=true;return 'Komutan görevden alındı; mevcut askerler ordularında kaldı.';
 }
 function validate(s){if(s.managementVersion!==undefined&&!stateMode(s))throw Error('Devlet yönetimi sürümü ve modu tutarsız.');if(!stateMode(s))return s;
  if(s.managementVersion!==1||!s.managementArchive||!Number.isInteger(s.managementArchive.turn)||s.managementArchive.turn<0||s.managementArchive.turn>s.turn)throw Error('Devlet yönetimi dönüşüm kaydı geçersiz.');
  if(ids.some(id=>s.provinces[id].governor!==null)||s.successionDisputes.length||s.rebelArmies.some(r=>r.status==='active'))throw Error('Kapatılan yönetim sistemi yeniden etkinleşmiş.');
  for(const l of s.lords)if(l.treasury||l.manpower||kinds.some(u=>l.units[u])||l.demand||l.rebelId)throw Error('Arşivde etkin bey kaynağı bulunamaz.');
  for(const n of nids){const q=s.nations[n];if(q.dynasty.crisis||q.dynasty.civilWar||[...q.commanders,...q.council].some(a=>a.demand||a.rebelId||a.ultimatum!==null))throw Error('Etkin iç siyaset kaydı bulunamaz.')}
  return s;
 }
 return {initialize,handle,validate,blocked};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createStateManagement;else root.createAnadoluStateManagement=createStateManagement;
})(typeof globalThis!=='undefined'?globalThis:this);
