/* Persistent people, independent offices and read-through legacy projections. */
(function(root){'use strict';
function createCharacters(E){
 const {N,P,nids,own,profile,clamp}=E,L=E.lordship,G=E.statecraft;
 const catalogue=E.C.characters||(typeof module!=='undefined'&&module.exports?require('../source-data/characters-1280.json'):{});
 const skillNames={diplomacy:'Diplomasi',military:'Askerî yönetim',administration:'İdare',intrigue:'Entrika',learning:'Öğrenim'};
 const traitNames={ambitious:'Hırslı',loyal:'Sadık',brave:'Cesur',cautious:'Temkinli',greedy:'Açgözlü',generous:'Cömert',merciful:'Merhametli',cruel:'Zalim',proud:'Gururlu',conciliatory:'Uzlaşmacı'};
 const opposite={brave:'cautious',cautious:'brave',greedy:'generous',generous:'greedy',merciful:'cruel',cruel:'merciful',proud:'conciliatory',conciliatory:'proud'};
 const oldTraits={'hırslı':'ambitious','temkinli':'cautious','uzlaşmacı':'conciliatory'};
 const hash=v=>[...v].reduce((h,c)=>(Math.imul(h,31)+c.charCodeAt(0))>>>0,1280);
 const indexes=new WeakMap();
 function get(s,id){if(!s.people)return null;let cache=indexes.get(s);if(!cache||cache.array!==s.people||cache.size!==s.people.length){cache={array:s.people,size:s.people.length,people:new Map(s.people.map(p=>[p.id,p]))};indexes.set(s,cache)}return cache.people.get(id)||null}
 const date=t=>({year:1280+Math.floor(t/12),month:(t%12+12)%12+1,precision:'month'});
 const dynastyId=name=>'dynasty-'+hash(name||'Bilinmeyen hane').toString(36);
 const repeatedRulers={mamluk:{'en-Nâsır Muhammed':'nasir-muhammed'}};
 const rulerToken=(n,r)=>'ruler:'+n+':'+(Object.entries(catalogue).find(([,v])=>v.nation===n&&v.rulerNames?.includes(r.name))?.[0]||repeatedRulers[n]?.[r.name]||r.name+'@'+r.from);
 const specFor=(n,name,role=null)=>Object.entries(catalogue).find(([,v])=>v.nation===n&&(role?v.courtRoles?.includes(role)&&v.name===name:v.rulerNames?.includes(name)));
 function addTrait(p,t){if(!traitNames[t])return;p.traits=p.traits.filter(v=>v!==opposite[t]);if(!p.traits.includes(t))p.traits.push(t);p.traits=p.traits.slice(0,3)}
 function register(s,p,{fresh=false}={}){
  if(p.characterId)return p;
  const h=hash(p.id);p.characterId=p.id;p.dynastyId=dynastyId(p.house);p.branchId=p.dynastyId;
  p.culture=profile(p.owner).culture;p.skills={diplomacy:7+h%8,military:p.military*3,administration:p.administration*3,intrigue:5+(h>>>4)%10,learning:7+(h>>>8)%8};
  p.traits=[];addTrait(p,['cautious','brave','generous','merciful','proud','conciliatory'][h%6]);if(p.ambition>=72)addTrait(p,'ambitious');else if(p.loyalty>=75)addTrait(p,'loyal');
  p.opinions={};p.partnerIds=p.spouse?[p.spouse]:[];p.officeHistory=[];p.sourceStatus=p.source==='historical'&&!/\(oyun\)|meclis|alternatif/i.test(p.name)?'uncertain':'fictional';p.sources=p.sourceUrl?[p.sourceUrl]:[];
  p.origin=p.ageMonths===0&&p.born===s.turn?'simulated-birth':fresh?'initial':'legacy';
  p.birth={...date((p.alive?s.turn:p.died??s.turn)-p.ageMonths),precision:'scenario'};p.ageBasis='scenario';p.deathDate=p.alive?null:p.died===null?{year:null,month:null,precision:'unknown'}:date(p.died);p.deathProcessed=!p.alive;
  return p;
 }
 function create(s,fields){const p=L.createPerson(s,fields);return register(s,p,{fresh:s.characterFresh})}
 function historical(s,key,existing=null){
  const spec=catalogue[key];if(!spec)return existing;
  let p=get(s,s.characterLinks[key])||s.people.find(p=>p.historicalKey===key)||existing;
  if(!p)p=create(s,{name:spec.name,house:spec.dynasty,owner:spec.nation,source:'historical',sourceUrl:spec.sources[0],ageMonths:12*(spec.scenarioAge||40),alive:!(spec.deathYear<1280),died:spec.deathYear<1280?(spec.deathYear-1280)*12:null});
  register(s,p,{fresh:s.characterFresh});s.characterLinks[key]=p.id;p.historicalKey=key;p.sourceStatus='verified';p.sources=[...spec.sources];p.source='historical';p.sourceUrl=spec.sources[0];p.historicalNote=spec.note;
  // Migrations preserve played ages, names, households and relatives. Initial dates are labelled by precision.
  if(s.characterFresh){p.house=spec.dynasty;p.dynastyId=dynastyId(p.house);p.branchId=p.dynastyId;if(spec.birthYear){p.birth={year:spec.birthYear,month:null,precision:spec.birthPrecision};p.ageMonths=((p.alive?1280:spec.deathYear||1280)-spec.birthYear)*12;p.ageBasis=spec.birthPrecision}else if(spec.scenarioAge){p.ageMonths=spec.scenarioAge*12;p.birth={year:null,month:null,precision:'unknown'};p.ageBasis='scenario'}if(!p.alive&&spec.deathYear)p.deathDate={year:spec.deathYear,month:null,precision:'year'}}
  return p;
 }
 function family(s,id){const p=get(s,id);if(!p)return {parents:[],spouses:[],children:[],siblings:[]};return {parents:p.parents.map(id=>get(s,id)).filter(Boolean),spouses:[...new Set([p.spouse,...p.partnerIds].filter(Boolean))].map(id=>get(s,id)).filter(Boolean),children:s.people.filter(x=>x.parents.includes(id)),siblings:s.people.filter(x=>x.id!==id&&x.parents.some(id=>p.parents.includes(id)))};}
 function opinion(s,from,to){const a=get(s,from),b=get(s,to);if(!a||!b)return 0;if(Number.isFinite(a.opinions[to]))return a.opinions[to];const f=family(s,from);return clamp((a.dynastyId===b.dynastyId?10:0)+(f.parents.includes(b)||f.children.includes(b)||f.siblings.includes(b)?15:0)+(f.spouses.includes(b)?20:0),-100,100)}
 function adjustOpinion(s,from,to,delta){const p=get(s,from);if(!p||!get(s,to)||from===to)return;p.opinions[to]=clamp(opinion(s,from,to)+delta,-100,100);const entries=Object.keys(p.opinions);if(entries.length>32)delete p.opinions[entries.find(id=>id!==to)];}
 function bindRole(s,role,kind){
  const p=get(s,role.personId);if(!p)return;register(s,p);role.characterId=role.personId;
  const keys=kind==='lord'?['name','house','ageMonths','administration','military','ambition','loyalty']:['name','ambition','loyalty'];
  for(const key of keys){const fallback=role[key];Object.defineProperty(role,key,{enumerable:true,configurable:true,get(){return get(s,this.personId)?.[key]??fallback},set(value){const q=get(s,this.personId);if(q){const old=q[key];q[key]=value;if(key==='administration'&&old!==value)q.skills.administration=clamp(value*3,0,20)} }});}
  Object.defineProperty(role,'characterId',{enumerable:true,configurable:true,get(){return this.personId},set(id){this.personId=id}});
  if(kind==='commander'){
   if(!p.commandSkills){p.commandSkills={command:role.command,siege:role.siege,cavalry:role.cavalry};p.skills.military=clamp(role.command*3,0,20)}
   for(const key of ['command','siege','cavalry'])Object.defineProperty(role,key,{enumerable:true,configurable:true,get(){return get(s,this.personId).commandSkills[key]},set(v){const q=get(s,this.personId);q.commandSkills[key]=v;if(key==='command')q.skills.military=clamp(v*3,0,20)}});
   role.sharedLoyalty=p.loyalty;
  }
  if(kind==='lord'&&!Object.getOwnPropertyDescriptor(role,'personality')?.get){addTrait(p,oldTraits[role.personality]);Object.defineProperty(role,'personality',{enumerable:true,configurable:true,get(){return traitNames[get(s,this.personId)?.traits[0]]||'Temkinli'},set(value){addTrait(get(s,this.personId),oldTraits[value]||Object.keys(traitNames).find(k=>traitNames[k]===value))}})}
 }
 function ensureOfficer(s,n,role,descriptor){
  const q=s.nations[n],token='court:'+n+':'+role+':'+(descriptor?descriptor.name+'@'+descriptor.from:'fictional'),spec=descriptor&&specFor(n,descriptor.name,role);
  let p=get(s,s.characterLinks[token]);
  if(!p||!p.alive){const replacement=!!p;p=!replacement&&spec?historical(s,spec[0]):create(s,{name:!replacement&&descriptor?descriptor.name:E.roles[role].name+' (oyun)',house:descriptor?profile(n).dynasty:N[n].short+' Sarayı',owner:n,source:!replacement&&descriptor?'historical':'office',ageMonths:40*12,note:!replacement&&descriptor?'Mevcut tarihî kadrodan taşındı; ayrıntılı aile bilgisi doğrulanmadı.':'Oyun tarafından oluşturulmuş saray görevlisi.'});s.characterLinks[token]=p.id}
  return p;
 }
 function reconcile(s,{initial=false}={}){
  if(!s.characterSchema)return;
  for(const p of s.people)register(s,p);
  for(const n of nids){const q=s.nations[n],raw=E.rulerDescriptor(s,n),token=rulerToken(n,raw),spec=specFor(n,raw.name);
   if(q.characterRulerToken!==token){let p=get(s,s.characterLinks[token]);const old=get(s,q.crownPerson);
    if(!p){const existing=initial&&old?.name===raw.name?old:null;p=spec?historical(s,spec[0],existing):existing||create(s,{name:raw.name,house:profile(n).dynasty||N[n].short,owner:n,source:/\(oyun\)|meclis|alternatif/i.test(raw.name+' '+raw.title)?'scenario':'historical',note:'Mevcut hükümdar takviminden taşındı; ek aile ilişkisi varsayılmadı.'});s.characterLinks[token]=p.id}
    if(old&&old.id!==p.id)archiveOffice(old,s,'Hükümdarlık görevi sona erdi');q.crownPerson=p.id;q.characterRulerToken=token;
   }
   q.advisorCharacters??={};
   for(const role of Object.keys(E.roles)){const descriptor=profile(n).court.find(p=>p.role===role&&p.from<=s.turn&&p.until>s.turn);let p;
    if(role==='marshal'&&descriptor){const c=q.commanders.find(c=>c.historical&&c.name===descriptor.name&&get(s,c.personId)?.alive);p=c&&get(s,c.personId)}
    p??=ensureOfficer(s,n,role,descriptor);q.advisorCharacters[role]=p.id;const council=q.council.find(c=>c.role===role);if(council){if(initial&&!council.personId){p.loyalty=council.loyalty;p.ambition=council.ambition}if(council.personId&&council.personId!==p.id)archiveOffice(get(s,council.personId),s,'Saray görevi sona erdi');council.personId=p.id;bindRole(s,council,'council')}
   }
   for(const c of q.commanders){if(!get(s,c.personId)){const p=create(s,{name:c.name,house:N[n].short+' Sarayı',owner:n,source:c.historical?'historical':'office',military:Math.max(1,c.command),ambition:c.ambition,loyalty:c.loyalty,ageMonths:40*12,note:c.historical?'Önceki komutan kadrosundan taşındı; yaşam ayrıntıları belirsiz.':'Oyun komutanı.'});c.personId=p.id}bindRole(s,c,'commander')}
  }
  for(const l of s.lords)bindRole(s,l,'lord');
  for(const p of s.people){if(p.spouse){const q=get(s,p.spouse);if(q){if(!p.partnerIds.includes(q.id))p.partnerIds.push(q.id);if(!q.partnerIds.includes(p.id))q.partnerIds.push(p.id)}}}
  for(const m of s.lordMarriages){const a=get(s,m.a),b=get(s,m.b);if(a&&b){if(!a.partnerIds.includes(b.id))a.partnerIds.push(b.id);if(!b.partnerIds.includes(a.id))b.partnerIds.push(a.id)}}
 }
 function initialize(s,{fresh=false}={}){
  if(s.characterSchema){reconcile(s);return s}
  s.characterSchema=1;s.characterLinks={};s.characterLastAge=s.turn;s.characterHistory=[];s.characterFresh=fresh;
  // Preserve existing authority and personal values before attaching legacy views.
  for(const p of s.people)register(s,p,{fresh});
  for(const l of s.lords){const p=get(s,l.personId);for(const k of ['name','house','ageMonths','administration','military','ambition','loyalty'])p[k]=l[k];p.skills.administration=p.administration*3;p.skills.military=p.military*3;addTrait(p,oldTraits[l.personality]);}
  for(const [key,spec] of Object.entries(catalogue)){if(spec.province){const l=G.governor(s,spec.province),p=l&&get(s,l.personId);if(p?.source==='historical'&&p.name===spec.name)historical(s,key,p)}}
  reconcile(s,{initial:true});
  // Only explicit, sourced relationships are added. Existing played families are never rewritten.
  for(const [key,spec] of Object.entries(catalogue).filter(([,v])=>v.parents)){const p=historical(s,key);if(fresh||!p.parents.length)for(const parentKey of spec.parents){const parent=historical(s,parentKey);if(parent&&!p.parents.includes(parent.id)&&p.parents.length<2)p.parents.push(parent.id)}}
  delete s.characterFresh;reconcile(s);return s;
 }
 function roles(s,id){const p=get(s,id);if(!p?.alive)return [];const out=[];
  for(const n of nids){const q=s.nations[n];if(q.crownPerson===id&&own(s,n).length)out.push({kind:'ruler',nation:n,label:E.rulerDescriptor(s,n).title+' · '+N[n].short});for(const c of q.commanders)if(c.personId===id&&!c.retired&&!c.suspended)out.push({kind:'commander',nation:n,id:c.id,label:'Komutan · '+N[n].short});for(const role of Object.keys(E.roles))if(q.advisors[role]&&q.advisorCharacters[role]===id)out.push({kind:'advisor',nation:n,id:role,label:E.roles[role].title+' · '+N[n].short})}
  for(const l of s.lords.filter(l=>l.personId===id&&l.alive))for(const city of G.cities(s,l))out.push({kind:'lord',nation:l.owner,id:l.id,city,label:P[city].name+' · '+(l.rank===2?'Bölge beyi':'Şehir yöneticisi')});return out;
 }
 function archiveOffice(p,s,text){if(!p)return;p.officeHistory.push({turn:s.turn,text});p.officeHistory=p.officeHistory.slice(-40)}
 function rememberDeath(s,p,cause='Mevcut veraset / yaşam akışı'){
  if(!s.characterSchema||p.deathProcessed)return false;
  for(const r of roles(s,p.id))archiveOffice(p,s,r.label);p.deathProcessed=true;const spec=catalogue[p.historicalKey],when=date(s.turn);p.deathDate=spec?.deathYear===when.year?{year:when.year,month:spec.deathPrecision==='month'?when.month:null,precision:spec.deathPrecision||'year'}:when;p.deathCause=cause;p.died=s.turn;
  if(p.spouse){const q=get(s,p.spouse);if(q){if(!p.partnerIds.includes(q.id))p.partnerIds.push(q.id);if(!q.partnerIds.includes(p.id))q.partnerIds.push(p.id)}}
  s.characterHistory.unshift({turn:s.turn,characterId:p.id,text:p.name+' vefat etti.'});s.characterHistory=s.characterHistory.slice(0,200);return true;
 }
 function die(s,id,cause='Yaşlılık'){
  const p=get(s,id);if(!p?.alive||p.deathProcessed)return false;
  const titles=s.lords.filter(l=>l.personId===id&&l.alive);
  rememberDeath(s,p,cause);
  // A deceased rebel leader's remaining soldiers return to existing reserve/wounded pools once.
  for(const r of s.rebelArmies.filter(r=>r.status==='active')){const actor=r.kind==='lord'?G.lord(s,r.actor):s.nations[r.owner].commanders.find(c=>c.id===r.actor);if(actor?.personId!==id)continue;const q=s.nations[r.owner];for(const u of Object.keys(E.units)){q.reserveUnits[u]+=r.units[u];q.casualties.wounded[u]+=r.wounded[u];r.units[u]=0;r.wounded[u]=0}if(r.kind==='lord')actor.treasury+=r.treasury;else q.gold+=r.treasury;r.treasury=0;r.status='resolved';r.resolution='leader-death';r.characterId=id;const city=s.provinces[r.province];if(city.rebellion?.rebelId===r.id){city.rebellion=null;city.organization=0}actor.rebelId=null;actor.demand=null;actor.ultimatum=null;}
  for(const l of titles)L.death(s,l,true);
  p.alive=false;p.died=s.turn;if(p.spouse){const q=get(s,p.spouse);if(q)q.spouse=null;p.spouse=null}
  for(const n of nids){const q=s.nations[n];for(const c of q.commanders)if(c.personId===id){c.retired=true;c.suspended=true;c.demand=null;c.ultimatum=null;if(q.chiefCommander===c.id)q.chiefCommander=null;for(const a of E.armies(s,n))if(a.commander===c.id)a.commander=null}for(const role of Object.keys(E.roles))if(q.advisorCharacters[role]===id)q.advisors[role]=false}
  return true;
 }
 function age(s){if(s.characterLastAge===s.turn)return;const delta=s.turn-s.characterLastAge;if(delta<0)throw Error('Karakter takvimi geriye gidemez.');s.characterLastAge=s.turn;for(const p of s.people)if(p.alive)p.ageMonths+=delta;}
 function monthly(s){
  age(s);reconcile(s);
  const expired=new Set(nids.flatMap(n=>s.nations[n].commanders).filter(c=>c.historical&&!c.retired&&s.turn>=c.until).map(c=>c.personId));
  for(const p of [...s.people]){if(!p.alive)continue;const spec=catalogue[p.historicalKey],dated=spec?.deathTurn!==undefined&&s.turn>=spec.deathTurn,commander=expired.has(p.id);if(dated||commander||p.ageMonths>=1080){const crownNation=nids.find(n=>s.nations[n].crownPerson===p.id);if(die(s,p.id,dated?'Kaynaklı tarihî takvim':commander?'Mevcut komutan takvimi':'Yaşlılık')&&crownNation&&p.ageMonths>=1080&&!dated){const q=s.nations[crownNation];q.dynasty.crisis??={kind:'succession',started:s.turn};E.depth.dynastyChoice(s,crownNation,'accept')}}}
  reconcile(s);
 }
 const crown=(s,n)=>get(s,s.nations[n]?.crownPerson);
 const advisor=(s,n,role)=>get(s,s.nations[n]?.advisorCharacters?.[role]);
 const administrativeDrift=(s,id)=>{const p=get(s,id);return p?.alive?(p.skills.administration-10)*.005:0};
 const culturalGain=(s,n)=>3+(s.nations[n].advisors.envoy?1+Math.floor((advisor(s,n,'envoy')?.skills.learning??10)/10):0);
 function audienceGain(s,l){const p=crown(s,l.owner);return clamp(10+Math.floor(((p?.skills.diplomacy??10)-10)/4)+Math.floor(opinion(s,l.personId,p?.id)/30)+(get(s,l.personId)?.traits.includes('conciliatory')?1:0)-(get(s,l.personId)?.traits.includes('proud')?1:0),7,14)}
 function demandAmbition(s,n,a){const p=get(s,a.personId),q=s.nations[n],r=crown(s,n);return a.ambition+(p?.traits.includes('ambitious')?5:0)+(p?.traits.includes('greedy')?3:0)-(p?.traits.includes('generous')?2:0)+(p?.traits.includes('proud')?2:0)-(p?.traits.includes('conciliatory')?3:0)-(p?.traits.includes('cautious')&&s.wars.length?2:0)+(p?.traits.includes('brave')&&q.authority<40?1:0)-(p?.traits.includes('loyal')?4:0)-Math.floor(opinion(s,p?.id,r?.id)/30)+(q.gold===0?2:0)-(s.wars.some(w=>w.a===n||w.b===n)&&q.authority>=70?2:0)}
 function beforeAction(s,a){const l=a.lord?G.lord(s,a.lord):a.province?G.governor(s,a.province):null,actor=a.actor?(E.politics.actor(s,s.player,a.kind,a.actor)||s.nations[s.player].commanders.find(c=>c.id===a.actor)||s.nations[s.player].council.find(c=>c.id===a.actor)):null;return {personId:l?.personId||actor?.personId,oldTenure:l?.tenure}}
 function afterAction(s,a,before){reconcile(s);const p=get(s,before?.personId),r=crown(s,s.player);if(!p||!r)return;const delta={lordAudience:10,fundLord:5,promoteLord:15,dismissGovernor:-25,transferCity:-10,cityTitle:before.oldTenure!=='appointed'&&a.tenure==='appointed'?-20:5,politicalResponse:a.choice==='refuse'?-12:a.choice==='grant'?15:7,containActor:a.choice==='dismiss'?-15:a.choice==='mediate'?8:0}[a.type];if(a.type==='dismissGovernor'||a.type==='containActor'&&a.choice==='dismiss')archiveOffice(p,s,a.type==='dismissGovernor'?'Şehir yöneticiliğinden alındı':'Komutanlıktan alındı');if(delta){const response=delta<0?(p.traits.includes('proud')?Math.round(delta*1.2):p.traits.includes('conciliatory')?Math.round(delta*.8):delta):delta;adjustOpinion(s,p.id,r.id,response);adjustOpinion(s,r.id,p.id,Math.round(delta/2))}}
 function validate(s){
  if(s.characterSchema!==1||!s.characterLinks||!Number.isInteger(s.characterLastAge)||s.characterLastAge<0||s.characterLastAge>s.turn||!Array.isArray(s.characterHistory)||s.characterHistory.length>200)throw Error('Karakter defteri şeması geçersiz.');
  const people=new Map(s.people.map(p=>[p.id,p])),seen=new Set(),num=(v,a,b)=>Number.isFinite(v)&&v>=a&&v<=b;
  for(const p of s.people){if(p.characterId!==p.id||seen.has(p.characterId)||!p.skills||!Object.keys(skillNames).every(k=>Number.isInteger(p.skills[k])&&num(p.skills[k],0,20))||!Array.isArray(p.traits)||p.traits.length>3||new Set(p.traits).size!==p.traits.length||p.traits.some(t=>!traitNames[t]||p.traits.includes(opposite[t]))||!['verified','uncertain','fictional'].includes(p.sourceStatus)||!p.opinions||Object.entries(p.opinions).some(([id,v])=>!people.has(id)||id===p.id||!num(v,-100,100))||Object.keys(p.opinions).length>32||!Array.isArray(p.partnerIds)||new Set(p.partnerIds).size!==p.partnerIds.length||p.partnerIds.some(id=>!people.has(id)||id===p.id||!people.get(id).partnerIds.includes(p.id))||typeof p.dynastyId!=='string'||typeof p.branchId!=='string'||!Array.isArray(p.sources)||p.sources.some(u=>typeof u!=='string'||!/^https:\/\/[a-z0-9.-]+(?:\/|$)/i.test(u))||typeof p.deathProcessed!=='boolean'||!p.birth||!['scenario','unknown','year','approximate'].includes(p.birth.precision)||p.alive&&p.deathProcessed||!p.alive&&!p.deathDate||!Array.isArray(p.officeHistory)||p.officeHistory.length>40)throw Error('Tekil karakter kaydı geçersiz: '+p.id);seen.add(p.id);if(p.commandSkills&&(p.skills.military!==p.commandSkills.command*3||!['command','siege','cavalry'].every(k=>Number.isInteger(p.commandSkills[k])&&num(p.commandSkills[k],1,6))))throw Error('Komutan yetenekleri geçersiz.');}
  for(const id of Object.values(s.characterLinks))if(!people.has(id))throw Error('Tarihî kimlik bağlantısı geçersiz.');
  for(const n of nids){const q=s.nations[n];if(!get(s,q.crownPerson)||!q.advisorCharacters||Object.keys(E.roles).some(role=>!get(s,q.advisorCharacters[role])))throw Error('Saray karakter bağlantısı eksik.');for(const c of [...q.commanders,...q.council])if(c.characterId!==c.personId||!get(s,c.personId))throw Error('Görev karakter bağlantısı eksik.');}
  for(const l of s.lords)if(l.characterId!==l.personId)throw Error('Unvan sahibi karakter bağlantısı eksik.');
  return s;
 }
 return {initialize,reconcile,register,bindRole,get,crown,advisor,roles,family,opinion,adjustOpinion,age,monthly,die,rememberDeath,validate,skillNames,traitNames,catalogue,rulerToken,administrativeDrift,culturalGain,audienceGain,demandAmbition,beforeAction,afterAction,addTrait};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createCharacters;else root.createAnadoluCharacters=createCharacters;
})(typeof globalThis!=='undefined'?globalThis:this);
