/* Compatible map expansion. Existing provinces, treasuries and armies survive. */
(function(root){'use strict';
function createWorldSupport(E,createEngine){
 const revision=E.data.map?.revision,clone=x=>JSON.parse(JSON.stringify(x));
 const needsUpgrade=s=>{if(!revision)return false;if(s?.mapRevision===revision)return false;if(s?.mapRevision!==undefined)throw Error('Bu harita sürümü desteklenmiyor.');return true};
 function upgrade(text){
  if(!E.data.legacyScenario)throw Error('Önceki harita geçiş bilgisi bulunamadı.');
  const oldEngine=createEngine({...E.data.legacyScenario,campaign:E.C});
  // Validate and upgrade against the exact old geography before adding anything.
  // A damaged current-world save is never repaired by treating it as an old map.
  const raw=JSON.parse(text),oldIds=Object.keys(oldEngine.P);
  if(!raw?.provinces||Object.keys(raw.provinces).some(id=>!oldEngine.P[id])||oldIds.some(id=>!raw.provinces[id])&&raw.schema!==1)throw Error('Önceki haritanın şehir listesi eksik veya tutarsız.');
  const s=clone(oldEngine.fromJSON(text)),blank=E.createGame(s.player,s.difficulty,s.rng,s.historyMode);
  const originalNations=new Set(Object.keys(s.nations));
  for(const id of E.ids)if(!s.provinces[id])s.provinces[id]=clone(blank.provinces[id]);
  for(const id of E.nids){if(s.nations[id])continue;const q=s.nations[id]=clone(blank.nations[id]);
   delete q.crownPerson;delete q.characterRulerToken;q.advisorCharacters={};
   for(const c of [...q.commanders,...q.council])delete c.personId;
  }
  for(const a of blank.armies){if(originalNations.has(a.owner))continue;const next=clone(a);next.id='army-'+s.nextArmy++;s.armies.push(next)}
  s.mapRevision=revision;s.worldExpansion={turn:s.turn,previousProvinceCount:oldIds.length,addedProvinces:E.ids.length-oldIds.length};
  E.characters.initialize(s);E.depth.initialize(s);E.politics.initialize(s);E.conflict.initialize(s);E.diplomacy.initialize(s);E.lordship.linkCommanders(s);
  E.log(s,'Büyük Atlas açıldı: '+E.ids.length+' şehir çevresi ve '+E.playableNids.length+' siyasi alan. Önceki şehirler, askerler, hazine ve görev ilerlemesi korundu.','good');
  s.version=E.VERSION;E.validate(s);return s;
 }
 function validate(s){if(revision&&s.mapRevision!==revision)throw Error('Kayıt ile harita sürümü uyuşmuyor.');return s}
 return {revision,needsUpgrade,upgrade,validate};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createWorldSupport;else root.createAnadoluWorldSupport=createWorldSupport;
})(typeof globalThis!=='undefined'?globalThis:this);
