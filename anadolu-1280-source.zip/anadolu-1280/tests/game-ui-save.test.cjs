'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('src/game-app.js','utf8');
const key=source.match(/const SAVE_KEY='([^']+)'/)[1],read=source.match(/function readSave\(\)\{[^\n]+/)[0];
function run(values){const ctx={SAVE_KEY:key,E:{fromJSON:JSON.parse},localStorage:{getItem:k=>values.get(k)||null}};vm.createContext(ctx);vm.runInContext(read,ctx);return ctx.readSave()}
assert.equal(key,'anadolu1280-development-v040-v1');
const live=JSON.stringify({campaign:'live',turn:123}),draft=JSON.stringify({campaign:'draft',turn:1}),legacy=JSON.stringify({campaign:'legacy',turn:42});
const all=new Map([[key,live],['anadolu1280-ui-preview-v1',draft],['anadolu1280-campaign-v1',legacy]]);
assert.equal(run(all).campaign,'live');assert.equal(all.get(key),live);console.log('PASS current live campaign takes priority over UI preview and older campaign');
const old=new Map([['anadolu1280-campaign-v1',legacy]]);assert.equal(run(old).turn,42);assert.equal(old.size,1);console.log('PASS old campaign fallback is read-only');
assert.equal(run(new Map([['anadolu1280-ui-preview-v1',draft]])),null);console.log('PASS design-preview campaigns never replace a production campaign');
const corrupt=new Map([[key,'broken'],['anadolu1280-campaign-v1',legacy]]);assert.equal(run(corrupt),null);assert.equal(corrupt.get(key),'broken');assert.equal(corrupt.get('anadolu1280-campaign-v1'),legacy);console.log('PASS invalid current save is not silently overwritten');
function migrated(values,fail=false){const ctx={SAVE_KEY:key,E:{fromJSON:t=>({...JSON.parse(t),managementVersion:1})},localStorage:{getItem:k=>values.get(k)||null,setItem:(k,v)=>{if(fail)throw Error('quota');values.set(k,v)}}};vm.createContext(ctx);vm.runInContext(read,ctx);return ctx.readSave()}
const original=JSON.stringify({version:'0.4.4.1',turn:17}),backups=new Map([[key,original]]);assert.equal(migrated(backups).turn,17);assert.equal(backups.get(key+'-before-v0442'),original);assert.equal(backups.get(key),original);console.log('PASS old save is backed up byte-for-byte before the primary autosave changes');
backups.set(key,JSON.stringify({version:'0.4.4.1',turn:29}));migrated(backups);assert.equal(backups.get(key+'-before-v0442'),original);console.log('PASS repeated migration never overwrites the original backup');
const full=new Map([[key,original]]);assert.equal(migrated(full,true).turn,17);assert.equal(full.get(key),original);console.log('PASS optional backup storage quota does not corrupt or block the original save');
console.log('7 UI release save checks passed');
