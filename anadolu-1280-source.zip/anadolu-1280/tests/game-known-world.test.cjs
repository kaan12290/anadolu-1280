'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const data=JSON.parse(fs.readFileSync('dist/world-map-data.json')),svg=fs.readFileSync('dist/world-map.svg','utf8');
let count=0;const test=(name,fn)=>{fn();console.log('PASS',name);count++};
test('visible atlas contains Europe, Asia and North Africa only',()=>{const hidden=new Set(['mali','kanem','makuria','alwa','ethiopia','shewa']);const shown=data.provinces.filter(p=>p.map_visible);assert.equal(shown.length,315);assert.equal(data.regions.filter(n=>n.map_visible).length,91);assert.ok(shown.every(p=>!hidden.has(p.owner)));assert.ok(shown.filter(p=>['marinid','zayyanid','hafsid','mamluk'].includes(p.owner)).every(p=>p.lat>=23.7||p.lon>36));for(const p of data.legacyScenario.provinces)assert.ok(shown.some(q=>q.id===p.id));assert.equal(data.map.revision,'world-1280-v1');assert.equal(data.year,1280)});
test('hidden cities have no drawn control polygons, markers or search metadata in the visible atlas',()=>{for(const p of data.provinces.filter(p=>!p.map_visible))assert.ok(!svg.includes('data-province="'+p.id+'"'));for(const id of data.map.visibleProvinceIds)assert.ok(svg.includes('data-province="'+id+'"'));assert.ok(!svg.includes('world-province-lines'));assert.ok(!svg.includes('world-relief-raster'));assert.ok(!svg.includes('world-grain'))});
test('compact map keeps heraldic and city references valid without duplicate IDs',()=>{assert.ok(Buffer.byteLength(svg)<1300000);const ids=[...svg.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size);for(const ref of svg.matchAll(/(?:href="#|url\(#)([^"\s)]+)/g))assert.ok(ids.includes(ref[1]),'Missing '+ref[1]);for(const n of data.regions.filter(n=>n.map_visible))assert.ok(ids.includes('crest-'+n.id),n.id)});
test('North Africa and Anatolia views remain available and scope has period-source notes',()=>{assert.equal(data.map.views.find(v=>v.id==='africa').name,'Kuzey Afrika');assert.ok(data.map.views.some(v=>v.id==='anatolia'));assert.ok(data.cartography.sources.some(s=>s.url.includes('carta-pisana')));assert.equal(data.stats.visibleProvinces,315);assert.equal(data.stats.visibleCountries,91)});
test('land scope excludes sub-Saharan Africa while preserving North Africa, Europe and Asian cities',()=>{
 const d=svg.match(/<path id="world-land" d="([^"]+)"/)[1],rings=d.split('M').filter(Boolean).map(r=>r.replace('Z','').split('L').map(v=>v.split(',').map(Number)));
 function hasLand(lon,lat){const x=120+(lon+26)*(11200-240)/174,y=180+(73-lat)*(6000-160)/85;let inside=false;for(const r of rings){for(let i=0,j=r.length-1;i<r.length;j=i++){const [xi,yi]=r[i],[xj,yj]=r[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)inside=!inside}}return inside}
 for(const [lon,lat]of [[2.35,48.86],[32.49,37.87],[31.24,30.04],[80.7,7.3],[112.5,-7.5]])assert.ok(hasLand(lon,lat),[lon,lat]);
 for(const [lon,lat]of [[31,10],[43,5],[24,-8],[140,-5],[-22,68]])assert.ok(!hasLand(lon,lat),[lon,lat]);
});
test('camera remains within map edges on desktop and portrait screens',()=>{
 const constrain=require('../src/game-map-camera.js'),bounds=data.map.cameraBounds;
 for(const aspect of [1.7,.46,1,2.8])for(const w of [100,600,3500,20000])for(const [x,y]of [[-1e6,-1e6],[1e6,1e6],[2000,2200]]){
  const v=constrain({x,y,w},bounds,aspect),h=v.w/aspect,bw=bounds[2]-bounds[0],bh=bounds[3]-bounds[1];assert.ok(v.w>=300&&v.w<=Math.max(bw,bh*aspect));
  if(v.w<=bw)assert.ok(v.x>=bounds[0]&&v.x+v.w<=bounds[2]+1e-6);else assert.ok(Math.abs(v.x+v.w/2-(bounds[0]+bounds[2])/2)<1e-6);
  if(h<=bh)assert.ok(v.y>=bounds[1]&&v.y+h<=bounds[3]+1e-6);else assert.ok(Math.abs(v.y+h/2-(bounds[1]+bounds[3])/2)<1e-6);
 }
});
console.log(count+' known-world checks passed');
