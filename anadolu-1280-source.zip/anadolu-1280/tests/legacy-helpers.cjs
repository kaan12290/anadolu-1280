// Archived subsystem regressions; these mechanics are disabled in normal play.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const data=JSON.parse(fs.readFileSync(path.join(__dirname,'../dist/map-data.json')));data.campaign=JSON.parse(fs.readFileSync(path.join(__dirname,'../source-data/campaign-1280.json')));
const E=require('../src/game-engine.js')(data,{legacyManagement:true}),G=E.statecraft,T=E.politics,L=E.lordship,W=E.conflict;
const fresh=(n='seljuk')=>E.createGame(n,'normal',1280,'sandbox'),clone=x=>JSON.parse(JSON.stringify(x)),act=(s,a)=>{const r=E.apply(s,a);assert.equal(r.ok,true,r.message);return r},reject=(s,a)=>{const b=JSON.stringify(s);assert.equal(E.apply(s,a).ok,false);assert.equal(JSON.stringify(s),b)},close=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
function suite(label){const tests=[];return {test:(n,f)=>tests.push([n,f]),run:()=>{for(const [n,f] of tests){try{f();console.log('PASS',n)}catch(e){console.error('FAIL',n);throw e}}console.log(tests.length+' '+label+' checks passed')}}}
module.exports={assert,fs,path,E,G,T,L,W,fresh,clone,act,reject,close,suite};
