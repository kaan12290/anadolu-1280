'use strict';
const {app,BrowserWindow,Menu,session}=require('electron');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
app.setName('Anadolu 1280');
if(process.platform==='win32')app.setAppUserModelId('com.kaan.anadolu1280');
const lock=app.requestSingleInstanceLock();
let window;
if(!lock)app.quit();
function createWindow(){
 window=new BrowserWindow({width:1440,height:940,minWidth:1024,minHeight:720,title:'Anadolu 1280 — Taht ve Toprak',backgroundColor:'#1b3437',icon:path.join(__dirname,'icon.png'),autoHideMenuBar:true,show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true}});
 const entry=path.join(__dirname,'index.html'),allowed=pathToFileURL(entry).href;
 window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 window.webContents.on('will-navigate',(event,url)=>{if(url!==allowed)event.preventDefault()});
 window.once('ready-to-show',()=>window.show());
 window.loadFile(entry);
 Menu.setApplicationMenu(Menu.buildFromTemplate([{label:'Anadolu 1280',submenu:[{label:'Tam ekran',accelerator:'F11',click:()=>window.setFullScreen(!window.isFullScreen())},{type:'separator'},{label:'Çıkış',role:'quit'}]}]));
}
if(lock){app.whenReady().then(()=>{session.defaultSession.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()})});app.on('second-instance',()=>{if(window){if(window.isMinimized())window.restore();window.focus()}});app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()})}
