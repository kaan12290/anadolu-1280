# Cliopatria attribution

Source: Seshat Global History Databank, Cliopatria v0.2.1.

https://github.com/Seshat-Global-History-Databank/cliopatria

License: Creative Commons Attribution 4.0 International.

https://creativecommons.org/licenses/by/4.0/

Changes: selected 1280 and explicitly identified 1294 reference records; clipped,
merged and corrected polity outlines; added approximate city-control areas;
generated original city game regions and SVG cartography. See
`docs/V0.4.5-ATLAS.md` and `world-research/geometry-audit.json`.
