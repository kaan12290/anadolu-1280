'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('src/game-app.js','utf8');
const key=source.match(/const SAVE_KEY='([^']+)'/)[1],read=source.match(/function readSave\(\)\{[^\n]+/)[0];
function run(values){const ctx={SAVE_KEY:key,E:{fromJSON:JSON.parse},localStorage:{getItem:k=>values.get(k)||null}};vm.createContext(ctx);vm.runInContext(read,ctx);return ctx.readSave()}
assert.equal(key,'anadolu1280-development-v040-v1');
const live=JSON.stringify({campaign:'live',turn:123}),draft=JSON.stringify({campaign:'draft',turn:1}),legacy=JSON.stringify({campaign:'legacy',turn:42});
const all=new Map([[key,live],['anadolu1280-ui-preview-v1',draft],['anadolu1280-campaign-v1',legacy]]);
assert.equal(run(all).campaign,'live');assert.equal(all.get(key),live);console.log('PASS current live campaign takes priority over UI preview and older campaign');
const old=new Map([['anadolu1280-campaign-v1',legacy]]);assert.equal(run(old).turn,42);assert.equal(old.size,1);console.log('PASS old campaign fallback is read-only');
assert.equal(run(new Map([['anadolu1280-ui-preview-v1',draft]])),null);console.log('PASS design-preview campaigns never replace a production campaign');
const corrupt=new Map([[key,'broken'],['anadolu1280-campaign-v1',legacy]]);assert.equal(run(corrupt),null);assert.equal(corrupt.get(key),'broken');assert.equal(corrupt.get('anadolu1280-campaign-v1'),legacy);console.log('PASS invalid current save is not silently overwritten');
console.log('4 UI release save checks passed');
