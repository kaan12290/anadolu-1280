/* Itibar ve Nufuz: decisions stay inside one on-demand window. */
let prestigeTarget=null;
function openPrestige(target=prestigeTarget){
 if(!game)return;
 const n=game.player,q=game.nations[n],info=E.prestigeInfo(game);
 const countries=E.nids.filter(id=>id!==n&&E.own(game,id).length);
 prestigeTarget=countries.includes(target)?target:countries.find(id=>id==='byzantine'&&!E.isWar(game,n,id))||countries.find(id=>!E.isWar(game,n,id))||countries[0]||null;
 const embassy=E.prestigeQuote(game,'embassy',prestigeTarget),support=E.prestigeQuote(game,'support');
 const actionButton=(decision,quote,label)=>'<button class="primary" data-prestige-decision="'+decision+'" '+(!quote.ok?'disabled':'')+'>'+label+' · '+quote.cost+' itibar</button>';
 const reason=quote=>'<p class="prestige-reason" role="status">'+escapeHtml(quote.reason||('Yeniden kullanım: '+quote.cooldown+' ay.'))+'</p>';
 const e=embassy.effects,d=support.effects;
 const relationText=prestigeTarget&&e.before!==undefined?signed(e.before)+' → '+signed(e.after)+' ilişki':'Barıştaki başka bir ülkeyle ilişkini geliştir.';
 const supportText=d.stability!==undefined?'İstikrar '+num(q.stability)+' → '+num(q.stability+d.stability)+' · Meşruiyet '+num(q.dynasty.legitimacy)+' → '+num(q.dynasty.legitimacy+d.legitimacy)+' · Saray desteği '+num(q.dynasty.factions.court)+' → '+num(q.dynasty.factions.court+d.court):'İstikrarı, meşruiyeti ve saray desteğini güçlendir.';
 openDialog('İtibar ve Nüfuz','<div class="dialog-help prestige-window">'
  +'<div class="prestige-summary"><span class="prestige-score">'+num(info.score)+'<small>/ 100</small></span><div><p class="eyebrow">SİYASİ NÜFUZ</p><h3>'+escapeHtml(info.rank)+'</h3><p>'+(info.next?'Sonraki düzey: '+info.next+' itibar.':'En yüksek itibar düzeyindesin.')+'</p></div></div>'
  +'<div class="prestige-passive"><strong>Biriktirdiğinde</strong><p>'+(info.level?'İttifak ilişki eşiğine −'+info.allianceDiscount+'; altınla gönderilen elçilere +'+info.envoyBonus+' ek ilişki.':'İlk diplomatik bonus 40 itibarda açılır.')+'</p><small>İttifakta iki devletin yüksek olan bonusu kullanılır. Düzeyler: 40 / 60 / 80 / 100.</small></div>'
  +'<section class="prestige-decision"><h3>Elçi heyeti</h3><p>İtibarını kullanarak en çok +25 ilişki kazan. Altın harcanmaz; ittifak ayrıca önerilir.</p><label for="prestige-country">Görüşülecek devlet</label><select id="prestige-country" '+(!countries.length?'disabled':'')+'>'+(countries.length?countries.map(id=>'<option value="'+id+'" '+(id===prestigeTarget?'selected':'')+'>'+escapeHtml(E.N[id].short)+' · '+signed(E.relation(game,n,id))+(E.isWar(game,n,id)?' · Savaşta':'')+'</option>').join(''):'<option>Görüşülecek devlet yok</option>')+'</select><p class="prestige-effect">'+escapeHtml(relationText)+'</p>'+actionButton('embassy',embassy,'Heyeti gönder')+reason(embassy)+'</section>'
  +'<section class="prestige-decision"><h3>Divan desteği</h3><p>En çok +8 istikrar, +5 meşruiyet ve +5 saray desteği. Altın harcanmaz.</p><p class="prestige-effect">'+escapeHtml(supportText)+'</p>'+actionButton('support',support,'Destek topla')+reason(support)+'</section>'
  +'<p class="prestige-tradeoff">Puan harcadığında düzeyin ve diplomatik bonusun azalabilir.</p>'
  +'<details class="prestige-earning"><summary>İtibar nasıl kazanılır?</summary><p>Muharebe zaferi +3, fetih +8. Saray şölenleri ve tamamlanan görevler de itibar verir. Muharebe yenilgisi −2, şehir kaybı −6. Puan 0–100 aralığında kalır.</p></details></div>');
}
const prestigePreviousHeader=renderHeader;
renderHeader=function(){prestigePreviousHeader();const info=E.prestigeInfo(game),button=$('#open-prestige');button.setAttribute('aria-label','İtibar ve nüfuz: '+num(info.score)+' puan. Kararları aç.');button.title=info.rank+' · Nüfuz kararlarını aç';};
const prestigePreviousPalace=renderPalace;
renderPalace=function(){prestigePreviousPalace();if(!game)return;const info=E.prestigeInfo(game);$('#decision-list').insertAdjacentHTML('beforeend','<div class="decision-item"><div><strong>İtibar ve Nüfuz</strong><p>'+num(info.score)+' itibar · '+escapeHtml(info.rank)+'</p></div><button data-prestige-open>Kararları aç</button></div>');};
const prestigePreviousHelp=help;
help=function(){prestigePreviousHelp();$('#dialog-title').textContent='Nasıl oynanır? · 0.4.0-dev.1';$('#dialog-content .dialog-help').insertAdjacentHTML('beforeend','<h3>İtibar ve Nüfuz</h3><p>Üstteki itibar sayısına veya Saray Defteri içindeki İtibar ve Nüfuz kararına tıkla. 40/60/80/100 itibar düzeyleri elçilerin etkisini artırır ve ittifak için gereken ilişkiyi azaltır. 15 itibarla elçi heyeti, 20 itibarla divan desteği kullanılır. Yeniden kullanım süreleri 6 ve 12 aydır; puanı harcamak mevcut bonusunu düşürebilir.</p>');};
$('#open-prestige').addEventListener('click',()=>openPrestige());
document.addEventListener('change',e=>{if(e.target.id==='prestige-country')openPrestige(e.target.value)});
document.addEventListener('click',e=>{
 if(!game)return;
 const open=e.target.closest('[data-prestige-open]');if(open){openPrestige(open.dataset.nation||prestigeTarget);return}
 const button=e.target.closest('[data-prestige-decision]');if(!button)return;
 const result=command({type:'prestige',decision:button.dataset.prestigeDecision,nation:prestigeTarget});
 if(result?.ok)openPrestige(prestigeTarget);
});
