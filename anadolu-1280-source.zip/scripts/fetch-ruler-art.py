"""Fetch identified historical depictions and retain source/licence metadata."""
import json,urllib.request,urllib.parse,concurrent.futures,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'source-data/ruler-art';out.mkdir(exist_ok=True)
items=[
('michael8','File:Michael VIII Palaiologos.jpg',['VIII. Mihail Palaiologos'],'XIV. yüzyıl minyatürü; Pachymeres, BSB Cod. gr. 442.'),
('andronikos2','File:Miniature of Andronikos II (cropped).png',['II. Andronikos Palaiologos'],'XIV. yüzyıl minyatürü; Pachymeres el yazması.'),
('abaka','File:AbaqaEnthroned.png',['Abaka Han'],'Yaklaşık 1430 tarihli minyatür; Sayf al-Vâhidî, BnF Suppl. persan 1113, fol. 194r. Hükümdarın yaşadığı çağdan değildir.'),
('dragutin','File:Stefan Dragutin, Arilje.jpg',['Stefan Dragutin'],'1296 tarihli Arilje freski; anonim ressam.'),
('levon','File:LevonKeran.jpg',['II. Leon / III. Levon'],'1272 Kraliçe Keran İncili; Leon ve ailesini gösteren minyatür.'),
('charles1','File:Charles IofAnjou.jpg',['I. Charles d’Anjou'],'XIV. yüzyıl Anjou İncili minyatürü; Cristoforo Orimina.'),
('contarini','File:Doge Jacopo Contarini portrait.JPG',['Jacopo Contarini'],'Antonio Nani, 1867. Sonradan yapılmış tarihî tasvir; çağdaş portre değildir.'),
('david6','File:David VI Narin (Gelati fresco)-b&w.JPG',['VI. David Narin'],'Gelati freskinin siyah beyaz tarihî çoğaltması.'),
]
def request(url):
 return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Anadolu1280/0.2 historical game asset research'}),timeout=40)
def fetch(item):
 slug,title,names,note=item
 try:
  params=urllib.parse.urlencode({'action':'query','format':'json','prop':'imageinfo','iiprop':'url|extmetadata','iiurlwidth':480,'titles':title})
  with request('https://commons.wikimedia.org/w/api.php?'+params) as f:meta=json.load(f)
  page=next(iter(meta['query']['pages'].values()));info=page['imageinfo'][0];em=info['extmetadata'];license=em.get('LicenseShortName',{}).get('value','')
  if 'public domain' not in license.lower() and license.lower() not in ['cc0','pd']:return {'id':slug,'skipped':license}
  url=info.get('thumburl',info['url']);
  with request(url) as f:body=f.read()
  ext='png' if body[:4]==b'\x89PNG' else 'jpg';path=out/(slug+'.'+ext);path.write_bytes(body)
  clean=lambda v:re.sub('<[^>]+>','',v)
  return {'id':slug,'names':names,'file':str(path.relative_to(ROOT)),'source':info['descriptionurl'],'license':license,'artist':clean(em.get('Artist',{}).get('value','Anonim')),'note':note}
 except Exception as e:return {'id':slug,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(fetch,items))
(out/'credits.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps([{k:v for k,v in r.items() if k in ['id','file','error','skipped']} for r in results],ensure_ascii=False))
