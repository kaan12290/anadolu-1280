"""Original vector game illustrations. Crests interpret period motifs."""
import html

EAGLE='''<g fill="currentColor"><path d="M0-9C-8-20-20-18-26-26L-23-9-28-10-18 4-23 3-12 13-4 8-7 23 0 18 7 23 4 8 12 13 23 3 18 4 28-10 23-9 26-26C20-18 8-20 0-9Z"/><path d="M-5-7-9-17-14-17-17-21-8-23-3-19 0-13 3-19 8-23 17-21 14-17 9-17 5-7Z"/><path d="M-3 9-10 17-16 18-13 21-7 20 0 14 7 20 13 21 16 18 10 17 3 9Z"/></g>'''
LION='''<g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M-6 7Q-18 3-17-10T-24-20M-6 7-11 19-20 22M-4 5 7 17 12 23M0-4 14-11 24-10M-2-6 8-20 17-25M-4 3Q9 8 10-3L5-12-5-12-11-4Z" stroke-width="5"/><path d="M-4-13-9-20-5-28 3-28 8-22 13-20 6-16" fill="currentColor" stroke-width="2"/><path d="M-8-29-8-35-2-31 3-36 6-29Z" fill="currentColor" stroke-width="1.2"/></g>'''
MOTIFS={
 'seljuk':EAGLE,
 'byzantine':'<path d="M-4-30h8v60h-8zM-26-4h52v8h-52z" fill="currentColor"/>'+''.join(f'<text x="{x}" y="{y}" font-family="Georgia,serif" font-size="19" fill="currentColor" text-anchor="middle">B</text>' for x,y in [(-15,-10),(15,-10),(-15,23),(15,23)]),
 'trebizond':EAGLE.replace('M-5-7-9-17-14-17-17-21-8-23-3-19 0-13 3-19 8-23 17-21 14-17 9-17 5-7Z','M-4-7-6-20 0-26 9-25 16-20 8-17 5-7Z'),
 'cilicia':LION,'bulgaria':LION,
 'cyprus':'<path d="M-27-14h54m-54 12h54m-54 12h54m-54 12h54" stroke="#5a7790" stroke-width="5"/>'+LION,
 'ilkhan':'<path d="M0-31v58M-22-12h44M-18-29v18M18-29v18M-16 13 0 29 16 13" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>',
 'mamluk':'<path d="M0-32 8-19 23-23 19-8 32 0 19 8 23 23 8 19 0 32-8 19-23 23-19 8-32 0-19-8-23-23-8-19Z" fill="currentColor"/><circle r="13" fill="#a78438"/><circle r="7" fill="currentColor"/>',
 'georgia':'<path d="M-4-31h8v62h-8zM-28-4h56v8h-56z" fill="currentColor"/>'+''.join(f'<path d="M{x-2} {y-7}h4v14h-4zM{x-7} {y-2}h14v4h-14z" fill="currentColor"/>' for x,y in [(-17,-18),(17,-18),(-17,18),(17,18)]),
 'venice':'<path d="M-20 1-28-22-12-17-1-4 10-13 27-16 18 3 3 8Z" fill="currentColor"/>'+LION,
 'crusader':'<path d="M-5-30h10v60h-10zM-27-5h54v10h-54z" fill="currentColor"/>'
}
HERALDRY={
 'seljuk':('#246d72','#e1c67b','Çift başlı kartal · oyun yorumu'),
 'byzantine':('#812f38','#e4c16a','Palaiologos haçı · oyun yorumu'),
 'trebizond':('#385a7d','#e4c276','Komnenos kartalı · oyun yorumu'),
 'cilicia':('#963b30','#ead08b','Taçlı aslan · oyun yorumu'),
 'ilkhan':('#426858','#e5d6a7','Tamga · oyun yorumu'),
 'mamluk':('#b29142','#ece0b4','Sekiz kollu rozet · oyun yorumu'),
 'cyprus':('#ece2c2','#a44945','Çizgili aslan kalkanı · oyun yorumu'),
 'georgia':('#eee0bb','#a4403c','Haçlı kalkan · oyun yorumu'),
 'bulgaria':('#863b36','#e4c479','Aslan kalkanı · oyun yorumu'),
 'venice':('#9b4339','#e4c57d','Kanatlı aslan · oyun yorumu'),
 'crusader':('#a5493c','#eee3c3','Haç sancağı · oyun yorumu')
}

for key,ref,bg,fg,desc in [
 ('serbia','byzantine','#794d46','#e7d9aa','Haçlı kartal motifi'),
 ('epirus','trebizond','#7d605f','#e7cf93','Yunan kartal motifi'),
 ('thessaly','trebizond','#6e7761','#e5d5aa','Kartal motifi'),
 ('athens','crusader','#93694c','#ead7a2','Latin haç motifi'),
 ('achaea','crusader','#9b814d','#eddda7','Latin haç motifi'),
 ('cephalonia','cilicia','#7a6e4a','#eddbac','Aslan motifi'),
 ('naxos','venice','#7d6075','#ecd39b','Latin ada aslanı'),
 ('angevin','crusader','#447e89','#e9d8a4','Haç motifi'),
 ('jerusalem','crusader','#eee1bd','#b68e44','Kudüs haçı motifi')]:
 MOTIFS[key]=MOTIFS[ref]
 HERALDRY[key]=(bg,fg,desc+' · oyun yorumu')

def defs():
 out=['<defs><linearGradient id="herald-gold" x2="1" y2="1"><stop stop-color="#e8d39a"/><stop offset=".5" stop-color="#ae8a46"/><stop offset="1" stop-color="#f2dfa8"/></linearGradient><linearGradient id="roof" x2="1" y2="1"><stop stop-color="#b87e57"/><stop offset="1" stop-color="#704e3d"/></linearGradient><filter id="sprite-shadow" x="-60%" y="-60%" width="220%" height="240%"><feDropShadow dx="0" dy="1.1" stdDeviation=".7" flood-color="#192c29" flood-opacity=".4"/></filter>']
 for key,(bg,fg,desc) in HERALDRY.items():
  out.append(f'<symbol id="crest-{key}" viewBox="0 0 72 88"><title>{html.escape(desc)}</title><path d="M3 4h66v42Q69 69 36 84 3 69 3 46Z" fill="{bg}" stroke="#57452e" stroke-width="3"/><path d="M7 8h58v38Q65 65 36 79 7 65 7 46Z" fill="none" stroke="url(#herald-gold)" stroke-width="2"/><g transform="translate(36 45) scale(.78)" style="color:{fg}">{MOTIFS[key]}</g></symbol>')
  out.append(f'<symbol id="banner-{key}" viewBox="0 0 58 42"><path d="M1 2h55v37H1Z" fill="{bg}" stroke="#9d814b" stroke-width="1.7"/><path d="M2 3 12 6 23 3 36 6 55 3v35l-19-3-12 3-12-3-10 3Z" fill="#fff5cf" opacity=".07"/><g transform="translate(29 22) scale(.45)" style="color:{fg}">{MOTIFS[key]}</g></symbol>')
 out+=['''<symbol id="site-city" viewBox="-32 -38 64 60"><ellipse cx="0" cy="10" rx="29" ry="9" fill="#354b3d" opacity=".2"/><path d="m-27 6 26-13 29 13L2 20Z" fill="#c5b992" stroke="#837554" stroke-width=".6"/><path d="M-22 4v-12l9-4 9 5V8L-13 12ZM1 3v-20l10-4 12 7V7L11 12Z" fill="#e1cfaa" stroke="#6b5b44" stroke-width="1"/><path d="m-25-8 12-11 12 10-12 4Zm23-9 13-12 15 13-15 6Z" fill="url(#roof)" stroke="#5d493a" stroke-width=".8"/><path d="M-5 6v-23q5-11 12 0V7Z" fill="#bcb99c" stroke="#6b644a" stroke-width="1"/><path d="M-7-17q8-13 16 0Z" fill="#6c8d7d" stroke="#546b5e" stroke-width="1"/><path d="M-15 2v5m24-10v7m-7-24v4" stroke="#5d5040" stroke-width="2"/></symbol>''',
 '''<symbol id="site-capital" viewBox="-38 -46 76 74"><ellipse cx="0" cy="14" rx="33" ry="10" fill="#334438" opacity=".22"/><path d="m-34 7 31-16 36 16-31 19Z" fill="#b4b293" stroke="#655f44" stroke-width="1"/><path d="M-30 8v-14h6v-5h7v5h7v-5h7v5h8v-5h7v5h8v-4h8v19L2 21Z" fill="#c8b88e" stroke="#5b5540" stroke-width="1.3"/><path d="M-18-7v-18l13-5 15 8V8Z" fill="#e5d7b5" stroke="#655a42"/><path d="m-22-25 17-14 19 15-18 7Z" fill="#a4684a" stroke="#624b37"/><path d="M8-9v-20q7-13 15 0v30Z" fill="#d8c8a2" stroke="#625a42"/><path d="M6-29q9-15 19 0Z" fill="#5a8176" stroke="#4d6559"/><path d="M-2 17V7q5-8 10 0v11" fill="#4e4b3b"/><path d="M-24 2v5m9-23v5m11-6v6m21-18v5m5 17v5" stroke="#5d5040" stroke-width="2"/></symbol>''',
 '''<symbol id="site-fort" viewBox="-20 -24 40 48"><ellipse cy="15" rx="19" ry="6" fill="#374438" opacity=".22"/><path d="m-18 9 16-10 20 10-17 11Z" fill="#9d9e83"/><path d="M-16 10V-9h6v5h5v-12h9v11h5v-4h7v19L1 19Z" fill="#bab6a0" stroke="#4c5146" stroke-width="1.5"/><path d="M-4 15V6q4-6 8 0v9" fill="#4f574d"/><path d="M-12-1v5M0-9v4m12 4v5" stroke="#5e6658" stroke-width="2"/></symbol>''',
 '''<symbol id="site-port" viewBox="-20 -24 40 48"><circle cx="0" cy="1" r="16" fill="#29596b" stroke="#dbcf9e" stroke-width="1.5"/><g fill="none" stroke="#f0e1b5" stroke-width="2.3" stroke-linecap="round"><circle cy="-8" r="3"/><path d="M0-5v17M-6-1H6M-12 3q1 10 12 10T12 3m-24 0 3 2m21-2-3 2"/></g></symbol>''',
 '''<symbol id="site-crown" viewBox="-16 -12 32 24"><path d="m-13-7 7 4 6-8 6 8 7-4-3 16H-10Z" fill="#d8b85b" stroke="#604b25" stroke-width="1.4"/><path d="M-9 4H9" stroke="#f4dfa0"/></symbol>''']
 out.append('</defs>');return ''.join(out)
