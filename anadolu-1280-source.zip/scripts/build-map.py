#!/usr/bin/env python3
"""Build the historical atlas and the self-contained playable application."""
import pathlib, runpy, subprocess
scripts=pathlib.Path(__file__).resolve().parent
runpy.run_path(str(scripts/'render-atlas.py'),run_name='__main__')
runpy.run_path(str(scripts/'build-game-geography.py'),run_name='__main__')
subprocess.run(['node',str(scripts/'build-game.mjs')],check=True)
