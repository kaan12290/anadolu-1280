"""Repackage a verified existing portable Windows app with the current game build.

Keeps the Electron executable, native files, app identity and security settings.
Checks every old manifest entry, and verifies the new ZIP after writing it.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, re, struct, zipfile

ROOT = Path(__file__).resolve().parents[1]
PREFIX = 'Anadolu_1280_Windows/'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-archive', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--source-commit', required=True)
    args = parser.parse_args()
    original, output = Path(args.base_archive), Path(args.output)
    if original.resolve() == output.resolve():
        raise ValueError('Keep the previous archive as a backup')
    if not re.fullmatch(r'[0-9a-f]{40}', args.source_commit):
        raise ValueError('A full source commit SHA is required')
    version = json.loads((ROOT / 'package.json').read_text())['version']
    html = (ROOT / 'dist/index.html').read_bytes()
    if ('SÜRÜM ' + version + '<').encode() not in html:
        raise ValueError('Build the matching game version first')
    instructions = f'''ANADOLU 1280 — TAHT VE TOPRAK
{version} — Sade Tarihî Arayüz
Windows 10/11 · 64 bit · Taşınabilir uygulama

BAŞLATMA
1. ZIP dosyasına sağ tıkla ve “Tümünü ayıkla” seçeneğini kullan.
2. Anadolu_1280_Windows klasörünü aç.
3. Anadolu_1280.exe dosyasına çift tıkla.
ZIP içinden çalıştırma; dosyaları aynı klasörde birlikte tut.
Tarayıcı, internet veya hesap gerekmez. F11 ile tam ekranı açıp kapat.

MASAÜSTÜNDEN AÇMA
Anadolu_1280.exe → sağ tık → Daha fazla seçenek göster →
Gönder → Masaüstü (kısayol oluştur).
Yalnızca EXE dosyasını taşıma; klasöründeki diğer dosyalar da gereklidir.

YENİ ARAYÜZ
İnce parşömen üst çubuğu; daha geniş harita alanı.
Şehir seçilince sağda açılan şehir defteri. İnşaat, asker toplama,
ordu emirleri ve topluluklar açılır bölümlerdedir.
Saray, tarih ve devlet defterleri haritanın yanında açılır.
Üstte ayrı Diplomasi düğmesi: gelen teklifler, komşu devletler,
ilişki, güven ve tehdit. Diğer devletler de aynı panelden ulaşılabilir.
Escape ile yan panel kapanır. Harita, şehir konumları ve kurallar korunur.
Ayrıntılar SURUM_NOTLARI_{version}.md dosyasındadır.

ESKİ KAYITLAR
Önce eski oyundaki Kayıt menüsünden JSON dışa aktarımıyla yedek al.
Yeni oyundaki “Kayıt dosyası aç” ile bu dosyayı seçebilirsin.
Uygulamanın kimliği ve 0.4.0 otomatik kayıt anahtarı korunmuştur.
Klasör konumu değişirse veya kayıt görünmezse JSON ile aktar.
Site ve Windows uygulamasının kayıtları ayrıdır. Bu paket kayıtlarını silmez.
Tasarım önizlemesinin deneme seferi gerçek seferinin yerine geçirilmez.

KONTROLLER
1–5: ekran değiştir · N: ay ilerlet · Boşluk: zamanı başlat/durdur.
Harita: sürükle ve tekerlekle yakınlaştır. Oyun her emirden sonra kaydeder.
Bu çevrimdışı paket manuel güncellenir; otomatik güncelleyici içermez.

DOĞRULAMA
HTML, yayımlanacak aynı sürümün dosyasıyla birebir eşleşir.
ZIP CRC, Windows x64 PE başlığı ve tüm dosya özetleri kontrol edilir.
Mevcut çalıştırıcı ve yerel dosyalar değiştirilmeden korunur.
DOSYA_SHA256.json içindeki özetler paket içeriğini tanımlar.
Windows üzerinde EXE başlatma testi Linux ortamında yapılamadı.
Çalıştırıcı lisansları LICENSE ve LICENSES.chromium.html içindedir.
'''
    output.parent.mkdir(parents=True, exist_ok=True)
    hashes, preserved = {}, {}
    with zipfile.ZipFile(original) as old:
        if old.testzip() is not None:
            raise ValueError('Base ZIP CRC failed')
        names = [i.filename for i in old.infolist() if not i.is_dir()]
        if len(names) != len(set(names)):
            raise ValueError('Duplicate archive members')
        for name in names:
            p = PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts or '\\' in name or not name.startswith(PREFIX):
                raise ValueError('Unsafe archive path')
        manifest = json.loads(old.read(PREFIX + 'DOSYA_SHA256.json'))
        expected = {PREFIX + n for n in manifest['files']} | {PREFIX + 'DOSYA_SHA256.json'}
        if set(names) != expected:
            raise ValueError('Base manifest must cover every archive file')
        for name, digest in manifest['files'].items():
            if sha(old.read(PREFIX + name)) != digest:
                raise ValueError('Base checksum mismatch: ' + name)
        package = json.loads(old.read(PREFIX + 'resources/app/package.json'))
        if package.get('name') != 'anadolu-1280' or package.get('main') != 'main.cjs':
            raise ValueError('Unexpected application identity')
        package['version'] = version
        replacements = {
            'resources/app/index.html': html,
            'resources/app/package.json': (json.dumps(package, ensure_ascii=False, indent=2) + '\n').encode(),
            'OYUNU_BASLAT.txt': instructions.replace('\n', '\r\n').encode('utf-8-sig'),
            'SURUM_NOTLARI_' + version + '.md': (ROOT / ('docs/V' + version + '-RELEASE.md')).read_bytes(),
            'SOURCE-COMMIT.txt': (args.source_commit + '\n').encode(),
        }
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as new:
            for info in old.infolist():
                name = info.filename.removeprefix(PREFIX)
                if info.is_dir() or name in replacements or name == 'DOSYA_SHA256.json':
                    continue
                data = old.read(info.filename)
                new.writestr(info, data)
                hashes[name] = preserved[name] = sha(data)
            for name, data in replacements.items():
                new.writestr(PREFIX + name, data)
                hashes[name] = sha(data)
            new.writestr(PREFIX + 'DOSYA_SHA256.json', json.dumps({
                'algorithm': 'SHA256', 'game_version': version,
                'source_commit': args.source_commit, 'files': hashes,
            }, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(output) as new:
        if new.testzip() is not None:
            raise ValueError('Output ZIP CRC failed')
        for name, digest in hashes.items():
            if sha(new.read(PREFIX + name)) != digest:
                raise ValueError('Output checksum mismatch: ' + name)
        if new.read(PREFIX + 'resources/app/index.html') != html:
            raise ValueError('Output game differs from the tested build')
        if json.loads(new.read(PREFIX + 'resources/app/package.json'))['version'] != version:
            raise ValueError('Output application version mismatch')
        exe = new.read(PREFIX + 'Anadolu_1280.exe')
        pe = struct.unpack_from('<I', exe, 0x3c)[0]
        if exe[:2] != b'MZ' or exe[pe:pe + 4] != b'PE\x00\x00' or struct.unpack_from('<H', exe, pe + 4)[0] != 0x8664:
            raise ValueError('Output executable is not Windows x64 PE')
    report = {
        'version': version, 'archive': str(output), 'size_bytes': output.stat().st_size,
        'sha256': hashlib.file_digest(output.open('rb'), 'sha256').hexdigest(),
        'game_sha256': sha(html), 'package_file_hashes_checked': len(hashes),
        'unchanged_files': len(preserved), 'zip_crc': 'passed', 'executable_format': 'PE x86-64',
        'source_commit': args.source_commit, 'windows_execution_test': 'not available on Linux',
    }
    output.with_suffix('.validation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
