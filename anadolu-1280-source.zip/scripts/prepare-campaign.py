"""Historical reference, branching events and explicitly fictional culture weights."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def month(y,m=1):return (y-1280)*12+m-1
S={
 'seljuk':'https://islamansiklopedisi.org.tr/selcuklular#6','mesud':'https://islamansiklopedisi.org.tr/mesud-ii',
 'sahib':'https://islamansiklopedisi.org.tr/sahib-ata','osman':'https://islamansiklopedisi.org.tr/osman-i',
 'beylik':'https://islamansiklopedisi.org.tr/anadolu-beylikleri','karaman':'https://islamansiklopedisi.org.tr/karamanogullari',
 'germiyan':'https://islamansiklopedisi.org.tr/germiyanogullari','mentese':'https://islamansiklopedisi.org.tr/menteseogullari',
 'candar':'https://islamansiklopedisi.org.tr/candarogullari','hamid':'https://islamansiklopedisi.org.tr/hamidogullari',
 'ilkhan':'https://islamansiklopedisi.org.tr/ilhanlilar','abaka':'https://islamansiklopedisi.org.tr/abaka',
 'cuveyni':'https://islamansiklopedisi.org.tr/cuveyni-semseddin','memluk':'https://islamansiklopedisi.org.tr/memlukler',
 'kalavun':'https://islamansiklopedisi.org.tr/kalavun','halil':'https://islamansiklopedisi.org.tr/halil-b-kalavun',
 'katip':'https://islamansiklopedisi.org.tr/ibn-abduzzahir','bizans':'https://islamansiklopedisi.org.tr/bizans',
 'pachy':'https://islamansiklopedisi.org.tr/pachymeres-georgios','girit':'https://islamansiklopedisi.org.tr/girit',
 'cyprus':'https://mimsy.bham.ac.uk/detail.php?kv=11003100&t=people&type=related',
 'levant':'https://repository.royalholloway.ac.uk/file/f1827709-a68e-90e5-c469-7fcdd6616dd4/8/THESIS_FINAL_DRAFT.pdf',
 'trebizond':'https://research-repository.st-andrews.ac.uk/bitstream/handle/10023/8570/Jackson_Williams_Grand_Komnenoi.pdf',
 'bulgaria':'https://medievalbulgaria.com/people/ivan-asen-iii','georgia':'https://islamansiklopedisi.org.tr/gurcistan',
 'serbia':'https://www.britannica.com/place/Serbia/Medieval-Serbia',
 'thessaly':'https://www.worldhistory.org/Thessaly_and_the_Duchy_of_Neopatras/',
 'orsini':'https://en.wikipedia.org/wiki/Richard_Orsini','athens':'https://en.wikipedia.org/wiki/William_I_de_la_Roche',
 'naxos':'https://www.treccani.it/enciclopedia/sanudo-duchi-di-nasso_(Enciclopedia-Italiana)/',
 'venice':'https://www.treccani.it/enciclopedia/giovanni-dandolo_res-cf80ef38-87eb-11dc-8e9d-0016357eee51_(Dizionario-Biografico)/',
 'tripoli':'https://islamansiklopedisi.org.tr/trablussam','cilicia':'https://en.wikipedia.org/wiki/Leo_II,_King_of_Armenia'}
profiles={}
def profile(id,culture,accepted,summary,marks,rulers,source,court=None,dynasty=''):
 profiles[id]={'culture':culture,'accepted':accepted,'summary':summary,'milestones':[{'year':y,'text':t} for y,t in marks],
  'rulers':[{'from':month(y,m),'name':name,'title':title} for y,m,name,title in rulers], 'sources':[S[k] for k in source], 'court':court or [],'dynasty':dynasty}
def person(name,title,role,start=1280,end=1400):return {'name':name,'title':title,'role':role,'from':month(start),'until':month(end)}
profile('seljuk','turkish',['turkish'],'Konya merkezli sultanlık, Anadolu’daki fetihler ve ticaret yolları üzerinde yükseldi. Kösedağ’dan sonra Moğol üst hâkimiyeti güçlendi. 1280’de hanedan yaşamaya devam ederken uç beyleri ve İlhanlı müdahalesi merkezî iktidarı sınırlar.',[(1077,'Anadolu Selçuklu siyasî teşekkülü.'),(1176,'Miryokefalon zaferi.'),(1243,'Kösedağ yenilgisi; Moğol nüfuzunun güçlenmesi.'),(1277,'Baybars’ın Anadolu seferi ve Pervâne’nin sonu.')],[(1266,1,'III. Gıyâseddin Keyhusrev','Sultan'),(1284,8,'II. Gıyâseddin Mesud','Sultan'),(1298,1,'III. Alâeddin Keykubad','Sultan'),(1302,1,'II. Gıyâseddin Mesud','Sultan')],['seljuk','mesud','sahib'],[person('Sâhib Ata Fahreddin Ali','Vezir','finance',1280,1289),person('Fahreddin Kazvînî','Vezir','finance',1289,1292),person('Sultan Veled','Âlim; Konya için arabuluculuk yaptı','envoy',1280,1312),person('Muzafferüddin Yavlak Arslan','Kastamonu uç beyi','marshal',1280,1292)],'Selçuklu')
profile('ilkhan','persian',['persian','mongol'],'Hülâgû’nun seferleriyle İran ve Irak’ta kurulan İlhanlı yönetimi, Selçuklular üzerinde belirleyici nüfuza sahiptir. Hanedan Moğol kökenlidir; Farsça bürokrasi geniş coğrafyanın idaresinde önemlidir. 1280’de Abaka Han, Memlüklerle rekabet etmektedir.',[(1256,'İlhanlı siyasî teşekkülü.'),(1258,'Bağdat’ın alınması.'),(1260,'Aynicâlût; Suriye’de Memlük–Moğol mücadelesi.'),(1265,'Abaka’nın hanlığı.')],[(1265,1,'Abaka Han','İlhan'),(1282,5,'Ahmed Teküder','İlhan'),(1284,8,'Argun Han','İlhan'),(1291,7,'Geyhatu Han','İlhan'),(1295,10,'Gāzân Han','İlhan'),(1304,7,'Olcaytu','İlhan'),(1316,12,'Ebû Said Bahadır Han','İlhan')],['ilkhan','abaka','cuveyni'],[person('Şemseddin Cüveynî','Sâhib-i dîvân','finance',1280,1285),person('Reşîdüddin Fazlullah','Vezir','finance',1298,1318)],'Hülâgû hanedanı')
profile('byzantine','greek',['greek'],'1204’te Konstantinopolis’in Latinlerce ele geçirilmesi Bizans dünyasını parçalamıştı. İznik merkezli güç, 1261’de şehri geri aldı. 1280’de VIII. Mihail batıdaki Latin baskısı, Balkanlar ve Anadolu sınırı arasında denge aramaktadır.',[(1204,'Dördüncü Haçlı Seferi ve Konstantinopolis’in kaybı.'),(1261,'Konstantinopolis geri alındı.'),(1274,'Lyon Konsili ve kiliselerin birleşmesi girişimi.')],[(1259,1,'VIII. Mihail Palaiologos','İmparator'),(1282,12,'II. Andronikos Palaiologos','İmparator'),(1328,5,'III. Andronikos Palaiologos','İmparator')],['bizans','pachy'],[person('Georgios Pachymeres','Tarihçi ve kilise görevlisi','envoy',1280,1310)],'Palaiologos')
profile('mamluk','arabic',['arabic','turkish'],'1250’de Mısır’da kurulan sultanlık, Aynicâlût sonrasında Suriye’de güçlendi. Türk kökenli askerî seçkinler ile Arapça idare bir aradadır. Kalavun 1279’da tahta çıktı; İlhanlı baskısı ve Haçlı kıyı merkezleri devletin önemli meseleleridir.',[(1250,'Mısır’da Memlük iktidarı.'),(1260,'Aynicâlût zaferi.'),(1268,'Baybars Antakya’yı aldı.'),(1279,'Kalavun sultan oldu.')],[(1279,1,'el-Mansûr Kalavun','Sultan'),(1290,11,'el-Eşref Halîl','Sultan'),(1293,12,'en-Nâsır Muhammed','Sultan'),(1294,12,'Ketboğa','Sultan'),(1296,11,'Hüsâmeddin Lâçin','Sultan'),(1299,2,'en-Nâsır Muhammed','Sultan'),(1309,4,'II. Baybars','Sultan'),(1310,3,'en-Nâsır Muhammed','Sultan')],['memluk','kalavun','halil','katip'],[person('İbn Abdüzzâhir','Dîvân-ı inşâ kâtibi ve tarihçi','envoy',1280,1293)],'Bahrî Memlükleri')
profile('cilicia','armenian',['armenian'],'Toroslar ve Çukurova’daki Ermeni siyasî örgütlenmesi zamanla Sis merkezli bir krallığa dönüştü. 1280’de Leon, İlhanlılarla ittifak ve Memlük baskısı arasında hüküm sürmektedir. Leon’un sıra numarası kaynak geleneklerine göre değişir.',[(1198,'Krallık tacının kabulü.'),(1266,'Memlük saldırısı ve ağır kayıplar.'),(1269,'Leon’un hükümdarlığının başlangıcı.')],[(1269,1,'II. Leon / III. Levon','Kral'),(1289,2,'II. Hetum','Kral')],['cilicia','kalavun'],dynasty='Hetum')
profile('trebizond','greek',['greek','georgian'],'Komnenos ailesi 1204’te Doğu Karadeniz’de ayrı bir imparatorluk kurdu. Trabzon’un ticaret yolları ve Gürcistan bağlantıları önemlidir. 1280 yılı Georgios’tan II. İoannes’e geçişin eşiğidir; ayı kesin olmayan geçişler senaryoda yaklaşık tarihlenir.',[(1204,'Trabzon İmparatorluğu kuruldu.'),(1214,'Sinop’un Selçuklulara kaybı.'),(1266,'Georgios’un hükümdarlığı.')],[(1266,1,'Georgios Megas Komnenos','İmparator'),(1280,6,'II. İoannes Megas Komnenos','İmparator'),(1284,6,'Theodora Megale Komnene','İmparatoriçe'),(1285,6,'II. İoannes Megas Komnenos','İmparator'),(1297,8,'II. Aleksios Megas Komnenos','İmparator')],['trebizond'],dynasty='Megas Komnenos')
profile('cyprus','latin',['latin','greek'],'XII. yüzyıl sonunda Lusignan hanedanının yönetimine giren Kıbrıs, Doğu Akdeniz’in Latin krallıklarından biridir. Rum nüfus ile Latin krallık kurumları bir aradadır. III. Hugues, Kudüs tacına da hak iddia ederken Akkâ’daki Anjou nüfuzuyla karşı karşıyadır.',[(1192,'Lusignan yönetiminin başlangıcı.'),(1267,'III. Hugues Kıbrıs kralı oldu.'),(1277,'Anjou hanedanının Kudüs tacı iddiası güçlendi.')],[(1267,1,'III. Hugues de Lusignan','Kral'),(1284,3,'I. Jean de Lusignan','Kral'),(1285,5,'II. Henri de Lusignan','Kral'),(1324,3,'IV. Hugues de Lusignan','Kral')],['cyprus','levant'],dynasty='Lusignan')
profile('georgia','georgian',['georgian'],'Gürcü krallığı XIII. yüzyılda Moğol baskısıyla bölünmüştür. Kutaisi merkezli batı kolu, doğudaki İlhanlı nüfuzundan farklı bir siyasî yol izler. 1280’de batı krallığının hükümdarı VI. David Narin’dir.',[(1220,'Moğol akınları Kafkasya’ya ulaştı.'),(1259,'David Narin batıda ayrı iktidar kurdu.')],[(1259,1,'VI. David Narin','Kral'),(1293,1,'I. Konstantine','Kral')],['georgia'],dynasty='Bagrationi')
profile('bulgaria','bulgarian',['bulgarian'],'Asen hanedanıyla yeniden yükselen Bulgar Çarlığı XIII. yüzyılda büyük bir Balkan gücüydü. 1277’den itibaren İvaylo hareketi, hanedan çekişmesi ve dış müdahaleler iktidarı sarstı. 1280, III. İvan Asen ile I. Georgi Terter arasındaki dönüşüm yılıdır.',[(1185,'İkinci Bulgar Çarlığı’nın doğuşu.'),(1230,'Klokotnitsa zaferi.'),(1277,'İvaylo ayaklanması.'),(1279,'III. İvan Asen’in iktidarı.')],[(1279,1,'III. İvan Asen','Çar'),(1280,6,'I. Georgi Terter','Çar'),(1292,1,'Smilets','Çar'),(1300,1,'Todor Svetoslav','Çar')],['bulgaria'],dynasty='Asen / Terter')
profile('serbia','serbian',['serbian'],'Nemanjić hanedanı Sırp topraklarında krallık otoritesini güçlendirdi. XIII. yüzyılda Bizans ve Macaristan ilişkileri siyaseti belirledi. 1280’de Stefan Dragutin hüküm sürer; kardeşi Milutin sonraki taht değişiminin merkezindedir.',[(1217,'Sırp krallık tacı.'),(1276,'Stefan Dragutin tahta çıktı.')],[(1276,1,'Stefan Dragutin','Kral'),(1282,6,'Stefan Uroš II Milutin','Kral'),(1321,1,'Stefan Uroš III Dečanski','Kral')],['serbia'],dynasty='Nemanjić')
profile('epirus','greek',['greek'],'1204 sonrasında Epir’de kurulan Doukas yönetimi Bizans dünyasının mirasına ortak oldu. Bizans, Latin devletleri ve akraba Tesalya yönetimiyle ilişkiler değişkendir. 1280’de Nikephoros I, Arta merkezli iktidarı sürdürmektedir.',[(1204,'Epir’de ayrı yönetimin doğuşu.'),(1267,'Nikephoros I döneminin başlangıcı.')],[(1267,1,'I. Nikephoros Komnenos Doukas','Despot'),(1297,1,'I. Thomas Komnenos Doukas','Despot')],['bizans','thessaly'],dynasty='Komnenos Doukas')
profile('thessaly','greek',['greek','vlach'],'Tesalya, XIII. yüzyılda Epir mirasından çıkan ayrı bir yönetimdir. Neopatras merkezli İoannes I, Konstantinopolis’e karşı Atina ve Batılı güçlerle bağlantılar kurdu. Devlet Bizans imparatorunun doğrudan idaresinde değildir.',[(1268,'İoannes I’in ayrı yönetimi.'),(1274,'Lyon birleşmesine karşı muhalefet.')],[(1268,1,'I. İoannes Doukas','Sebastokrator'),(1289,1,'Konstantinos ve Theodoros Doukas','Ortak yöneticiler'),(1303,1,'II. İoannes Doukas','Sebastokrator')],['thessaly'],dynasty='Doukas')
profile('athens','latin',['latin'],'Dördüncü Haçlı Seferi sonrasında La Roche ailesi Atina ve Thebai’de Latin yönetimi kurdu. Tesalya ile evlilik bağlantıları ve Anjou nüfuzu önemlidir. 1280’de Jean’dan Guillaume’a geçiş vardır; kesin ay bilinmediği için oyun yıl ortasını kullanır.',[(1204,'La Roche yönetiminin başlangıcı.'),(1270,'Tesalya ile hanedan bağlantılarının güçlenmesi.')],[(1263,1,'I. Jean de La Roche','Atina hâkimi'),(1280,6,'I. Guillaume de La Roche','Dük'),(1287,1,'II. Guy de La Roche','Dük')],['athens','thessaly'],dynasty='La Roche')
profile('achaea','latin',['latin'],'Mora’da 1204 sonrasında kurulan Latin prensliği, Villehardouin ailesiyle güçlendi. 1262’den sonra Bizans güney Mora’da tutunma alanları elde etti. 1278’den itibaren Ahaia’nın üst yönetimi Anjou hanedanına geçti.',[(1205,'Ahaia Prensliği’nin kuruluşu.'),(1262,'Bizans’ın Mora’da yeniden tutunması.'),(1278,'Anjou yönetiminin başlaması.')],[(1278,1,'I. Charles d’Anjou','Prens'),(1285,1,'II. Charles d’Anjou','Prens'),(1289,1,'Isabelle de Villehardouin','Prenses')],['levant','thessaly'],dynasty='Anjou / Villehardouin')
profile('cephalonia','latin',['latin'],'İyon adalarındaki Latin kontluk, XIII. yüzyılda Orsini ailesinin elindedir. Ada limanları, Ahaia ve Epir arasındaki bağlar siyasî önem taşır. 1280’de Riccardo Orsini hüküm sürer; iktidara geliş yılı kaynaklarda kesin değildir.',[(1185,'Latin kontluğunun kökeni.'),(1264,'Riccardo Orsini’nin adı belgelerde görülür.')],[(1264,1,'Riccardo Orsini','Kont'),(1303,12,'I. Giovanni Orsini','Kont')],['orsini'],dynasty='Orsini')
profile('naxos','latin',['latin'],'1204 sonrasında Ege’de oluşan Latin ada yönetimleri içinde Sanudo ailesi Nakşa merkezli bir güç kurdu. Venedik bağlantısı doğrudan tek tip Venedik idaresi anlamına gelmez. Marco II, 1280’de adalar üzerindeki dükalık otoritesini sürdürür.',[(1207,'Nakşa merkezli Latin teşekkülünün başlangıcı.'),(1262,'Marco II Sanudo dönemi başladı.')],[(1262,1,'II. Marco Sanudo','Dük'),(1303,1,'Guglielmo Sanudo','Dük')],['naxos'],dynasty='Sanudo')
profile('angevin','latin',['latin'],'Charles d’Anjou, XIII. yüzyılın ikinci yarısında Adriyatik’in doğu kıyısında üsler elde etti. Dıraç ve Korfu çevresi, Bizans’a karşı tasarlanan seferlerin dayanaklarıdır. Oyunda bu kıyı mevzileri tek siyasî alanda sadeleştirilmiştir.',[(1267,'Korfu çevresinde Anjou nüfuzu.'),(1272,'Dıraç merkezli Anjou krallık iddiası.')],[(1272,1,'I. Charles d’Anjou','Kral'),(1285,1,'II. Charles d’Anjou','Kral')],['bizans','venice'],dynasty='Anjou')
profile('venice','latin',['latin'],'Venedik, 1204 sonrasında Doğu Akdeniz’de ada ve liman ağları elde etti. Girit, bu denizaşırı düzenin önemli merkezidir. 1280’de Jacopo Contarini’nin yerini Giovanni Dandolo alır; rekabetin merkezinde Bizans, Cenova ve ticaret yolları vardır.',[(1204,'Latin düzeninde Venedik’in geniş kazanımları.'),(1211,'Girit’te Venedik yönetiminin yerleşmesi.'),(1275,'Jacopo Contarini doç oldu.')],[(1275,1,'Jacopo Contarini','Doç'),(1280,3,'Giovanni Dandolo','Doç'),(1289,11,'Pietro Gradenigo','Doç')],['girit','venice'],dynasty='Venedik Cumhuriyeti')
profile('crusader','latin',['latin'],'Trablus, Haçlı seferleri sırasında kurulmuş kıyı kontluğunun merkezidir. Antakya’nın 1268’de kaybından sonra Bohemond hanedanının bölgedeki gücü daralmıştır. 1280’de VII. Bohemond Trablus’u yönetir; Memlük baskısı sürmektedir.',[(1109,'Trablus Kontluğu kuruldu.'),(1268,'Antakya’nın kaybı.'),(1275,'VII. Bohemond’un iktidarı.')],[(1275,1,'VII. Bohemond','Kont'),(1287,10,'Lucia','Kontes')],['tripoli','kalavun'],dynasty='Poitiers-Antakya')
profile('jerusalem','latin',['latin'],'Kudüs şehri kaybedildikten sonra krallığın önemli merkezi Akkâ oldu. XIII. yüzyıl sonunda krallık unvanı Lusignan ve Anjou taraflarınca paylaşılmaz bir hak olarak savunuluyordu. 1280’de Akkâ’da Charles d’Anjou’nun temsilcileri etkilidir; oyun bu karmaşıklığı tek kıyı yönetiminde toplar.',[(1187,'Kudüs’ün kaybı.'),(1191,'Akkâ Latin kuvvetlerce alındı.'),(1277,'Anjou hanedanının tacı devralma iddiası ve Akkâ’da etkisi.')],[(1277,1,'I. Charles d’Anjou','Taht iddiacısı; Akkâ temsilcileri'),(1285,1,'II. Charles d’Anjou','Taht iddiacısı'),(1286,6,'II. Henri de Lusignan','Kral')],['levant','cyprus'],dynasty='Anjou / Lusignan')

future=[]
for id,name,short,color,claims,bey,start,source in [
 ('ottoman','Osmanlı Beyliği','Osmanlı','#719b82',['pr-eskisehir'],'Osman Bey',1299,'osman'),
 ('karaman','Karamanoğulları','Karaman','#b8876d',['pr-alaiye','pr-konya'],'Güneri Bey',1288,'karaman'),
 ('germiyan','Germiyanoğulları','Germiyan','#b4ae75',['pr-karahisar'],'I. Yâkub Bey',1300,'germiyan'),
 ('mentese','Menteşeoğulları','Menteşe','#c4a070',['pr-mugla'],'Menteşe Bey',1282,'mentese'),
 ('candar','Candaroğulları','Candar','#8babb6',['pr-kastamonu','pr-sinop'],'Şemseddin Yaman Candar',1292,'candar'),
 ('hamid','Hamîdoğulları','Hamid','#aea1bb',['pr-antalya'],'Feleküddin Dündar Bey',1297,'hamid')]:
 future.append({'id':id,'name':name,'short':short,'color':color,'future':True,'kind':'Türkmen beyliği','claims':claims,'center':claims[0],'capital':{'city':None,'name':'Uç yönetimi','visible':False},'province_count':0,'ports':0,'forts':0})
 profile(id,'turkish',['turkish'],'Bu hanedan 1280 başlangıcında bağımsız bir ülke olarak çizilmez. Uç beyliği ve merkezle ilişkisi, sonraki olaylar ve oyuncu tercihleriyle şekillenir. Az sayıdaki şehir bölgesi nedeniyle ayrılma alanları temsilîdir; bütün bir tarihî beylik sınırının kesin karşılığı değildir.',[(1280,'Bağımsız ülke olarak başlangıç haritasında yer almaz.')],[(1280,1,bey,'Uç beyi')],[source],dynasty=name)
profiles['karaman']['rulers']+=[{'from':month(1300),'name':'Mahmud Bey','title':'Bey'}]
profiles['mentese']['rulers']+=[{'from':month(1294),'name':'Mesud Bey','title':'Bey'}]
profiles['candar']['rulers']+=[{'from':month(1309),'name':'I. Süleyman Bey','title':'Bey'}]
profiles['ottoman']['rulers']+=[{'from':month(1326),'name':'Orhan Bey','title':'Bey'}]

events=[]
for nation,p in profiles.items():
 if nation in [f['id'] for f in future]:continue
 for r in p['rulers']:
  if r['from']<=0:continue
  events.append({'id':nation+'-taht-'+str(r['from']),'turn':r['from'],'kind':'succession','nation':nation,'involved':[nation],
   'title':p['dynasty']+' sarayında taht değişimi','history':r['name']+' tarihî kronolojide bu dönemde '+r['title'].lower()+' olarak yer alır. Ayı bilinmeyen geçişler oyunda yaklaşık tarihlenir.',
   'ruler':r,'sources':p['sources'][:2]})
def event(id,y,m,kind,title,history,involved,source,**extra):events.append({'id':id,'turn':month(y,m),'kind':kind,'title':title,'history':history,'involved':involved,'sources':[S[k] for k in source],**extra})
event('homs-1281',1281,10,'campaign','Hums eşiği: Memlük–İlhanlı mücadelesi','Tarihî II. Hums Muharebesi 29 Ekim 1281’de Kalavun’un kuvvetleriyle İlhanlı ordusunu karşılaştırdı. Bu seferde savaşın çıkması ve sonucu mevcut kuvvetlere ve kararlara bağlıdır.',['mamluk','ilkhan'],['kalavun','abaka'],attacker='ilkhan',defender='mamluk',target='pr-sam')
event('mentese-frontier',1282,6,'beylik','Menteşe uçlarında yeni bir güç','Menteşe Bey 1282 çevresinde Batı Anadolu’da kaynaklara girer; erken kronolojisi kesin değildir. Merkez himayesi ile yerel güçlenme aynı anda bulunabilir. Muğla oyun bölgesi temsilî uç alanıdır.',['seljuk'],['mentese'],beylik='mentese')
event('loyalty-1288',1288,1,'loyalty','Uç beylerinin bağlılık yemini','1288’de Karaman ve Germiyan çevresindeki beyler Sultan Mesud’a bağlılık bildirdiler. Oyundaki karar, mevcut ülkenin gücüne göre merkezle uçların bağını yeniler veya yerel özerkliği genişletir.',['seljuk'],['mesud','karaman'])
event('tripoli-1289',1289,4,'campaign','Trablus kapılarında','Kalavun tarihî kronolojide 1289’da Trablus’u aldı. Oyundaki şehir, askerî olarak ele geçirilmedikçe kendiliğinden el değiştirmez. Sefer veya uzlaşma farklı bir gelecek açabilir.',['mamluk','crusader'],['tripoli','kalavun'],attacker='mamluk',defender='crusader',target='pr-trablus')
event('acre-1291',1291,5,'campaign','Akkâ için son büyük sefer','el-Eşref Halîl döneminde Akkâ 1291’de Memlüklerce alındı. Burada tarihî sefer bir karar eşiğidir; canlı oyundaki askerî sonuç önceden yazılmış değildir.',['mamluk','jerusalem'],['halil','memluk'],attacker='mamluk',defender='jerusalem',target='pr-akka')
event('candar-frontier',1292,6,'beylik','Kuzey uçlarında Candar','Candaroğulları’nın ortaya çıkışı 1292 çevresine yerleştirilir. Yaman Candar’ın ilk alanı Eflani idi; Kastamonu oyun bölgesi daha geniş, temsilî bir yerel yönetim alanıdır.',['seljuk'],['candar','beylik'],beylik='candar')
event('hamid-frontier',1297,6,'beylik','Hamid-ili için idare meselesi','Hamîdoğulları’nın teşekkülü XIII. yüzyıl sonundaki merkezî çözülmeyle ilişkilidir. Isparta ve Burdur’u da içeren Antalya oyun bölgesi, bu olay için sadeleştirilmiş bir temsil alanıdır.',['seljuk'],['hamid'],beylik='hamid')
event('osman-frontier',1299,6,'beylik','Osman Bey: uçta bağlılık mı, yeni yol mu?','1299 geleneksel ve tartışmalı bir kuruluş tarihidir; Osman’ın yükselişinde 1302 Bafeus zaferi de önemlidir. Selçuklu düzeni bu seferde ayaktaysa Osman Bey’in merkezle bağlılığı korunabilir. Söğüt, Eskişehir oyun bölgesine dahildir.',['seljuk'],['osman','beylik'],beylik='ottoman')
event('germiyan-frontier',1300,6,'beylik','Germiyan’ın yeni tercihi','I. Yâkub Bey 1299 tarihli kitabede Selçuklu hâkimiyetini tanır; 1300 çevresinde bağımsızlaşma görülür. Bu eşik, oyuncunun merkezî idaresine göre başka sonuç verebilir. Karahisar oyun alanı temsilîdir.',['seljuk'],['germiyan'],beylik='germiyan')
event('bapheus-1302',1302,7,'frontier','Bafeus eşiği: Osman’ın nüfuzu','27 Temmuz 1302 Bafeus Muharebesi, Osman’ın tarihî yükselişindeki belirgin eşiklerden biridir. Bu seferde uç beyinin bağlılığı ve Bizans’la savaşın sonucu önceki kararlara bağlıdır.',['seljuk','byzantine','ottoman'],['osman','pachy'])
event('seljuk-1308',1308,6,'collapse','Selçuklu mirasının geleceği','II. Mesud’un 1308’de ölümü genellikle Anadolu Selçuklu hanedan iktidarının sonu kabul edilir. Ancak bu seferde güçlü bir merkez korunmuş olabilir: beyler bağlı kalabilir veya ayrı idarelere dönüşebilir. Dağıtım, 69 şehir bölgesine göre temsilîdir.',['seljuk'],['mesud','beylik'])
events.sort(key=lambda e:(e['turn'],e['id']))

cultures={k:{'name':name,'color':color} for k,name,color in [
 ('turkish','Türk / Türkmen','#b49b55'),('greek','Rum / Yunanca konuşan','#739daa'),('kurdish','Kürt','#9e8165'),
 ('armenian','Ermeni','#a9838f'),('arabic','Arap','#b8a079'),('persian','Fars','#9b93b5'),('mongol','Moğol','#7e9a83'),
 ('georgian','Gürcü','#7c9d83'),('bulgarian','Bulgar','#b6a97a'),('serbian','Sırp','#8297ae'),
 ('albanian','Arnavut','#a77c70'),('vlach','Ulah','#8b9c75'),('latin','Latin / Frank-İtalyan','#b88972'),
 ('coptic','Kıpti','#c29b6f'),('nubian','Nûbeli','#9d8a70'),('syriac','Süryani','#ad9cbb'),('jewish','Yahudi toplulukları','#9b997b')]}
weights={}
data=json.loads((ROOT/'dist/map-data.json').read_text())
defaults={
 'seljuk':{'turkish':55,'greek':25,'armenian':15,'kurdish':5},'byzantine':{'greek':80,'latin':5,'turkish':10,'jewish':5},
 'ilkhan':{'kurdish':40,'arabic':30,'armenian':15,'turkish':15},'cilicia':{'armenian':65,'greek':15,'arabic':10,'turkish':10},
 'mamluk':{'arabic':80,'turkish':10,'syriac':5,'jewish':5},'trebizond':{'greek':70,'georgian':15,'armenian':10,'turkish':5},
 'cyprus':{'greek':75,'latin':15,'armenian':5,'arabic':5},'georgia':{'georgian':80,'armenian':10,'greek':5,'turkish':5},
 'bulgaria':{'bulgarian':65,'greek':15,'vlach':10,'turkish':5,'jewish':5},'serbia':{'serbian':70,'vlach':15,'albanian':10,'greek':5},
 'epirus':{'greek':65,'albanian':20,'vlach':10,'latin':5},'thessaly':{'greek':65,'vlach':25,'albanian':5,'latin':5},
 'athens':{'greek':80,'latin':15,'jewish':5},'achaea':{'greek':80,'latin':15,'vlach':5},'cephalonia':{'greek':85,'latin':15},
 'naxos':{'greek':85,'latin':15},'angevin':{'albanian':60,'greek':25,'latin':15},'venice':{'greek':85,'latin':10,'jewish':5},
 'crusader':{'arabic':55,'syriac':15,'latin':20,'greek':10},'jerusalem':{'arabic':50,'latin':25,'syriac':10,'jewish':10,'greek':5}}
for p in data['provinces']:weights[p['id']]=dict(defaults[p['owner']])
for id,dist in {
 'pr-mardin':{'kurdish':50,'arabic':25,'syriac':10,'armenian':10,'turkish':5},
 'pr-musul':{'kurdish':45,'arabic':40,'syriac':10,'turkish':5},'pr-van':{'armenian':45,'kurdish':35,'turkish':10,'georgian':10},
 'pr-tebriz':{'persian':55,'turkish':30,'armenian':10,'mongol':5},'pr-amid':{'kurdish':55,'armenian':20,'arabic':15,'turkish':10},
 'pr-harput':{'kurdish':45,'armenian':35,'turkish':20},'pr-malatya':{'kurdish':35,'armenian':30,'turkish':30,'greek':5},
 'pr-erzurum':{'armenian':40,'turkish':35,'kurdish':20,'greek':5},'pr-erzincan':{'turkish':40,'armenian':35,'kurdish':20,'greek':5},
 'pr-kayseri':{'turkish':45,'armenian':30,'greek':20,'kurdish':5},'pr-konya':{'turkish':60,'greek':25,'armenian':10,'jewish':5},
 'pr-mugla':{'greek':50,'turkish':45,'latin':5},'pr-sinop':{'greek':55,'turkish':35,'armenian':10},
 'pr-samsun':{'greek':55,'turkish':35,'armenian':10},'pr-izmir':{'greek':65,'turkish':20,'latin':10,'armenian':5},
 'pr-uskup':{'serbian':30,'bulgarian':30,'greek':20,'albanian':15,'vlach':5},'pr-ohri':{'bulgarian':40,'greek':30,'albanian':20,'vlach':10},
 'pr-kahire':{'arabic':65,'coptic':25,'turkish':5,'jewish':5},'pr-kus':{'arabic':50,'coptic':45,'nubian':5},
 'pr-asvan':{'nubian':45,'arabic':35,'coptic':20},'pr-iskenderiye':{'arabic':65,'coptic':20,'greek':10,'jewish':5},
 'pr-dimyat':{'arabic':70,'coptic':25,'jewish':5},'pr-antakya':{'arabic':45,'greek':25,'armenian':20,'syriac':10},
 'pr-halep':{'arabic':55,'kurdish':20,'armenian':10,'syriac':10,'turkish':5}}.items():weights[id]=dist
for id,w in weights.items():assert sum(w.values())==100 and all(k in cultures for k in w),id
payload={'version':'0.2.0','coverage':'1280–1335; geçiş aylarının bir bölümü oyun için yaklaşık yerleştirilmiştir.',
 'cultureNote':'Bu yüzdeler tarihî nüfus sayımı veya akademik demografi tahmini DEĞİLDİR. 1280 için şehir bazında karşılaştırılabilir sayımlar bulunmadığından yalnızca oynanış için tanımlanmış, değiştirilebilir senaryo ağırlıklarıdır. Kültür adları sadeleştirilmiş topluluk başlıklarıdır; modern uluslarla birebir eşitlenmez.',
 'cultureShortNote':'Temsilî senaryo oranları · tarihî nüfus sayımı değildir', 'cultures':cultures,'demographics':weights,'profiles':profiles,'futureNations':future,'events':events,'sources':S}
(ROOT/'source-data/campaign-1280.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
print(json.dumps({'profiles':len(profiles),'historicalEvents':len(events),'cultureRegions':len(weights),'futureBeyliks':len(future)}))
