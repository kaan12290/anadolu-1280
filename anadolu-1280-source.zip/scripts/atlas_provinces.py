"""Coarse named city regions, with removed small locations absorbed by neighbours."""
import math,re,unicodedata
from shapely.geometry import MultiPoint
from shapely.ops import voronoi_diagram
from atlas_geography import *
cfg={'capitals':scenario['capitals'],'notes':scenario['notes']}
lakes=[]
for f in json.loads((DATA/'ne_50m_lakes.geojson').read_text())['features']:
 if f['properties'].get('featurecla')!='Reservoir':
  g=shape(f['geometry']).intersection(source_frame)
  if not g.is_empty:lakes.append(g)
natural_water=unary_union(lakes)
playable_land=territory_land.difference(natural_water)
mainland=max(list(land.geoms) if land.geom_type=='MultiPolygon' else [land],key=lambda g:g.area)
province_countries={key:g.difference(natural_water) for key,g in owned.items()}
def slug(s):return re.sub('[^a-z0-9]+','-',unicodedata.normalize('NFKD',s.replace('ı','i')).encode('ascii','ignore').decode().lower()).strip('-')
locations=[]
for q in cities:
 p={**q,'id':'pr-'+slug(q['name']),'major':True,'dx':15,'dy':19,'anchor':'start','capital':cfg['capitals'][q['owner']]['city']==q['name'],'absorbed':[]}
 distance=owned[p['owner']].distance(Point(p['lon'],p['lat']))
 if distance>.08:raise ValueError('City outside expected owner: '+p['name']+' '+p['owner']+' '+str(distance))
 locations.append(p)
assert len({p['id'] for p in locations})==len(locations)
COS=math.cos(math.radians(34))
def distance(a,b):return ((a['lon']-b['lon'])*COS)**2+(a['lat']-b['lat'])**2
kept={p['name'] for p in locations};aliases={}
for old in scenario['previous_locations']:
 if old['name'] in kept:continue
 candidates=[p for p in locations if p['owner']==old['owner']]
 if candidates:
  p=min(candidates,key=lambda q:distance(old,q));p['absorbed'].append(old['name']);aliases[old['id']]=p['id']
def warp(u,v):return u+.035*math.sin(v*5+u*.7)+.018*math.sin(v*11-u*2),v+.03*math.sin(u*5+v*1.2)
def unwarp(u,v):
 x,y=u,v
 for _ in range(10):
  a,b=warp(x,y);x+=u-a;y+=v-b
 return x/COS,y
def reverse_cell(cell):
 ring=list(cell.exterior.coords);dense=[]
 for a,b in zip(ring,ring[1:]):
  n=max(1,math.ceil(math.hypot(a[0]-b[0],a[1]-b[1])/.07))
  for j in range(n):dense.append(unwarp(a[0]+(b[0]-a[0])*j/n,a[1]+(b[1]-a[1])*j/n))
 return Polygon(dense).buffer(0)
province_shapes={};provinces=[]
for country in regions:
 key=country['id'];group=[p for p in locations if p['owner']==key];territory=province_countries[key]
 if not group:raise ValueError('Country has no city '+key)
 if len(group)==1:cells=[(group[0],territory)]
 else:
  pts=[warp(p['lon']*COS,p['lat']) for p in group]
  diagram=voronoi_diagram(MultiPoint(pts),envelope=box(WEST*COS-8,SOUTH-8,EAST*COS+8,NORTH+8),edges=False)
  cells=[]
  for cell in diagram.geoms:
   pt=cell.representative_point();idx=min(range(len(pts)),key=lambda i:(pts[i][0]-pt.x)**2+(pts[i][1]-pt.y)**2)
   cells.append((group[idx],reverse_cell(cell).intersection(territory).buffer(0)))
 for loc,g in cells:
  if g.is_empty:raise ValueError('Empty city '+loc['name'])
  assert loc['id'] not in province_shapes,'Duplicate cell'
  province_shapes[loc['id']]=g
  coastal=g.boundary.intersection(land.boundary.buffer(.0001)).length>.025
  terrain='Kıyı' if coastal else 'Nil vadisi' if loc['name'] in ['Kahire','Kus','Asvan'] else 'Çöl / vadi' if loc['lat']<32 else 'Dağlık' if loc['lon']>37.8 or loc['owner'] in ['epirus','thessaly','serbia'] else 'Plato'
  p={**loc,'coastal':coastal,'terrain':terrain,'neighbours':[],'island':not g.intersects(mainland),'control':'Şeriflik · Memlük üst hâkimiyeti' if loc['name'] in ['Mekke','Medine'] else 'Ülke alanı'}
  p['map_x'],p['map_y']=xy((p['lon'],p['lat']));provinces.append(p)
union=unary_union(list(province_shapes.values()))
assert union.symmetric_difference(playable_land).area<1e-6,'Province coverage gap'
for i,a in enumerate(provinces):
 ga=province_shapes[a['id']];assert ga.is_valid,a['name']
 for b in provinces[i+1:]:
  gb=province_shapes[b['id']];assert ga.intersection(gb).area<1e-8,'Overlapping regions'
  if ga.boundary.intersection(gb.boundary.buffer(.000003)).length>.009:a['neighbours'].append(b['id']);b['neighbours'].append(a['id'])
assert len(provinces)==len(locations)==69
province_boundaries=unary_union([g.boundary for g in province_shapes.values()]).difference(land.boundary.buffer(.00005))
province_by_id={p['id']:p for p in provinces}
for p in provinces:p['neighbours'].sort(key=lambda i:province_by_id[i]['name'])
