#!/usr/bin/env python3
"""Compile the expanded Balkan–Anatolia–Mamluk strategy atlas."""
from atlas_provinces import *
import atlas_assets as art
import hashlib
from shapely.geometry import mapping

def tint(color,n):
 v=[int(color[i:i+2],16) for i in [1,3,5]]
 return '#'+''.join(f'{round(x+(255-x)*n) if n>=0 else round(x*(1+n)):02x}' for x in v)

lp=gpath(land)
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" id="historical-map" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="map-title map-desc"><title id="map-title">Anadolu 1280 — Balkanlar, Doğu Akdeniz ve Mısır</title><desc id="map-desc">69 adlandırılmış şehir bölgesi. Bizans, Bulgar ve Memlük alanları geniş çerçevede; Hicaz üst hâkimiyeti taralıdır. Sınırlar yaklaşık, bölgeler oyun tasarımıdır.</desc>']
svg.append(f'''<defs><path id="land-geometry" d="{lp}" fill-rule="evenodd"/><clipPath id="land-clip"><use href="#land-geometry"/></clipPath><clipPath id="frame-clip"><rect y="{TOP}" width="{W}" height="{PH}"/></clipPath><linearGradient id="paper"><stop stop-color="#cbb889"/><stop offset=".2" stop-color="#ecdfbc"/><stop offset=".8" stop-color="#e6d3a8"/><stop offset="1" stop-color="#bea273"/></linearGradient><linearGradient id="sea" x2=".8" y2="1"><stop stop-color="#748e8d"/><stop offset=".5" stop-color="#819d98"/><stop offset="1" stop-color="#607d83"/></linearGradient><radialGradient id="age-edge"><stop offset=".7" stop-color="#554d32" stop-opacity="0"/><stop offset="1" stop-color="#57432a" stop-opacity=".25"/></radialGradient><pattern id="sea-grid" width="90" height="90" patternUnits="userSpaceOnUse"><path d="M0 0H90V90" fill="none" stroke="#dedbb7" stroke-width=".5" opacity=".11"/></pattern><pattern id="paper-grain" width="23" height="27" patternUnits="userSpaceOnUse"><path d="M3 4h2m8 16 1 1m6-12v2" stroke="#73583a" stroke-width=".6" opacity=".1"/></pattern><pattern id="subject-lines" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><path d="M0 0V14" stroke="#8a6546" stroke-width="3" opacity=".32"/></pattern><g id="pine"><path d="M0 8V-9" stroke="#545f3f" stroke-width=".65"/><path d="M0-11-5-2h3l-5 7H7L2-2h3Z" fill="#657953" stroke="#4e6549" stroke-width=".35"/></g></defs>''')
svg += [art.defs(),'<style>'+(ROOT/'src/map-style.css').read_text()+'</style>',f'<rect width="{W}" height="{H}" fill="url(#paper)"/><g clip-path="url(#frame-clip)"><rect y="{TOP}" width="{W}" height="{PH}" fill="url(#sea)"/><rect y="{TOP}" width="{W}" height="{PH}" fill="url(#sea-grid)"/>']
for width,opacity in [(12,.13),(7,.2),(3,.45)]:svg.append(f'<path d="{lp}" fill="#bcb9a2" stroke="#c4cfb3" stroke-width="{width}" stroke-opacity="{opacity}"/>')
for r in regions:svg.append(f'<path class="country-fill" data-country="{r["id"]}" fill="{r["color"]}" d="{gpath(owned[r["id"]])}" fill-rule="evenodd"/>')
for p in provinces:
 n=int(hashlib.sha256(p['id'].encode()).hexdigest()[:6],16);c=tint(byid[p['owner']]['color'],(n%17-8)/85)
 svg.append(f'<path class="province {"is-selected" if p["name"]=="Konya" else ""}" data-province="{p["id"]}" data-owner="{p["owner"]}" role="button" tabindex="0" aria-label="{esc(p["name"])} bölgesi" fill="{c}" d="{gpath(province_shapes[p["id"]])}"><title>{esc(p["name"])} — {esc(byid[p["owner"]]["name"])}</title></path>')
for s,g in subject_shapes:svg.append(f'<path class="subject-area" d="{gpath(g)}" fill="url(#subject-lines)" stroke="#8f6b4f" stroke-width="1.5" stroke-dasharray="7 6"/>')
# Modest original terrain marks; geographical coastline remains sourced.
chains=[[(20.1,40.4),(21.5,39.8),(22.5,38.8)],[(29.4,36.8),(31.4,37.3),(33.2,37.15),(35.7,38),(36.5,38.4)],[(31.5,41.2),(34.5,40.9),(37.4,40.55),(40.2,40.6),(41.4,40.85)],[(38.1,39.4),(40.7,39.3),(43.2,39.8)],[(37,27),(38.5,25),(39.7,22.5)]]
random.seed(1280);svg.append('<g class="relief" clip-path="url(#land-clip)">')
for chain in chains:
 for a,b in zip(chain,chain[1:]):
  for t in [.12,.4,.72]:
   x,y=xy((a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t));h=random.uniform(12,21)
   svg.append(f'<path d="M{x-h:.1f} {y+7:.1f} {x:.1f} {y-h:.1f} {x+h:.1f} {y+7:.1f}Z" fill="#a9a684" stroke="#7d8666" stroke-width=".5"/><path d="M{x:.1f} {y-h:.1f} {x+3:.1f} {y+5:.1f} {x+h:.1f} {y+7:.1f}Z" fill="#747c58" opacity=".45"/>')
svg.append('</g><g class="forests" clip-path="url(#land-clip)">')
for _ in range(300):
 lon=random.uniform(20,41.5);lat=random.uniform(38.8,43)
 if any((lon-p['lon'])**2+(lat-p['lat'])**2<.07 for p in provinces):continue
 if land.covers(Point(lon,lat)):
  x,y=xy((lon,lat));svg.append(f'<use href="#pine" transform="translate({x:.1f} {y:.1f}) scale(.8)"/>')
svg.append('</g>')
svg.append(f'<path class="water" fill-rule="evenodd" d="{gpath(natural_water)}"/>')
for f in json.loads((DATA/'ne_50m_rivers_lake_centerlines.geojson').read_text())['features']:
 if any(n in str(f['properties'].get('name','')).lower() for n in ['euphr','tigris','sakarya','kizil','kızıl','yesil','yeşil','nile','danube','maritsa']):
  g=shape(f['geometry']).intersection(source_frame)
  if not g.is_empty:svg.append(f'<path class="river" d="{gpath(g)}"/>')
svg.append(f'<path class="province-line" d="{gpath(province_boundaries)}"/><path d="{gpath(frontiers)}" fill="none" stroke="#e9dbad" stroke-opacity=".75" stroke-width="4.7" pointer-events="none"/><path class="country-border" d="{gpath(frontiers)}"/><path d="{lp}" fill="none" stroke="#5a6c59" stroke-width="1.1" pointer-events="none"/><rect y="{TOP}" width="{W}" height="{PH}" fill="url(#paper-grain)" pointer-events="none"/>')
reserved=[]
def label(text,lon,lat,cls='country-label',extra=''):
 x,y=xy((lon,lat));svg.append(f'<text class="{cls}" x="{x:.2f}" y="{y:.2f}" {extra}>{esc(text)}</text>')
 if cls.startswith('country-label'):
  m=re.search(r'font-size:(\d+)',extra);size=int(m.group(1)) if m else 30;ww=len(text)*(size*.62+2)
  reserved.append(box(x-ww/2-5,y-size-5,x+ww/2+5,y+6))
for text,x,y,extra in [('KARADENİZ',35,44.5,''),('AKDENİZ',26.5,33,''),('EGE',25.3,38.5,'style="font-size:23px;letter-spacing:5px"'),('KIZILDENİZ',36.3,23.6,'style="font-size:24px;letter-spacing:4px"')]:label(text,x,y,'sea-label',extra)
svg.append('<g class="country-labels">')
for args in [('TÜRKİYE SELÇUKLULARI',34.8,39.15,'country-label','style="font-size:28px;letter-spacing:2px"'),('BİZANS',25.2,40.7,'country-label',''),('İMPARATORLUĞU',25.2,40.38,'country-sub','style="font-size:15px"'),('BİZANS',28.0,39.2,'country-label','style="font-size:22px"'),('BULGAR ÇARLIĞI',25.5,43.65,'country-label','style="font-size:27px;letter-spacing:2px"'),('MEMLÜK',29,28.6,'country-label','style="font-size:39px"'),('SULTANLIĞI',29,28.05,'country-label','style="font-size:31px"'),('İLHANLILAR',44.2,35.3,'country-label',''),('TRABZON',39.5,41.85,'country-label small-country','style="font-size:20px"'),('KİLİKYA',35.1,36.1,'country-label small-country','style="font-size:20px"'),('KIBRIS',33.4,34.45,'country-label small-country','style="font-size:20px"'),('HİCAZ',39.6,26.2,'country-label small-country','style="font-size:24px"'),('Memlük’e bağlı yerel yönetimler',39.6,25.85,'country-sub','style="font-size:14px"'),('SIRBİSTAN',20.4,44.15,'country-label small-country','style="font-size:21px"'),('BATI GÜRCİSTAN',43,43.35,'country-label small-country','style="font-size:19px"')]:label(*args)
svg.append('</g>')
for text,x,y in [('EFLAK',25,45.6),('LİBYA',20.8,28.5),('NÛBE',30.3,21.0),('ARAP ÇÖLÜ',44.0,28),('ALTIN ORDA',36.5,46)]:label(text,x,y,'country-sub','style="font-size:20px;letter-spacing:4px;opacity:.65"')
# Every retained region has a visible city name. Offset crowded names with leaders.
placed=list(reserved);positions={}
for p in sorted(provinces,key=lambda p:not p['capital']):
 x,y=p['map_x'],p['map_y'];size=19 if p['capital'] else 17;width=len(p['name'])*size*.58
 candidates=[(18,24,'start'),(-18,24,'end'),(18,-22,'start'),(-18,-22,'end'),(0,49,'middle'),(0,-45,'middle'),(45,46,'start'),(-45,46,'end'),(65,0,'start'),(-65,0,'end')]
 for dx,dy,anchor in candidates:
  left=x+dx-(width if anchor=='end' else width/2 if anchor=='middle' else 0);r=box(left-5,y+dy-size-5,left+width+5,y+dy+5)
  if not any(r.intersects(q) for q in placed):break
 placed.append(r);positions[p['id']]=(dx,dy,anchor)
svg.append('<g class="cities-layer">')
for p in provinces:
 x,y=p['map_x'],p['map_y'];size=34 if p['capital'] else 27;dx,dy,anchor=positions[p['id']]
 svg.append(f'<g class="city-node {"capital-node" if p["capital"] else ""}" data-province="{p["id"]}" role="button" tabindex="0" aria-label="{esc(p["name"])} merkezi" transform="translate({x:.2f} {y:.2f})"><circle r="20" fill="transparent" pointer-events="all"/>')
 if abs(dx)>30 or abs(dy)>35:svg.append(f'<path class="city-leader" d="M0 0 {dx} {dy-5}"/>')
 icon='site-capital' if p['capital'] else 'site-city';svg.append(f'<use class="city-sprite" href="#{icon}" x="{-size/2}" y="{-size*.73}" width="{size}" height="{size}"/>')
 if p['capital']:svg.append(f'<path d="M17-43V-7" stroke="#735b34" stroke-width="1.4"/><use href="#banner-{p["owner"]}" x="17" y="-43" width="24" height="18"/><use class="crown-mark" href="#site-crown" x="-8" y="-37" width="17" height="13"/>')
 if p['port']:svg.append('<use class="port-mark" href="#site-port" x="9" y="1" width="20" height="24"/>')
 if p['fort']:svg.append('<use class="fort-mark" href="#site-fort" x="-29" y="-2" width="20" height="24"/>')
 svg.append(f'<text class="city-label" x="{dx}" y="{dy}" text-anchor="{anchor}">{esc(p["name"])}</text></g>')
svg.append('</g>')
label('Van Gölü',42.8,38.78,'map-symbol-label','style="font-size:13px"');label('Nil',31.95,27.4,'map-symbol-label','style="font-size:17px"')
svg.append(f'<rect y="{TOP}" width="{W}" height="{PH}" fill="url(#age-edge)" pointer-events="none"/></g>')
svg.append(f'<g class="export-only"><rect x="16" y="16" width="{W-32}" height="{H-32}" fill="none" stroke="#856a44" stroke-width="1.3"/><text x="46" y="59" fill="#633e2b" font-size="38" letter-spacing="5">ANADOLU 1280</text><text x="{W-46}" y="56" text-anchor="end" fill="#806747" font-size="18" letter-spacing="2">BALKANLAR · DOĞU AKDENİZ · MISIR VE HİCAZ</text><path d="M20 {TOP-1}H{W-20}M20 {TOP+PH+1}H{W-20}" stroke="#94794f"/><g fill="#745d40" font-size="15"><use href="#site-city" x="46" y="{H-72}" width="31" height="30"/><text x="91" y="{H-49}">Şehir bölgesi</text><use href="#site-port" x="270" y="{H-73}" width="25" height="30"/><text x="308" y="{H-49}">Liman</text><use href="#site-fort" x="418" y="{H-73}" width="25" height="30"/><text x="456" y="{H-49}">Kale / sur</text><use href="#site-crown" x="604" y="{H-70}" width="30" height="24"/><text x="649" y="{H-49}">Başkent / merkez</text><rect x="891" y="{H-69}" width="32" height="23" fill="url(#subject-lines)"/><text x="940" y="{H-49}">Memlük’e bağlı Hicaz</text><text x="{W-46}" y="{H-49}" text-anchor="end">69 şehir bölgesi · 20 siyasi alan</text></g><text x="47" y="{H-24}" fill="#8b7450" font-size="12">Ülke sınırları yaklaşık; şehir bölgeleri oynanış taslağıdır. Nötr komşular ayrıntılandırılmamıştır. Sancaklar temsilî oyun çizimleridir.</text></g></svg>')
svgtext=''.join(svg);(OUT/'map.svg').write_text(svgtext)
public=[]
for r in regions:
 p={k:v for k,v in r.items() if k!='parts'};p['capital']=cfg['capitals'][r['id']];p['emblem_note']=art.HERALDRY[r['id']][2];p['map_bbox']=mapbounds(owned[r['id']]);p['province_count']=sum(q['owner']==r['id'] for q in provinces);p['ports']=sum(q['owner']==r['id'] and q['port'] for q in provinces);p['forts']=sum(q['owner']==r['id'] and bool(q['fort']) for q in provinces);public.append(p)
views=[{'id':'all','name':'Genel','bbox':[0,TOP,W,TOP+PH]},{'id':'balkans','name':'Balkanlar','bbox':mapbounds(box(18.5,35.6,30.3,46))},{'id':'anatolia','name':'Anadolu','bbox':mapbounds(box(25,34.3,46.8,43.4))},{'id':'mamluk','name':'Mısır–Şam','bbox':mapbounds(owned['mamluk'])}]
payload={'year':1280,'regions':public,'provinces':provinces,'sources':source_all,'notes':cfg['notes'],'map':{'width':W,'height':H,'top':TOP,'plot_height':PH,'views':views},'aliases':aliases,'stats':{'provinces':len(provinces),'ports':sum(p['port'] for p in provinces),'forts':sum(bool(p['fort']) for p in provinces),'land_edges':sum(len(p['neighbours']) for p in provinces)//2,'countries':len(regions),'merged_old_locations':len(aliases)},'method':'1280 çevresindeki siyasi dağılım kaynak karşılaştırmasıyla yaklaşık çizildi. Yunanistan’ın tamamı Bizans’a ait sayılmadı. Mısır, Suriye ve Filistin ana Memlük alanı; Hicaz taraması Memlük üst hâkimiyetindeki yerel şerifliklerdir. Çöl uçları ve küçük Latin mevzileri genelleştirilmiştir. Şehir bölgeleri tarihî idarî sınır iddiası taşımaz.'}
(OUT/'map-data.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
(OUT/'provinces.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','id':p['id'],'properties':{k:v for k,v in p.items() if k not in ['dx','dy','anchor','map_x','map_y']},'geometry':mapping(province_shapes[p['id']])} for p in provinces]},ensure_ascii=False))
template=(ROOT/'src/index.template.html').read_text().replace('/* ATLAS_CSS */',(ROOT/'src/atlas.css').read_text()+'\n'+(ROOT/'src/strategy.css').read_text()).replace('/* ATLAS_APP */',(ROOT/'src/atlas-app.js').read_text())
template=template.replace('<!-- MAP_SVG -->',svgtext.replace('role="img" aria-labelledby','role="group" aria-labelledby')).replace('/* MAP_DATA */',json.dumps(payload,ensure_ascii=False).replace('</','<\\/'))
(OUT/'atlas.html').write_text(template)
print(json.dumps(payload['stats']|{'geometry_checks':'passed'}))
