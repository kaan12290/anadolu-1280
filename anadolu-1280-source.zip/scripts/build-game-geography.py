"""Shared borders for changing country ownership in the playable game."""
from atlas_provinces import *
edges=[]
for a in provinces:
 for bid in a['neighbours']:
  if a['id']>bid:continue
  boundary=province_shapes[a['id']].boundary.intersection(province_shapes[bid].buffer(.000003))
  edges.append({'a':a['id'],'b':bid,'path':gpath(boundary)})
outer=territory_land.boundary.difference(land.boundary.buffer(.00005))
(OUT/'game-edges.json').write_text(json.dumps({'shared':edges,'outer':gpath(outer)},ensure_ascii=False,separators=(',',':')))
print('Game geography:',len(edges),'shared borders')
