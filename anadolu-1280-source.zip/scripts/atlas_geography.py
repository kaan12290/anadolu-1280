"""Expanded 1280 atlas with a shared political partition and Lambert projection."""
import json, math, pathlib, html, random
from shapely.geometry import shape, Polygon, Point, box
from shapely.ops import unary_union
from shapely import set_precision
ROOT=pathlib.Path(__file__).resolve().parents[1]
DATA=ROOT/'source-data';OUT=ROOT/'dist';OUT.mkdir(exist_ok=True)
history=json.loads((DATA/'history-1280.json').read_text())
scenario=json.loads((DATA/'regional-1280.json').read_text())
F=scenario['frame'];WEST,EAST,SOUTH,NORTH=[F[k] for k in ['west','east','south','north']]
W,H,TOP,PH=F['width'],F['height'],F['top'],F['plot_height']
frame=box(WEST,SOUTH,EAST,NORTH)
source_frame=box(WEST-8,SOUTH-5,EAST+8,NORTH+5)
# Spherical Lambert conformal conic; standard parallels 25 and 43 degrees.
p1,p2,p0=map(math.radians,[25,43,34]);l0=math.radians(32)
LCC_N=math.log(math.cos(p1)/math.cos(p2))/math.log(math.tan(math.pi/4+p2/2)/math.tan(math.pi/4+p1/2))
LCC_F=math.cos(p1)*math.tan(math.pi/4+p1/2)**LCC_N/LCC_N
RHO0=LCC_F/math.tan(math.pi/4+p0/2)**LCC_N
def project(p):
 lon,lat=map(math.radians,p);rho=LCC_F/math.tan(math.pi/4+lat/2)**LCC_N
 return rho*math.sin(LCC_N*(lon-l0)),RHO0-rho*math.cos(LCC_N*(lon-l0))
samples=[]
for i in range(161):
 x=WEST+(EAST-WEST)*i/160;y=SOUTH+(NORTH-SOUTH)*i/160
 samples += [project((x,SOUTH)),project((x,NORTH)),project((WEST,y)),project((EAST,y))]
X0=min(x for x,y in samples);X1=max(x for x,y in samples);Y0=min(y for x,y in samples);Y1=max(y for x,y in samples)
SCALE=min((W-24)/(X1-X0),(PH-24)/(Y1-Y0));OX=(W-(X1-X0)*SCALE)/2;OY=TOP+(PH-(Y1-Y0)*SCALE)/2
def xy(p):
 x,y=project(p);return OX+(x-X0)*SCALE,OY+(Y1-y)*SCALE
def inverse_xy(px,py):
 x=X0+(px-OX)/SCALE;y=Y1-(py-OY)/SCALE
 rho=math.hypot(x,RHO0-y);theta=math.atan2(x,RHO0-y)
 lat=2*math.atan((LCC_F/rho)**(1/LCC_N))-math.pi/2
 return math.degrees(l0+theta/LCC_N),math.degrees(lat)
# Clip political areas to the existing rectangular camera, including the
# visible Lambert corners beyond the nominal longitude/latitude envelope.
edge=[]
for a,b in [((0,TOP),(W,TOP)),((W,TOP),(W,TOP+PH)),((W,TOP+PH),(0,TOP+PH)),((0,TOP+PH),(0,TOP))]:
 for i in range(241):edge.append(inverse_xy(a[0]+(b[0]-a[0])*i/240,a[1]+(b[1]-a[1])*i/240))
visible_frame=Polygon(edge)
def esc(s):return html.escape(str(s),quote=True)
def ringpath(points,close=True):return 'M'+' L'.join(f'{x:.2f},{y:.2f}' for x,y in map(xy,points))+(' Z' if close else '')
def gpath(g):
 if g.is_empty:return ''
 if g.geom_type=='Polygon':return ringpath(g.exterior.coords)+' '+' '.join(ringpath(r.coords) for r in g.interiors)
 if g.geom_type in ['MultiPolygon','GeometryCollection','MultiLineString']:return ' '.join(gpath(c) for c in g.geoms)
 if g.geom_type in ['LineString','LinearRing']:return ringpath(g.coords,False)
 return ''
def mapbounds(g):
 pts=[]
 def walk(q):
  if q.geom_type=='Polygon':pts.extend(xy(p) for p in q.exterior.coords)
  elif hasattr(q,'geoms'):
   for c in q.geoms:walk(c)
 walk(g)
 return [min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)]
def smooth_ring(points,steps=5,tension=.1):
 result=[];n=len(points)
 for i,p1 in enumerate(points):
  p0,p2,p3=points[(i-1)%n],points[(i+1)%n],points[(i+2)%n]
  for j in range(steps):
   t=j/steps;t2=t*t;t3=t2*t
   result.append(tuple((2*t3-3*t2+1)*p1[k]+(t3-2*t2+t)*tension*(p2[k]-p0[k])+(-2*t3+3*t2)*p2[k]+(t3-t2)*tension*(p3[k]-p1[k]) for k in [0,1]))
 return result
regions=scenario['countries'];source_all=history['SOURCES']+scenario['sources'];byid={r['id']:r for r in regions}
for r in regions:
 r['source']=[12]+list(range(len(history['SOURCES']),len(source_all)))
 if r['id']=='seljuk':r['source']=[0,1,12]
pieces=[]
for f in json.loads((DATA/'land.geojson').read_text())['features']:
 g=shape(f['geometry']).intersection(source_frame)
 if not g.is_empty:pieces.append(g)
land=unary_union(pieces).buffer(0)
island_land=unary_union([p for p in (land.geoms if hasattr(land,'geoms') else [land]) if p.area<20])
raw={}
for r in regions:
 parts=[]
 for i,p in enumerate(r['parts']):
  g=Polygon(smooth_ring(p)).buffer(0).intersection(land).intersection(visible_frame)
  if r['id']=='byzantine' and i==2:g=g.intersection(island_land)
  parts.append(g)
 raw[r['id']]=unary_union(parts)
owned={};occupied=Polygon()
for r in reversed(regions):
 g=raw[r['id']].difference(occupied).buffer(0);owned[r['id']]=g;occupied=unary_union([occupied,g])
# A nanodegree grid removes floating-point cracks at repaired shared edges.
owned={key:set_precision(g,1e-9) for key,g in owned.items()}
occupied=unary_union(list(owned.values()))
# Frontier repairs may add unassigned land only. They cannot overwrite any
# existing country's territory or claim neutral land outside their local mask.
for repair in scenario.get('frontier_fills',[]):
 g=set_precision(Polygon(repair['poly']).intersection(land).intersection(visible_frame).difference(occupied).buffer(0),1e-9)
 owned[repair['owner']]=unary_union([owned[repair['owner']],g]).buffer(0)
 occupied=unary_union([occupied,g])
territory_land=unary_union(list(owned.values()))
context_land=land.difference(territory_land)
for i,a in enumerate(regions):
 assert owned[a['id']].is_valid and not owned[a['id']].is_empty,a['id']
 for b in regions[i+1:]:assert owned[a['id']].intersection(owned[b['id']]).area<1e-8,'Country overlap'
frontiers=unary_union([g.boundary for g in owned.values()]).difference(land.boundary.buffer(.00005))
subject_shapes=[(s,Polygon(s['poly']).intersection(owned[s['owner']])) for s in scenario['subjects']]
cities=scenario['locations'];capitals={c['city'] for c in scenario['capitals'].values() if c['city']}
