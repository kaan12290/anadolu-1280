#!/usr/bin/env python3
"""Three original visual concepts using the approved map without geometry edits."""
from pathlib import Path
import base64, html, json
import atlas_assets as art

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'dist/ui-drafts'
OUT.mkdir(parents=True,exist_ok=True)
DATA=json.loads((ROOT/'dist/map-data.json').read_text())
MW=DATA['map']['width'];MH=DATA['map']['plot_height'];MT=DATA['map']['top']
KONYA=next(p for p in DATA['provinces'] if p['name']=='Konya')
PROVINCE_NAMES={p['id']:p['name'] for p in DATA['provinces']}
POINTS={p['name']:p for p in DATA['provinces']}
def uri(p):return 'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()
MAP=uri(ROOT/'dist/ui-assets/map-base.png')
RULER=uri(ROOT/'dist/ui-assets/ruler-concept.png')
E=html.escape

SYMBOLS='''<defs>
<symbol id="ui-coins" viewBox="0 0 24 24"><ellipse cx="10" cy="6" rx="7" ry="3"/><path d="M3 6v5c0 4 14 4 14 0V6M3 11v5c0 4 14 4 14 0v-5m2-3 2 2v7c0 2-3 4-7 4"/></symbol>
<symbol id="ui-army" viewBox="0 0 24 24"><path d="M6 20V10a6 6 0 0 1 12 0v10M3 20h18M8 11h8m-4-6v15m-7-4h14M9 3h6"/></symbol>
<symbol id="ui-seal" viewBox="0 0 24 24"><path d="m12 2 3 3 4 1 1 4 2 3-3 3-1 4-4 1-3 2-3-3-4-1-1-4-2-3 3-3 1-4 4-1Z"/><path d="m8 12 3 3 5-6"/></symbol>
<symbol id="ui-balance" viewBox="0 0 24 24"><path d="M12 2v19M4 21h16M3 7h18M5 7 1 16h8L5 7Zm14 0-4 9h8l-4-9Z"/></symbol>
<symbol id="ui-crown" viewBox="0 0 24 24"><path d="m2 5 6 5 4-7 4 7 6-5-3 15H5L2 5Zm3 11h14"/></symbol>
<symbol id="ui-book" viewBox="0 0 24 24"><path d="M12 5C8 2 4 3 2 4v16c4-2 7-1 10 1 3-2 6-3 10-1V4c-2-1-6-2-10 1v16Z"/></symbol>
<symbol id="ui-quill" viewBox="0 0 24 24"><path d="M3 22 17 4c3-3 7-2 5 2l-6 10-8 2M4 18l4 1m4-7 5 1"/></symbol>
<symbol id="ui-swords" viewBox="0 0 24 24"><path d="m3 3 4 1 13 15-2 2L4 7 3 3Zm18 0-4 1-5 6m-2 3-6 7 2 2 6-7M1 16l7 7m8-22 7 7M16 15l7 7"/></symbol>
<symbol id="ui-castle" viewBox="0 0 24 24"><path d="M2 21V6h4v4h3V3h6v7h3V6h4v15H2Zm8 0v-7h4v7"/></symbol>
<symbol id="ui-ship" viewBox="0 0 24 24"><path d="M12 2v14M12 3l9 10h-9M9 5l-7 8h7M2 17h20l-4 5H6L2 17Z"/></symbol>
<symbol id="ui-compass" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="m16 6-2 8-8 4 4-8 6-4Z"/></symbol>
<symbol id="ui-horse" viewBox="0 0 24 24"><path d="M4 21v-5l5-6-1-5 4 1 3-4 5 5-2 6-4-1-2 5v4M3 21h13m0-13h1"/></symbol>
<symbol id="ui-people" viewBox="0 0 24 24"><circle cx="12" cy="6" r="4"/><path d="M5 22v-6c0-7 14-7 14 0v6M3 6a3 3 0 0 0-1 6m20-6a3 3 0 0 1 1 6M2 22v-5m20 5v-5"/></symbol>
<symbol id="ui-bell" viewBox="0 0 24 24"><path d="M4 18h16l-2-4V9c0-8-12-8-12 0v5l-2 4ZM9 21h6M11 1h2"/></symbol>
<symbol id="ui-pause" viewBox="0 0 24 24"><path d="M7 4v16m10-16v16" stroke-width="4"/></symbol>
<symbol id="ui-play" viewBox="0 0 24 24"><path d="m7 3 14 9-14 9V3Z"/></symbol>
<symbol id="ui-settings" viewBox="0 0 24 24"><path d="M4 2v20M12 2v20M20 2v20M1 7h6m2 10h6m2-6h6"/></symbol>
</defs>'''

class Screen:
 def __init__(self,n,title):
  self.n=n;self.i=0
  self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1000" viewBox="0 0 1600 1000" role="img" aria-labelledby="title"><title id="title">{E(title)} — Anadolu 1280 ana ekran taslağı</title>',SYMBOLS,art.defs(),'''<defs><linearGradient id="metal" x2="0" y2="1"><stop stop-color="#314a46"/><stop offset="1" stop-color="#172d30"/></linearGradient><linearGradient id="vellum" x2="1" y2=".3"><stop stop-color="#d5c092"/><stop offset=".4" stop-color="#eddfbd"/><stop offset="1" stop-color="#dec9a0"/></linearGradient><linearGradient id="coal" x2="0" y2="1"><stop stop-color="#283235"/><stop offset="1" stop-color="#151e22"/></linearGradient><pattern id="grain" width="21" height="19" patternUnits="userSpaceOnUse"><path d="M2 4h2m9 7h1m3-9v1" stroke="#70583b" stroke-opacity=".12" stroke-width=".6"/></pattern></defs><style>.ui{font-family:DejaVu Sans,Arial,sans-serif}.display{font-family:DejaVu Serif,Georgia,serif}text{font-variant-numeric:tabular-nums}</style>''']
 def add(self,s):self.a.append(s)
 def rect(self,x,y,w,h,fill,stroke=None,sw=1):self.add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"'+(f' stroke="{stroke}" stroke-width="{sw}"' if stroke else '')+'/>')
 def line(self,x1,y1,x2,y2,c='#a58b59',w=1):self.add(f'<path d="M{x1} {y1}H{x2}" stroke="{c}" stroke-width="{w}"/>' if y1==y2 else f'<path d="M{x1} {y1} {x2} {y2}" stroke="{c}" stroke-width="{w}"/>')
 def text(self,x,y,t,size=16,c='#e7d7b2',serif=False,anchor=None,spacing=None,weight=None):
  self.add(f'<text class="{"display" if serif else "ui"}" x="{x}" y="{y}" font-size="{size}" fill="{c}"'+(f' text-anchor="{anchor}"' if anchor else '')+(f' letter-spacing="{spacing}"' if spacing else '')+(f' font-weight="{weight}"' if weight else '')+'>'+E(str(t))+'</text>')
 def label(self,x,y,t,c='#a8b49c',size=11):self.text(x,y,t,size,c,spacing=1.8)
 def icon(self,key,x,y,size=24,c='#d6bc7c'):
  self.add(f'<use href="#ui-{key}" x="{x}" y="{y}" width="{size}" height="{size}" stroke="{c}" color="{c}" fill="none" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"/>')
 def use(self,key,x,y,w,h):self.add(f'<use href="#{key}" x="{x}" y="{y}" width="{w}" height="{h}"/>')
 def portrait(self,x,y,w,h):
  self.i+=1;k=f'portrait{self.i}'
  self.add(f'<defs><clipPath id="{k}"><rect x="{x}" y="{y}" width="{w}" height="{h}"/></clipPath></defs><image href="{RULER}" x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="xMidYMid slice" clip-path="url(#{k})"/>')
  self.rect(x-2,y-2,w+4,h+4,'none','#b19a61',1.5)
 def map(self,x,y,w,h,shade=0):
  self.i+=1;k=f'mapclip{self.i}';scale=min(w/MW,h/MH);iw=MW*scale;ih=MH*scale;ox=x+(w-iw)/2;oy=y+(h-ih)/2
  self.rect(x,y,w,h,'#79948f');self.add(f'<defs><clipPath id="{k}"><rect x="{x}" y="{y}" width="{w}" height="{h}"/></clipPath></defs><g clip-path="url(#{k})"><image href="{MAP}" x="{ox}" y="{oy}" width="{iw}" height="{ih}"/>')
  if shade:self.rect(x,y,w,h,f'#17282b{round(shade*255):02x}')
  self.add('</g>')
  return lambda name:(ox+POINTS[name]['map_x']*scale,oy+(POINTS[name]['map_y']-MT)*scale)
 def tag(self,x,y,w,t,fill='#203b3b',c='#dfc797'):
  self.rect(x,y,w,31,fill,'#ae9664',.8);self.text(x+12,y+21,t,11,c,spacing=1.2)
 def finish(self,slug):
  self.add('</svg>');p=OUT/(slug+'.svg');p.write_text(''.join(self.a));return p

def metric(s,x,icon,label,value,sub=None):
 s.icon(icon,x,22,27);s.label(x+39,27,label,size=10);s.text(x+39,58,value,24,'#ead5a3',True)
 if sub:s.text(x+114,56,sub,11,'#a7bc98')
def zoom(s,x,y,dark=True):
 bg='#203637' if dark else '#e7d6ad';fg='#e3cca1' if dark else '#735839'
 s.rect(x,y,145,36,bg,'#a99060');s.text(x+16,y+25,'−',21,fg);s.line(x+39,y,x+39,y+36);s.text(x+54,y+25,'+',21,fg);s.line(x+78,y,x+78,y+36);s.text(x+112,y+24,'100%',12,fg,anchor='middle')
def note(s,n,light=False):
 s.text(1580,985,f'GÖRSEL TASLAK {n:02d} · PORTRE VE OYUN DEĞERLERİ TEMSİLÎDİR',10,'#8a7958' if light else '#9aab98',anchor='end',spacing=1)

def atlas():
 s=Screen(1,'Devlet Atlası');s.rect(0,0,1600,1000,'#203638');s.rect(0,0,1600,86,'url(#metal)');s.use('crest-seljuk',20,11,49,61)
 s.text(84,39,'ANADOLU',25,'#ead7a7',True,spacing=4);s.text(275,39,'1280',26,'#c9ab72',True)
 s.label(84,64,'TÜRKİYE SELÇUKLULARI',size=10)
 for args in [(435,'coins','HAZİNE','2.480','+36'),(615,'people','İNSAN GÜCÜ','18.000',None),(815,'balance','İSTİKRAR','+1',None),(985,'seal','OTORİTE','65',None)]:metric(s,*args)
 s.line(1193,15,1193,70,'#75816a');s.text(1220,35,'1 OCAK 1280',17,'#ead7ae',True);s.label(1220,60,'DURAKLATILDI',size=10);s.icon('pause',1433,24,24);s.text(1482,44,'1  2  3  4  5',16,'#baad87')
 s.line(0,85,1600,85,'#bca26b',2);s.rect(0,87,1600,45,'#3d5148')
 for i,(key,name) in enumerate([('crown','Devlet'),('book','Saray'),('quill','Diplomasi'),('swords','Ordular'),('coins','Ekonomi'),('seal','Kararlar')]):
  x=83+i*174
  if i==0:s.rect(x-12,94,154,31,'#6d7a5b44','#a99768',.6)
  s.icon(key,x,99,20);s.text(x+30,115,name,14,'#e4d6b1' if not i else '#bfcaaf')
 s.label(1307,115,'ŞEHİR BÖLGELERİ  69',size=10)
 s.map(62,132,1212,748);s.rect(0,132,62,748,'url(#metal)');s.line(61,132,61,880)
 for i,k in enumerate(['compass','castle','ship','army','people','bell','settings']):
  y=161+i*78
  if i==0:s.rect(8,y-6,46,46,'#7a89624d','#aa9963',.8)
  s.icon(k,19,y+5,24)
 s.tag(86,151,224,'SİYASİ HARİTA · ANADOLU');s.tag(1011,151,239,'ŞEHİR VE FETİH BÖLGELERİ','#eadbb9','#755839');zoom(s,1102,823)
 s.rect(1274,132,326,748,'url(#vellum)');s.line(1274,132,1274,880,'#9a7c4d',2)
 s.rect(1274,132,326,108,'url(#metal)');s.label(1296,159,'SEÇİLİ ŞEHİR BÖLGESİ');s.text(1296,202,'Konya',32,'#ecd9ac',True);s.use('banner-seljuk',1517,164,61,44);s.text(1296,225,'Başkent · Türkiye Selçukluları',12,'#b4c0a4')
 s.use('site-capital',1370,252,139,120);s.label(1296,392,'BÖLGE DURUMU','#917447');s.line(1296,405,1578,405,'#bfaa80')
 for i,(k,v) in enumerate([('Bağlılık','Sadık'),('Tahkimat','Selçuklu surları'),('Arazi','Plato'),('Kara komşusu',str(len(KONYA['neighbours']))+' bölge')]):
  y=433+i*39;s.text(1296,y,k,13,'#9a8053');s.text(1577,y,v,13,'#684a30',anchor='end');s.line(1296,y+13,1578,y+13,'#c7b58e',.7)
 s.label(1296,610,'KOMŞU BÖLGELER','#917447')
 for i,t in enumerate([PROVINCE_NAMES[i] for i in KONYA['neighbours'][:4]]):
  x=1296+(i%2)*145;y=625+(i//2)*39;s.rect(x,y,137,30,'#d8c49d','#b89b6b',.7);s.text(x+10,y+20,t,12,'#775737')
 s.line(1296,718,1578,718,'#af9465');s.portrait(1298,739,61,77);s.label(1375,754,'SARAYDAN HABER','#917447',size=10);s.text(1375,780,'Divan toplanabilir',14,'#68482e',True);s.text(1375,803,'Yeni karar gündemi',11,'#927347')
 s.rect(1296,836,282,31,'#354d43','#b69a64');s.text(1437,857,'ŞEHİR YÖNETİMİ',11,'#e2d1a5',anchor='middle',spacing=1.5)
 s.rect(0,880,1600,120,'url(#metal)');s.line(0,880,1600,880,'#b89b62',2);s.portrait(22,895,66,82);s.label(106,912,'HÜKÜMDAR');s.text(106,942,'Devletin iradesi',19,'#e6d2a5',True);s.text(106,966,'Tedbirli  ·  Kararlı',11,'#a5b496')
 for x,key,title,body in [(410,'ship','SİNOP LİMANI','Liman ve kıyı yönetimi'),(785,'book','SARAY GÜNDEMİ','Danışmanlar ve devlet kararları'),(1160,'castle','KONYA SAVUNMASI','Kale ve sur geliştirmeleri')]:
  s.line(x-26,903,x-26,963,'#627360');s.icon(key,x,919,31);s.label(x+46,919,title,size=10);s.text(x+46,946,body,12,'#d3cdaf')
 note(s,1);return s.finish('devlet')

def palace():
 s=Screen(2,'Saray Defteri');s.rect(0,0,1600,1000,'url(#vellum)');s.rect(0,0,1600,1000,'url(#grain)');s.rect(0,0,1600,92,'#e9d9b5');s.use('crest-seljuk',24,15,46,57)
 s.text(87,40,'ANADOLU',25,'#6c452e',True,spacing=4);s.text(277,40,'1280',26,'#9a7848',True);s.label(87,68,'TÜRKİYE SELÇUKLULARI','#9b7e50',10)
 for x,key,lab,val in [(700,'coins','HAZİNE','2.480'),(907,'people','İNSAN GÜCÜ','18.000'),(1147,'seal','OTORİTE','65')]:
  s.icon(key,x,27,29,'#876b3d');s.label(x+41,34,lab,'#9b8054',10);s.text(x+41,63,val,23,'#6a482f',True)
 s.line(1354,18,1354,73,'#b49a6c');s.text(1383,39,'1 OCAK 1280',16,'#715136',True);s.label(1383,64,'DURAKLATILDI','#9b8054',9);s.icon('pause',1544,31,20,'#886d42');s.line(0,91,1600,91,'#b39562',2)
 s.rect(0,93,350,907,'#dac49b');s.rect(16,106,318,871,'none','#b39665',.8);s.line(349,93,349,1000,'#a78b5d',2);s.portrait(29,120,292,327)
 s.add('<circle cx="289" cy="446" r="26" fill="#87443a" stroke="#b88a60" stroke-width="2"/>');s.use('crest-seljuk',275,427,28,34)
 s.label(32,484,'HÜKÜMDAR','#8b6e43',11);s.text(32,520,'Devletin iradesi',24,'#63432f',True)
 for i,(lab,val) in enumerate([('Otorite','65 / 100'),('İdare','Yetenekli'),('Askerî görüş','Tedbirli')]):
  y=554+i*38;s.text(32,y,lab,13,'#987a4c');s.text(318,y,val,14,'#6e5033',anchor='end');s.line(32,y+13,318,y+13,'#bfa67c',.8)
 s.tag(32,672,130,'TEDBİRLİ','#e8d6b0','#725437');s.tag(172,672,146,'KARARLI','#e8d6b0','#725437')
 s.label(32,739,'SARAY GÖREVLİLERİ','#8b6e43')
 for i,(key,role,body) in enumerate([('quill','Vezir','İç düzen ve yönetim'),('swords','Komutan','Ordu ve sefer hazırlığı'),('book','Elçi','Dış ilişkiler ve görüşmeler')]):
  y=768+i*63;s.icon(key,34,y,25,'#8f7241');s.text(77,y+10,role,17,'#69472e',True);s.text(77,y+32,body,11,'#987b50');s.line(32,y+44,318,y+44,'#bfa67c',.7)
 s.rect(350,93,1250,49,'#f0e1be')
 for i,t in enumerate(['Harita','Saray','Elçilik','Beratlar']):
  x=378+i*162
  if i==0:s.line(x,136,x+111,136,'#8c653c',2)
  s.text(x+3,124,t,15,'#725137',True)
 s.label(1325,123,'SARAY DEFTERİ','#a58b61',10)
 s.map(350,142,1250,646);s.tag(373,163,209,'DEVLET ATLASI · 1280','#e8d7b1','#765439');zoom(s,1425,728,False)
 s.rect(1309,212,267,274,'#ead9b5','#a68a58',1.2);s.label(1328,238,'SEÇİLİ ŞEHİR','#96784b',10);s.text(1328,276,'Konya',30,'#67432b',True);s.use('site-capital',1437,251,103,81);s.text(1328,307,'Başkent',14,'#9a7844',True);s.line(1328,330,1557,330,'#b99c6b')
 for i,(k,v) in enumerate([('Yönetim','Selçuklu'),('Savunma','Surlar'),('Komşular',str(len(KONYA['neighbours']))+' bölge')]):
  y=359+i*35;s.text(1328,y,k,12,'#9a7e51');s.text(1555,y,v,13,'#725035',anchor='end')
 s.rect(1328,453,228,24,'#d2bb90');s.text(1442,470,'ŞEHİR DEFTERİNİ AÇ',10,'#745337',anchor='middle',spacing=1)
 s.rect(350,788,1250,212,'#e9d8b1');s.line(350,788,1600,788,'#9f7c4c',2);s.icon('book',376,812,26,'#9a7844');s.label(417,831,'DİVAN GÜNDEMİ','#99794d');s.text(1569,831,'DEVLET KARARLARI',10,'#a38b61',anchor='end',spacing=1.5)
 for x,key,title,body in [(377,'castle','Tahkimatı güçlendir','Kaleler ve şehir savunması'),(782,'ship','Ticareti destekle','Limanlar ve ticaret yolları'),(1184,'people','Halkı gözet','İç düzen ve bölge bağlılığı')]:
  s.line(x,852,x+374,852,'#c0a476');s.icon(key,x,879,31,'#8b6b3f');s.text(x+48,892,title,18,'#705034',True);s.text(x+48,920,body,12,'#987b4f');s.text(x+48,947,'Karar ayrıntıları  →',11,'#855c38')
 note(s,2,True);return s.finish('saray')

def war():
 s=Screen(3,'Sefer Masası');s.rect(0,0,1600,1000,'#172126');s.rect(0,0,1600,82,'url(#coal)');s.use('crest-seljuk',20,11,45,56);s.label(80,31,'TÜRKİYE SELÇUKLULARI',size=10);s.text(80,60,'SEFER MASASI',23,'#e8d4aa',True,spacing=2)
 for args in [(446,'coins','HAZİNE','2.480',None),(640,'people','İNSAN GÜCÜ','18.000',None),(864,'army','SEÇİLİ ORDU','11.000',None),(1080,'castle','TAHKİMAT',str(DATA['stats']['forts']),None)]:metric(s,*args)
 s.text(1320,32,'1 OCAK 1280',16,'#d9c6a0',True);s.label(1320,58,'DURAKLATILDI',size=9);s.icon('pause',1518,26,22);s.line(0,81,1600,81,'#b39862',2)
 s.rect(0,82,298,918,'url(#coal)');s.line(297,82,297,1000,'#b19360',1.5);s.label(23,118,'SEÇİLİ BİRLİK','#9eaa9b',10);s.text(23,157,'Konya Ordusu',25,'#e6cf9c',True);s.text(23,186,'Harekete hazır',13,'#9eb38d');s.portrait(23,214,252,237);s.label(23,481,'HÜKÜMDARIN OTAĞI',size=10);s.text(23,510,'Seferin komutası',18,'#dfcba3',True);s.line(23,531,275,531,'#68705d')
 for i,(k,v) in enumerate([('Toplam asker','11.000'),('Moral','%85'),('İkmal','Yeterli'),('Mevcut konum','Konya')]):
  y=563+i*42;s.text(23,y,k,12,'#98a694');s.text(275,y,v,15,'#d4c69f',anchor='end');s.line(23,y+15,275,y+15,'#475448',.7)
 s.label(23,762,'HAREKET PLANI',size=10);s.icon('compass',23,784,23);s.text(61,803,'Konya → Karahisar',16,'#e4cc9d',True);s.text(23,838,'Güzergâh ve ikmal görünümü',11,'#99a590');s.rect(23,866,252,42,'#6f4336','#ad8c58');s.text(149,893,'HAREKÂT EMİRLERİ',11,'#e1c49b',anchor='middle',spacing=1.5)
 s.icon('settings',23,941,20,'#8f9c8e');s.text(57,957,'Ordu düzeni',12,'#aeb69e')
 pos=s.map(298,82,1302,697,.07)
 for i,t in enumerate(['ORDULAR','KALELER','İKMAL']):s.tag(321+i*144,102,136,t,'#684336' if i==0 else '#253537','#e2c99c')
 s.tag(1369,102,208,'SEFER HARİTASI · 1280')
 a=pos('Konya');b=pos('Karahisar');c=pos('Eskişehir')
 s.add(f'<path d="M{a[0]} {a[1]} Q{a[0]-45} {a[1]-68} {b[0]} {b[1]} T{c[0]} {c[1]}" fill="none" stroke="#ead7a6" stroke-width="7" stroke-opacity=".6"/><path d="M{a[0]} {a[1]} Q{a[0]-45} {a[1]-68} {b[0]} {b[1]} T{c[0]} {c[1]}" fill="none" stroke="#884d38" stroke-width="3" stroke-dasharray="10 7"/>')
 for name,count in [('Konya','11.000'),('Ankara','3.600'),('Kayseri','2.800')]:
  x,y=pos(name);s.rect(x-34,y-56,87,28,'#263e3d','#b69a60',1.3);s.use('banner-seljuk',x-29,y-53,25,20);s.text(x+22,y-37,count,11,'#eed6a2',anchor='middle');s.add(f'<path d="M{x+4} {y-28}v15" stroke="#ac8e58" stroke-width="2"/>');s.icon('army',x-11,y-14,25,'#f1d9a3')
 s.rect(1261,179,315,249,'#1f2f31ed','#9c8353');s.label(1281,206,'SEFER PLANI',size=10);s.text(1281,240,'Batı güzergâhı',23,'#e2c99b',True);s.text(1281,267,'Konya — Karahisar — Eskişehir',12,'#aeb79b');s.line(1281,284,1556,284,'#69765f')
 for i,(key,t) in enumerate([('army','Birlikleri Konya’da topla'),('compass','Kara güzergâhını incele'),('castle','Tahkimatları değerlendir')]):s.icon(key,1283,302+i*35,18);s.text(1316,316+i*35,t,12,'#c3c5a8')
 s.text(1281,413,'Örnek sefer planı',10,'#99a58e');zoom(s,1430,719)
 s.rect(298,779,1302,221,'url(#coal)');s.line(298,779,1600,779,'#ac8e59',2);s.label(324,810,'ORDU BİLEŞİMİ',size=10);s.label(1002,810,'HAREKÂT ÇİZELGESİ',size=10)
 for x,key,typ,val in [(324,'army','YAYA','8.400'),(547,'horse','SÜVARİ','2.600'),(770,'castle','KUŞATMA','12 araç')]:
  s.rect(x,831,199,114,'#31403c','#59624c',.8);s.icon(key,x+16,849,31);s.label(x+62,857,typ,size=9);s.text(x+62,891,val,24,'#e5cfa3',True);s.text(x+16,929,'Birlik ayrıntıları  →',11,'#a3af96')
 s.line(1011,864,1548,864,'#776d4e',2)
 for i,t in enumerate(['Toplanma','Yürüyüş','Varış']):
  x=1012+i*267;s.add(f'<circle cx="{x}" cy="864" r="6" fill="{"#d4b574" if i==0 else "#485948"}" stroke="#b8a071"/>');s.text(x,896,t,14,'#c8c9ae',anchor='start' if i==0 else 'end' if i==2 else 'middle');s.text(x,922,['Konya','Karahisar yolu','Hedef bölge'][i],11,'#8fa18c',anchor='start' if i==0 else 'end' if i==2 else 'middle')
 note(s,3);return s.finish('sefer')

if __name__=='__main__':
 for func in [atlas,palace,war]:print(func())
