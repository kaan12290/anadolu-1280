"""Build a portable Windows app from a verified official Electron archive."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--runtime',required=True);p.add_argument('--checksums',required=True);p.add_argument('--output',required=True);args=p.parse_args()
runtime=Path(args.runtime);expected=None
for line in Path(args.checksums).read_text().splitlines():
 fields=line.split()
 if fields and fields[-1].lstrip('*')==runtime.name:expected=fields[0]
if not expected or hashlib.file_digest(runtime.open('rb'),'sha256').hexdigest()!=expected:raise ValueError('Electron checksum mismatch')
out=Path(args.output);out.mkdir(parents=True,exist_ok=True);stage=out/'Anadolu_1280_Windows';stage.mkdir(exist_ok=True)
with zipfile.ZipFile(runtime) as z:
 if z.testzip() is not None:raise ValueError('Invalid runtime archive')
 for name in z.namelist():
  if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Unsafe archive path')
 runtime_files=[name for name in z.namelist() if not name.endswith('/')]
 z.extractall(stage)
exe=stage/'electron.exe';exe.rename(stage/'Anadolu_1280.exe')
wer=stage/'electron_wer.dll'
if wer.exists():wer.rename(stage/'Anadolu_1280_wer.dll')
app=stage/'resources/app';app.mkdir(parents=True,exist_ok=True)
for name in ['main.cjs','package.json','icon.png']:shutil.copyfile(ROOT/'desktop'/name,app/name)
shutil.copyfile(ROOT/'dist/index.html',app/'index.html');shutil.copyfile(ROOT/'desktop/OYUNU_BASLAT.txt',stage/'OYUNU_BASLAT.txt')
archive=out/'Anadolu_1280_Windows.zip'
names={('Anadolu_1280.exe' if name=='electron.exe' else 'Anadolu_1280_wer.dll' if name=='electron_wer.dll' else name) for name in runtime_files}
names.update(['resources/app/'+name for name in ['main.cjs','package.json','icon.png','index.html']]);names.add('OYUNU_BASLAT.txt')
hashes={}
for name in sorted(names):
 f=stage/name
 if not f.is_file():raise ValueError('Missing package member: '+name)
 hashes[name]=hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
(stage/'DOSYA_SHA256.json').write_text(json.dumps({'algorithm':'SHA256','files':hashes},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(stage/'DOSYA_KONTROLU.txt').write_text('ANADOLU 1280 — DOSYA KONTROLÜ\n\nResmî Electron arşivinin SHA256 özeti doğrulandı.\nZIP CRC kontrolü, Windows çalıştırıcısının dosya imzası ve oyun HTML eşitliği kontrol edildi.\nDOSYA_SHA256.json paket içindeki '+str(len(hashes))+' oyun ve çalıştırıcı dosyasının özetini içerir.\n\nZIP dosyasına sağ tıkla → Tümünü ayıkla.\nÇıkan klasördeki Anadolu_1280.exe dosyasını aç.\nDosyaları aynı klasörde birlikte tut.\n\nBu kontroller dosya bütünlüğünü doğrular.\nWindows üzerinde programı çalıştırma testi bu Linux ortamında yapılamamıştır.\n',encoding='utf8')
names.update(['DOSYA_SHA256.json','DOSYA_KONTROLU.txt'])
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in sorted(names):
  f=stage/name
  if not f.is_file():raise ValueError('Missing package member: '+name)
  z.write(f,f.relative_to(out))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('Anadolu_1280_Windows/Anadolu_1280.exe')[:2]==b'MZ'
 assert z.read('Anadolu_1280_Windows/resources/app/index.html')==(ROOT/'dist/index.html').read_bytes()
 for name,digest in hashes.items():
  assert hashlib.sha256(z.read('Anadolu_1280_Windows/'+name)).hexdigest()==digest
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'runtime_sha256':expected,'packaging_checks':'passed'},ensure_ascii=False))
