/* v0.4.0, stage 1. All quotes are read-only; monthly production stays in the engine. */
(function(root){
'use strict';
function createStrategy(E){
 const {P,N,units,terrainTypes,graph,sea,own,armies,capital,isWar,economy,policies,localPolicies,log,sync,retire,clamp}=E;
 const kinds=Object.keys(units);
 // Scenario balance weights, not historical revenue statistics.
 const tradeCenters=Object.freeze({'pr-konstantinopolis':12,'pr-iskenderiye':10,'pr-kahire':8,'pr-tebriz':8,'pr-halep':6,'pr-selanik':6,'pr-musul':4,'pr-izmir':4,'pr-konya':3,'pr-trabzon':3,'pr-sis':2,'pr-aksaray':1});
 const combatRules=Object.freeze({riverCrossing:.8,cityPerFort:Object.freeze({infantry:.06,cavalry:0,archer:.05})});
 function incomeBreakdown(s,id){
  const p=s.provinces[id],q=s.nations[p.owner];
  const safe=j=>!s.provinces[j].rebellion&&!isWar(s,p.owner,s.provinces[j].owner);
  const openRoads=p.rebellion?0:graph[id].filter(j=>!sea.has(id+'|'+j)&&safe(j)).length;
  const openHarbors=p.rebellion?0:graph[id].filter(j=>sea.has(id+'|'+j)&&safe(j)).length;
  const parts={development:4+p.development*4,trade:tradeCenters[id]||0,access:Math.min(3,openRoads)*.5,port:P[id].port?(openHarbors?4:2):0,market:p.market*5,road:(p.road||0)*2,capital:capital(s,p.owner)===id?8:0};
  const gross=Object.values(parts).reduce((a,b)=>a+b,0);
  const modifiers={security:1-p.unrest/150,stability:clamp(1+(q.stability-72)*.002,.85,1.04),administration:localPolicies[p.policy].rate,tax:policies[q.tax].rate,advisor:q.advisors.finance?1.12:1};
  modifiers.civic=s.politicsVersion?(p.allegiance<40?.8+p.allegiance/200:p.allegiance>=85?1+(p.allegiance-85)/200:1):1;
  const income=p.rebellion?0:gross*modifiers.civic*modifiers.security*modifiers.stability*modifiers.administration;
  return {parts,modifiers,gross,income,gold:income*modifiers.tax*modifiers.advisor,openRoads,openHarbors,suspended:!!p.rebellion};
 }
 function cityDefense(s,a,id,unit,defending){
  const p=s.provinces[id];
  return defending&&p.owner===a.owner&&!p.rebellion?1+p.fort*combatRules.cityPerFort[unit]:1;
 }
 function terrainGuide(unit){
  if(!Object.hasOwn(units,unit))throw Error('Birlik türü geçersiz.');
  return {name:units[unit].name,terrains:Object.entries(terrainTypes).map(([id,t])=>({id,name:t.name,multiplier:t.unit[unit]})),river:combatRules.riverCrossing,cityPerFort:combatRules.cityPerFort[unit]};
 }
 function managementReason(s,a,n=s.player){
  if(s.lost)return 'Sefer sona erdi.';
  if(!a||a.owner!==n||!s.armies.includes(a))return 'Kendi ordunu seç.';
  if(s.pendingEvents.length||s.nations[n].dynasty?.crisis)return 'Önce bekleyen olay veya taht krizi için karar ver.';
  const p=s.provinces[a.province];
  if(p.owner!==n||p.rebellion)return 'Ordu, denetimindeki güvenli bir şehirde olmalı.';
  if(a.path.length||a.travel||a.siege||a.marchWait)return 'Önce yürüyüşü veya kuşatmayı durdur.';
  if(s.armies.some(b=>b.province===a.province&&isWar(s,n,b.owner)))return 'Düşman varken ordu düzenlenemez.';
  return '';
 }
 const upkeep=selection=>kinds.reduce((v,u)=>v+selection[u]*units[u].upkeep,0);
 function armyQuote(s,action,n=s.player){
  const a=s.armies.find(a=>a.id===action.army),reason=managementReason(s,a,n);
  const fail=reason=>({ok:false,reason});
  if(reason)return fail(reason);
  if(!['splitArmy','mergeArmy','disbandArmy'].includes(action.type))return fail('Geçerli bir ordu işlemi seç.');
  if(action.type==='mergeArmy'){
   const b=s.armies.find(b=>b.id===action.target),otherReason=managementReason(s,b,n);
   if(otherReason)return fail(otherReason);
   if(b===a||b.province!==a.province)return fail('Aynı şehirdeki farklı bir kendi ordunu seç.');
   if(a.troops+b.troops>1e7)return fail('Birleşik ordu sınırını aşar.');
   return {ok:true,reason:'',amount:b.troops,after:a.troops+b.troops,saving:0};
  }
  const selection=action.units;
  if(!selection||typeof selection!=='object'||Array.isArray(selection)||Object.keys(selection).length!==3||!kinds.every(u=>Object.hasOwn(selection,u)&&Number.isSafeInteger(selection[u])&&selection[u]>=0&&selection[u]<=a.units[u]))return fail('Her birlik türü için mevcut sayıyı aşmayan tam sayı gir.');
  const amount=kinds.reduce((v,u)=>v+selection[u],0);
  if(!amount)return fail('En az bir asker seç.');
  if(action.type==='splitArmy'){
   if(amount>=a.troops)return fail('Ana orduda en az bir asker kalmalı.');
   if(s.armies.length>=500||s.nextArmy>=1e6)return fail('Ordu kayıt sınırına ulaşıldı.');
  }
  return {ok:true,reason:'',amount,after:a.troops-amount,saving:action.type==='disbandArmy'?upkeep(selection):0};
 }
 function handle(s,action,n=s.player){
  if(!['splitArmy','mergeArmy','disbandArmy'].includes(action.type))return null;
  const quote=armyQuote(s,action,n);
  if(!quote.ok)throw Error(quote.reason);
  const a=s.armies.find(a=>a.id===action.army);
  if(action.type==='mergeArmy'){
   const b=s.armies.find(b=>b.id===action.target),total=a.troops+b.troops;
   a.morale=(a.morale*a.troops+b.morale*b.troops)/total;
   a.supply=(a.supply*a.troops+b.supply*b.troops)/total;
   a.commander??=b.commander;
   a.lastAssault=Math.max(a.lastAssault,b.lastAssault);
   a.planTurn=Math.max(a.planTurn,b.planTurn);
   a.lastSupplyNotice=Math.max(a.lastSupplyNotice,b.lastSupplyNotice);
   for(const u of kinds)a.units[u]+=b.units[u];
   sync(a);retire(s,b);
   log(s,N[n].short+': '+P[a.province].name+' orduları birleştirildi; toplam '+a.troops+' asker.');
   return 'Ordular birleştirildi; asker sayısı ve toplam erzak korundu.';
  }
  if(action.type==='splitArmy'){
   const child={...a,id:'army-'+s.nextArmy++,units:{...action.units},troops:quote.amount,commander:null,path:[],arrivalFrom:null};
   for(const u of kinds)a.units[u]-=action.units[u];
   sync(a);s.armies.push(child);
   log(s,N[n].short+': '+P[a.province].name+' ordusundan '+quote.amount+' asker ayrı orduya bölündü.');
   return 'Ordu bölündü; yeni ordu komutansız, aynı moral ve erzakla hazır.';
  }
  for(const u of kinds)a.units[u]-=action.units[u];
  sync(a);if(!a.troops)retire(s,a);
  log(s,N[n].short+': '+quote.amount+' asker terhis edildi. Bakım −'+quote.saving.toFixed(2)+' altın/ay; altın veya insan gücü iadesi yok.');
  return quote.amount+' asker terhis edildi; bakım '+quote.saving.toFixed(2)+' altın/ay azaldı.';
 }
 function ai(s,n){
  if(n===s.player||s.turn%3||s.nations[n].dynasty?.crisis||s.pendingEvents.length)return;
  const q=s.nations[n],available=armies(s,n).filter(a=>!managementReason(s,a,n));
  const atWar=s.wars.some(w=>w.a===n||w.b===n);
  for(const a of available){
   const b=available.find(b=>b!==a&&b.province===a.province&&s.armies.includes(b)&&a.troops+b.troops<=12000);
   if(s.armies.includes(a)&&b){handle(s,{type:'mergeArmy',army:a.id,target:b.id},n);break}
  }
  const force=armies(s,n).find(a=>!managementReason(s,a,n));
  if(!force)return;
  if(!atWar&&q.gold<economy(s,n).upkeep&&economy(s,n).net<0){
   const selection=Object.fromEntries(kinds.map(u=>[u,Math.floor(force.units[u]*.15)]));
   if(Object.values(selection).some(v=>v))handle(s,{type:'disbandArmy',army:force.id,units:selection},n);
  }else if(atWar&&force.troops>12000&&armies(s,n).length<4&&armyQuote(s,{type:'splitArmy',army:force.id,units:Object.fromEntries(kinds.map(u=>[u,Math.floor(force.units[u]/2)]))},n).ok){
   handle(s,{type:'splitArmy',army:force.id,units:Object.fromEntries(kinds.map(u=>[u,Math.floor(force.units[u]/2)]))},n);
  }
 }
 return {incomeBreakdown,tradeCenters,combatRules,cityDefense,terrainGuide,managementReason,armyQuote,handle,upkeep,ai};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createStrategy;else root.createAnadoluStrategy=createStrategy;
})(typeof globalThis!=='undefined'?globalThis:this);
