/* Stage 1 UI: on-demand ledgers; the map and its layers remain untouched. */
const S=E.strategy;
const decimal=v=>v.toLocaleString('tr-TR',{maximumFractionDigits:2});
const percent=v=>(v>=0?'+':'−')+decimal(Math.abs(v)*100)+'%';
let managedArmy=null;
function incomeDetails(id){
 const b=S.incomeBreakdown(game,id),names={development:'Şehir ve gelişim',trade:'Ticaret merkezi',access:'Güvenli kara bağlantıları',port:'Liman',market:'Pazarlar',road:'Ticaret yolu',capital:'Başkent'};
 return '<details class="strategy-income"><summary>Gelir nasıl hesaplanıyor?</summary><dl>'+Object.entries(b.parts).map(([k,v])=>'<div><dt>'+names[k]+'</dt><dd>+'+decimal(v)+'</dd></div>').join('')+'<div><dt>Temel toplam</dt><dd>'+decimal(b.gross)+'</dd></div>'+Object.entries(b.modifiers).map(([k,v])=>'<div><dt>'+({security:'Şehir güvenliği',stability:'Devlet istikrarı',administration:'Yerel yönetim',tax:'Vergi politikası',advisor:'Maliye görevlisi'}[k])+'</dt><dd>×'+decimal(v)+'</dd></div>').join('')+'<div><dt>Aylık şehir vergisi</dt><dd>'+decimal(b.gold)+' altın</dd></div></dl><p>'+(b.suspended?'İsyancı denetiminde tahsilat durdu.':'Bu tutar ay geçişinde bir defa tahsil edilir. Kervan varış ödemeleri ayrıca kendi defterindedir.')+'</p></details>';
}
function unitHelp(u){
 const g=S.terrainGuide(u);
 return '<span class="unit-tooltip" role="tooltip"><strong>'+g.name+' · arazi</strong>'+g.terrains.map(t=>'<span>'+t.name+' <b>'+percent(t.multiplier-1)+'</b></span>').join('')+'<span>Nehirden saldırı <b>'+percent(g.river-1)+'</b></span><span>Şehir savunması <b>'+(g.cityPerFort?percent(g.cityPerFort)+'/kale seviyesi':'Ek bonus yok')+'</b></span><small>Arazi savunması, moral, ikmal ve komutan ayrıca etkilidir.</small></span>';
}
const strategyPreviousProvince=renderProvince;
renderProvince=function(){
 strategyPreviousProvince();if(!game)return;
 const dl=$('#province-panel dl');dl?.insertAdjacentHTML('afterend',incomeDetails(selectedProvince));
 const select=$('#recruit-unit');if(!select)return;
 select.hidden=true;$('#province-panel .unit-label')?.remove();
 select.insertAdjacentHTML('beforebegin','<div class="unit-picker" role="radiogroup" aria-label="Birlik türü">'+Object.entries(E.units).map(([u,v])=>'<button type="button" role="radio" tabindex="'+(select.value===u?'0':'-1')+'" aria-checked="'+(select.value===u)+'" data-strategy-unit="'+u+'" aria-label="'+v.name+'; arazi bilgisi için üzerinde bekle">'+v.icon+' '+v.name+unitHelp(u)+'</button>').join('')+'</div>');
};
const strategyPreviousArmies=renderArmies;
renderArmies=function(){
 strategyPreviousArmies();if(!game)return;
 $('#strategy-army-entry')?.remove();
 $('#army-list').insertAdjacentHTML('beforebegin','<div id="strategy-army-entry"><button class="strategy-open-armies" data-strategy-armies>Ordu Yönetimi →</button></div>');
};
function armyManager(id=managedArmy){
 const list=E.armies(game,game.player),a=list.find(a=>a.id===id)||list.find(a=>a.id===selectedArmy)||list[0];managedArmy=a?.id||null;
 if(!a){openDialog('Ordu Yönetimi','<div class="dialog-help"><p>Henüz sahra ordun yok. Kendi şehrinden asker toplayabilirsin.</p></div>');return}
 const reason=S.managementReason(game,a),others=list.filter(b=>b!==a&&b.province===a.province);
 openDialog('Ordu Yönetimi','<div class="dialog-help strategy-army-panel"><p class="eyebrow">'+escapeHtml(E.N[game.player].short)+' · GELİŞTİRME SÜRÜMÜ / AŞAMA 1</p><label for="managed-army">Düzenlenecek ordu</label><select id="managed-army">'+list.map(x=>'<option value="'+x.id+'" '+(x===a?'selected':'')+'>'+escapeHtml(E.P[x.province].name)+' · '+num(x.troops)+' asker · '+x.id+'</option>').join('')+'</select><div class="strategy-army-summary"><span>Bakım <b>'+decimal(S.upkeep(a.units))+' altın/ay</b></span><span>Moral <b>'+decimal(a.morale)+'</b></span><span>Erzak <b>%'+decimal(a.supply)+'</b></span></div>'+(reason?'<p class="strategy-warning">'+escapeHtml(reason)+'</p>':'<p>Ordu güvenli bir kendi şehrinde ve duruyor. İşlemler ay ilerletmez.</p>')+'<section class="strategy-selection"><h3>Bölünecek veya terhis edilecek askerler</h3>'+Object.entries(E.units).map(([u,v])=>'<label for="manage-'+u+'"><span>'+v.name+' <small>Mevcut '+num(a.units[u])+'</small></span><input id="manage-'+u+'" data-manage-unit="'+u+'" type="number" inputmode="numeric" min="0" max="'+a.units[u]+'" step="1" value="0" '+(reason?'disabled':'')+'></label>').join('')+'<p id="army-selection-preview" aria-live="polite">Asker sayılarını gir.</p><div class="strategy-actions"><button data-strategy-split '+(reason?'disabled':'')+'>Seçilenleri ayrı orduya böl</button><button class="danger" data-strategy-disband '+(reason?'disabled':'')+'>Seçilenleri terhis et</button></div><button class="text-link" data-strategy-select-all '+(reason?'disabled':'')+'>Terhis için bütün askerleri seç</button><p class="fineprint">Bölünmede ana orduda asker kalır; yeni ordu aynı moral ve erzakla, komutansız başlar. Terhis altın veya insan gücü iade etmez. Onaydan önce sonuç gösterilir.</p></section><details class="strategy-merge"><summary>Aynı şehirdeki orduları birleştir</summary>'+(others.length?'<label for="merge-target">Katılacak ordu</label><select id="merge-target">'+others.map(b=>'<option value="'+b.id+'">'+b.id+' · '+num(b.troops)+' asker'+(S.managementReason(game,b)?' · uygun değil':'')+'</option>').join('')+'</select><button data-strategy-merge '+(reason?'disabled':'')+'>Birleşme sonucunu incele</button><p>Seçili ordu korunur. Moral ve erzak asker sayısıyla ağırlıklı ortalanır. İki komutan varsa seçili ordunun komutanı görevde kalır.</p>':'<p>Bu şehirde birleştirilebilecek başka kendi ordun yok.</p>')+'</details></div>');
}
function selectedUnits(){return Object.fromEntries(Object.keys(E.units).map(u=>[u,Number($('#manage-'+u).value)]))}
function previewArmySelection(){
 const a=game.armies.find(a=>a.id===managedArmy);if(!a)return;
 const units=selectedUnits(),q=S.armyQuote(game,{type:'disbandArmy',army:a.id,units});
 $('#army-selection-preview').textContent=q.ok?num(q.amount)+' asker seçildi · ana orduda '+num(q.after)+' kalır · terhiste bakım −'+decimal(q.saving)+' altın/ay.':q.reason;
}
function confirmArmyAction(type){
 const action={type,army:managedArmy,...(type==='mergeArmy'?{target:$('#merge-target')?.value}:{units:selectedUnits()})},q=S.armyQuote(game,action);
 if(!q.ok){toast(q.reason,true);return}
 const a=game.armies.find(a=>a.id===managedArmy);
 const text=type==='mergeArmy'?'Birleşen ordu '+num(q.after)+' asker olacak. Moral ve erzak ağırlıklı ortalama ile korunacak.':type==='splitArmy'?num(q.amount)+' asker yeni orduya geçecek; ana orduda '+num(q.after)+' asker kalacak.':num(q.amount)+' asker terhis edilecek; '+(q.after?num(q.after)+' asker kalacak.':'Bu ordu kapanacak.')+' Bakım '+decimal(q.saving)+' altın/ay azalacak; altın ve insan gücü iadesi olmayacak.';
 const copyUnits=action.units?{...action.units}:null;
 openDialog('Ordu emrini onayla','<div class="dialog-help"><p>'+escapeHtml(E.P[a.province].name)+' · '+text+'</p><div class="strategy-actions"><button id="confirm-army-order" class="primary">Emri uygula</button><button data-strategy-armies>Geri dön</button></div></div>');
 $('#confirm-army-order').addEventListener('click',()=>{const result=command({...action,...(copyUnits?{units:copyUnits}:{})});if(result?.ok){selectedArmy=game.armies.some(a=>a.id===action.army)?action.army:E.armies(game,game.player)[0]?.id||null;armyManager(selectedArmy)}} ,{once:true});
}
document.addEventListener('click',e=>{
 if(!game)return;
 const unit=e.target.closest('[data-strategy-unit]');
 if(unit){const select=$('#recruit-unit');select.value=unit.dataset.strategyUnit;select.dispatchEvent(new Event('change',{bubbles:true}));$$('[data-strategy-unit]').forEach(b=>{b.setAttribute('aria-checked',String(b===unit));b.tabIndex=b===unit?0:-1});return}
 if(e.target.closest('[data-strategy-armies]'))return armyManager();
 if(e.target.closest('[data-strategy-select-all]')){const a=game.armies.find(a=>a.id===managedArmy);for(const u of Object.keys(E.units))$('#manage-'+u).value=a.units[u];previewArmySelection();return}
 if(e.target.closest('[data-strategy-split]'))return confirmArmyAction('splitArmy');
 if(e.target.closest('[data-strategy-disband]'))return confirmArmyAction('disbandArmy');
 if(e.target.closest('[data-strategy-merge]'))return confirmArmyAction('mergeArmy');
});
document.addEventListener('change',e=>{if(e.target.id==='managed-army')armyManager(e.target.value)});
document.addEventListener('input',e=>{if(e.target.matches('[data-manage-unit]'))previewArmySelection()});
const strategyPreviousHelp=help;
help=function(){strategyPreviousHelp();$('#dialog-title').textContent='Nasıl oynanır? · 0.4.0-dev.1';$('#dialog-content .dialog-help').insertAdjacentHTML('afterbegin','<p class="strategy-warning">v0.4.0 geliştirmesi · Aşama 1. Canlı v0.3.2 kaydından ayrı kaydedilir; JSON içe aktarma desteklenir. Beyler, karma veraset ve yeni diplomasi henüz eklenmedi.</p><h3>Şehirler ve ordular</h3><p>Şehirde gelir dökümünü aç. Birlik düğmesinde 0,7 saniye bekle veya klavyeyle odaklan: arazi etkileri görünür. Sefer Masası’ndaki Ordu Yönetimi; bölme, birleştirme ve terhis işlemlerini önizleyip onaylamanı sağlar. Kale seviyeleri savunan piyade ve okçuyu güçlendirir.</p>');};

// Unit radios handle their own keys; Space must not start the campaign clock.
document.addEventListener('keydown',e=>{
 const b=e.target.closest('[data-strategy-unit]');if(!b||!['ArrowLeft','ArrowRight','Home','End',' ','Enter'].includes(e.key))return;
 e.preventDefault();e.stopPropagation();
 const buttons=$$('[data-strategy-unit]'),i=buttons.indexOf(b),target=e.key==='Home'?buttons[0]:e.key==='End'?buttons.at(-1):e.key==='ArrowLeft'?buttons[(i+buttons.length-1)%buttons.length]:e.key==='ArrowRight'?buttons[(i+1)%buttons.length]:b;
 target.focus();target.click();
},true);
const strategyPreviousBattle=renderBattle;
renderBattle=function(){strategyPreviousBattle();const b=battleView.report;if(b.cityFort)$('#dialog-content .battle-modifiers')?.insertAdjacentHTML('beforeend','<span>Şehir kalesi '+b.cityFort+': piyade '+percent(b.cityFort*S.combatRules.cityPerFort.infantry)+', okçu '+percent(b.cityFort*S.combatRules.cityPerFort.archer)+'</span>');};
