/* Map-first parchment interface. Game commands and geographic data are unchanged. */
const uiIcons={atlas:'M2 4l5-2 6 2 5-2v14l-5 2-6-2-5 2z M7 2v14 M13 4v14',palace:'M3 18V8h14v10 M6 8V4l4-2 4 2v4 M1 18h18 M7 18v-5h6v5 M6 10h1 M13 10h1',war:'M3 2l5 3 9 12-2 1L6 7z M17 2l-5 3-9 12 2 1L14 7z M2 13l5 4 M13 17l5-4',history:'M5 3h10v14H5z M8 6h4 M8 9h4 M8 12h3 M3 3h2 M15 17h2',depth:'M2 6l4 3 4-6 4 6 4-3-2 10H4z M4 18h12',diplomacy:'M3 6l4-3 6 2 4-1 2 6-4 5-4-1-3 3-5-4z M7 8l4-3 M7 8l3 3 3-2 4 3 M5 12l3 3'};
function uiIcon(k){return '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="'+uiIcons[k]+'"/></svg>'}
const uiNames={atlas:['Atlas','Devlet Atlası'],palace:['Saray','Saray Defteri'],war:['Ordular','Sefer Masası'],history:['Tarih','Tarih ve Hanedan'],depth:['Devlet','Devlet Yolu']};
for(const b of $$('.main-nav>button[data-screen]')){const k=b.dataset.screen;b.innerHTML=uiIcon(k)+'<span>'+uiNames[k][0]+'</span>';b.setAttribute('aria-label',uiNames[k][1]);b.title=uiNames[k][1]}
$('.main-nav .nav-end').insertAdjacentHTML('beforebegin','<button id="ui-diplomacy" aria-controls="game-dialog" aria-expanded="false">'+uiIcon('diplomacy')+'<span>Diplomasi</span></button>');
$('#map-screen').insertAdjacentHTML('beforeend','<button class="ui-reopen" id="ui-reopen-city" aria-controls="province-panel" aria-expanded="false">'+uiIcon('palace')+'<span>Şehir defteri</span><span aria-hidden="true">‹</span></button>');
$('#game-shell').insertAdjacentHTML('beforeend','<div class="ui-workspace-head" id="ui-workspace-head" hidden><small>DEVLET DEFTERİ</small><span id="ui-workspace-title"></span><button class="ui-close-button" id="ui-workspace-close" aria-label="Defteri kapat">×</button></div>');
$('#province-panel').setAttribute('aria-label','Seçili şehir defteri');
let uiCityOpen=false,uiCityMode='overview',uiLastCity=null,uiDialogTrigger=null,uiWorkspaceTrigger=null;
const uiOpenFolds=new Map();
function uiRefreshReopen(){const b=$('#ui-reopen-city');b.hidden=uiCityOpen||!['atlas','war'].includes(screen)||$('#game-dialog').open;b.setAttribute('aria-expanded',String(uiCityOpen));b.querySelector('span').textContent=game?E.P[selectedProvince].name:'Şehir defteri'}
function uiSetCity(open){uiCityOpen=!!open;$('#province-panel').classList.toggle('ui-open',uiCityOpen);uiRefreshReopen()}
function uiFold(name,label,open=false){const city=selectedProvince;const d=document.createElement('details');d.className='ui-fold';d.dataset.uiFold=name;d.open=open;const s=document.createElement('summary');s.textContent=label;const content=document.createElement('div');d.append(s,content);d.addEventListener('toggle',()=>{if(d.isConnected&&city===selectedProvince){const set=uiOpenFolds.get(selectedProvince)||new Set();if(d.open)set.add(name);else set.delete(name);uiOpenFolds.set(selectedProvince,set)}});return {el:d,content}}
const uiProvinceBase=renderProvince;
renderProvince=function(){
 if(!game)return;const prior=$$('#province-panel .ui-fold[open]').map(d=>d.dataset.uiFold);if(uiLastCity)uiOpenFolds.set(uiLastCity,new Set(prior));uiProvinceBase();uiLastCity=selectedProvince;
 const p=game.provinces[selectedProvince],body=$('#province-panel .province-body'),head=$('#province-panel .province-top'),mine=p.owner===game.player,st=E.cityStats(game,selectedProvince),opened=uiOpenFolds.get(selectedProvince)||new Set();
 head.insertAdjacentHTML('beforeend','<button class="ui-close-button" data-ui-city-close aria-label="Şehir panelini kapat">×</button>');
 const craft=body.querySelector('.craft-city-summary');if(craft){head.insertAdjacentHTML('afterend','<p class="ui-context-note"><span>'+escapeHtml(craft.querySelector('strong').textContent)+'</span><button data-open-estates>Yönetim →</button></p>');craft.remove()}
 const dl=body.querySelector('dl');const stats=uiFold('stats','Şehir defteri',opened.has('stats'));const more=document.createElement('dl');[...dl.children].forEach((row,i)=>{if(![1,2,5].includes(i))more.append(row.cloneNode(true))});stats.content.append(more);const inc=body.querySelector('.strategy-income');if(inc)stats.content.append(inc);const note=body.querySelector('.province-note');if(note)stats.content.append(note);
 const build=uiFold('build','İnşaat ve gelişim',opened.has('build')||uiCityMode==='build'),recruit=uiFold('recruit','Asker toplama',opened.has('recruit')),orders=uiFold('orders','Ordu emirleri',opened.has('orders')||uiCityMode==='army'),people=uiFold('people','Topluluklar ve bağlılık',opened.has('people')||uiCityMode==='people'),extra=uiFold('extra','Çevre ve ayrıntılar',opened.has('extra'));
 const actions=[...body.children].find(n=>n.classList.contains('panel-actions'));
 if(actions&&mine){for(const node of [...actions.children])if(node.matches('.unit-picker,.unit-label,#recruit-unit,.recruit-control'))recruit.content.append(node);build.content.append(actions)}
 const community=body.querySelector('.community-panel');if(community)people.content.append(community);if(mine)people.content.insertAdjacentHTML('afterbegin','<p>Devlete bağlılık <strong>'+num(p.allegiance)+'/100</strong> · Aylık isyan olasılığı %'+st.risk.toFixed(1)+'</p><button data-open-community>Bağlılık ve kültür politikaları →</button>');
 const orderNode=[...body.children].find(n=>n.querySelector?.('#army-stance'));if(orderNode)orders.content.append(orderNode);
 const items=[...body.childNodes].filter(n=>n!==dl);for(const node of items)extra.content.append(node);
 body.replaceChildren(dl);
 body.insertAdjacentHTML('beforeend','<div class="ui-city-sections"><button data-ui-city-tab="overview">Genel bakış</button>'+(mine?'<button data-ui-city-tab="build">İnşaat</button>':'')+'<button data-ui-city-tab="people">Topluluklar</button></div>');
 body.append(stats.el);if(mine)body.append(build.el,recruit.el);if(orderNode)body.append(orders.el);body.append(people.el);if(extra.content.childNodes.length)body.append(extra.el);
 if(p.building||p.recruit)body.insertAdjacentHTML('afterbegin','<p class="ui-context-note">'+(p.building?escapeHtml(E.buildings[p.building.type].name)+' inşaatı · '+p.building.remaining+' ay':'')+(p.building&&p.recruit?' · ':'')+(p.recruit?num(p.recruit.amount)+' asker · '+p.recruit.remaining+' ay':'')+'</p>');
 uiSetCity(uiCityOpen);
};
const uiChooseProvince=chooseProvince;
chooseProvince=function(id,focus=false){if(!game||!E.P[id])return;uiCityOpen=true;uiCityMode='overview';if($('#game-dialog').classList.contains('ui-sheet'))closeDialog();if(!['atlas','war'].includes(screen))switchScreen('atlas');uiChooseProvince(id,focus);uiSetCity(true)};
const uiChooseArmy=chooseArmy;
chooseArmy=function(id,focus=true){if(!game?.armies.some(a=>a.id===id&&a.owner===game.player))return;uiCityOpen=true;uiCityMode='army';if($('#game-dialog').classList.contains('ui-sheet'))closeDialog();uiChooseArmy(id,focus);uiSetCity(true)};
const uiScreenBase=switchScreen;
switchScreen=function(name){if(!['atlas','war','palace','history','depth'].includes(name))return;if($('#game-dialog').classList.contains('ui-sheet'))closeDialog();uiWorkspaceTrigger=document.activeElement;uiScreenBase(name);const mapOnly=['atlas','war'].includes(name);$('#map-screen').hidden=false;$('#ui-workspace-head').hidden=mapOnly;if(!mapOnly){$('#ui-workspace-title').textContent=uiNames[name][1];uiSetCity(false);$('#army-roster').hidden=true}else{$('#army-roster').hidden=name!=='war'}uiRefreshReopen();requestAnimationFrame(resizeMap)};
const uiStartGame=startGame;
startGame=function(...args){uiCityOpen=false;uiCityMode='overview';uiLastCity=null;uiOpenFolds.clear();uiStartGame(...args);uiSetCity(false)};
const uiDialogBase=openDialog;
openDialog=function(title,html){
 const d=$('#game-dialog');const inGame=game&&$('#title-screen').hidden;
 const urgent=inGame&&(game.pendingEvents.length||E.politics.blocking(game)||game.nations[game.player].dynasty.crisis||game.lost||/Muharebe|zaferi|Yeni sefer|Sefer sona/.test(title));
 if(!inGame||urgent){if(d.open)d.close();d.classList.remove('ui-sheet');d.setAttribute('aria-modal','true');return uiDialogBase(title,html)}
 uiDialogTrigger=d.open?uiDialogTrigger:document.activeElement;setPlaying(false);if(d.open)d.close();if(!['atlas','war'].includes(screen))switchScreen('atlas');uiSetCity(false);d.classList.add('ui-sheet');d.setAttribute('aria-modal','false');$('#dialog-title').textContent=title;$('#dialog-content').innerHTML=html;d.show();$('#ui-diplomacy').setAttribute('aria-expanded',String(/Diplomasi|Karşı teklif/.test(title)||html.includes('diplomatic-form')));$('#close-dialog').focus({preventScroll:true});uiRefreshReopen();
};
const uiCloseDialog=closeDialog;
closeDialog=function(){uiCloseDialog();$('#ui-diplomacy').setAttribute('aria-expanded','false');uiRefreshReopen();if(uiDialogTrigger?.isConnected&&uiDialogTrigger.getClientRects().length)uiDialogTrigger.focus({preventScroll:true});uiDialogTrigger=null};
$('#ui-diplomacy').addEventListener('click',()=>{if(!game)return;if($('#ui-diplomacy').getAttribute('aria-expanded')==='true'){closeDialog();return}diplomaticOverview();$('#ui-diplomacy').setAttribute('aria-expanded','true')});
$('#ui-reopen-city').addEventListener('click',()=>{if(!game)return;renderProvince();uiSetCity(true);$('#province-panel [data-ui-city-close]').focus({preventScroll:true})});
$('#ui-workspace-close').addEventListener('click',()=>{const target=uiWorkspaceTrigger;switchScreen('atlas');if(target?.isConnected)target.focus({preventScroll:true})});
document.addEventListener('click',e=>{if(!game)return;if(e.target.closest('[data-ui-city-close]')){uiSetCity(false);$('#ui-reopen-city').focus({preventScroll:true});return}const b=e.target.closest('[data-ui-city-tab]');if(b){const mode=b.dataset.uiCityTab;uiCityMode=mode;$$('#province-panel .ui-fold').forEach(el=>el.open=el.dataset.uiFold===({overview:'stats',build:'build',people:'people'}[mode]));$('#province-panel .ui-fold[open]')?.scrollIntoView({block:'nearest',behavior:'smooth'})}});
document.addEventListener('keydown',e=>{if(e.key!=='Escape'||!game||!$('#title-screen').hidden)return;if($('#game-dialog').open&&$('#game-dialog').classList.contains('ui-sheet')){e.preventDefault();closeDialog();return}if($('#game-dialog').open)return;if(!['atlas','war'].includes(screen)){e.preventDefault();switchScreen('atlas')}else if(uiCityOpen){e.preventDefault();uiSetCity(false);$('#ui-reopen-city').focus({preventScroll:true})}});
$('#game-dialog').addEventListener('close',()=>{if($('#game-dialog').open)return;$('#ui-diplomacy').setAttribute('aria-expanded','false');uiRefreshReopen()});
const uiHeaderBase=renderHeader;
renderHeader=function(){uiHeaderBase();const count=game.diplomaticOffers.filter(o=>o.b===game.player).length;$('#ui-diplomacy span').textContent='Diplomasi'+(count?' · '+count:'');uiRefreshReopen()};
/* Show nearby courts first; every surviving state remains reachable. */
diplomaticOverview=function(){
 const n=game.player,all=E.nids.filter(b=>b!==n&&E.own(game,b).length),near=new Set(E.own(game,n).flatMap(id=>E.graph[id].map(j=>game.provinces[j].owner)).filter(b=>b!==n));
 const card=b=>{const m=DU.metrics(game,n,b);return '<button class="ui-nation-card" data-diplomacy="'+b+'">'+crest(b)+'<span><strong>'+escapeHtml(E.N[b].short)+'</strong><small>İlişki '+signed(m.relationship)+' · Güven '+num(m.trust)+' · Tehdit '+num(m.threat)+'</small></span><em aria-hidden="true">›</em></button>'};
 const incoming=incomingDiplomacy();openDialog('Diplomasi','<div class="dialog-help craft-panel ui-diplomacy-overview"><p class="eyebrow">DEVLETLER ARASI İLİŞKİLER</p><p>Anlaşmalarını yönet, komşu saraylarla görüş.</p>'+(incoming?'<h3>Gelen teklifler</h3>'+incoming:'<p class="ui-empty-offers">Bekleyen diplomatik teklif yok.</p>')+'<h3>Yakın devletler</h3><div class="ui-nation-list">'+all.filter(b=>near.has(b)).map(card).join('')+'</div><details><summary>Diğer devletler · '+all.filter(b=>!near.has(b)).length+'</summary><div class="ui-nation-list">'+all.filter(b=>!near.has(b)).map(card).join('')+'</div></details></div>');$('#ui-diplomacy').setAttribute('aria-expanded','true');
};
